<?php if (array_key_exists ("PATH_INFO", $_SERVER)) {
    $File = "/var/Nagios/Node/".trim($_SERVER["PATH_INFO"],"/")."/IsActive.uuid";
    $Uuid = @file_get_contents ($File);
    if ($Uuid) print $Uuid;
}
