<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
require_once ('/var/www/Nagios/Node/Client/Command.php');
class Command_Downtime extends \Nagios\Node\Client\Command {
	function __construct ($Info) {
		parent::__construct ($Info); // MUST be called FIRST !!!

		$Select = "all";
		if ($this->argc > 1) $Select = strtolower ($this->argv[1]);
		$Selection = $this->Select ($Select, 1, 1); // withContacts, withStatus
		if ($Selection === false)
		{
			$this->Abort (400, "Invalid parameters: use 'help' for instructions");
		}
		$Function = "Command_Downtime_Show";
		$Value    = "";
		$User     = $this->user;
		$Comment  = "";

		if ($this->argc > 2)	
		{
			$Function = "Command_Downtime_Set";
			$Value   = strtolower ($this->argv[2]);
			$Action = $this->Match ($Value, "cancel");
			if ($Action == "cancel") $Function = "Command_Downtime_Cancel";
			if ($this->argc < 4) 
			{
				$this->Abort (400, "Missing comment: use 'help downtime' for instructions");
			}
			$Comment = implode (" ", array_slice ($this->argv, 3));
		}
		$this->$Function ($Selection, $Value, $User, $Comment);

		exit (0);
	}
	//-------------------------------------------------------------------------
	function Command_Downtime_Show ($Selection, $Value, $User, $Comment) 
	{
		print "Type/Id  Type.id/Author/Comment               Type.name  /  Starttime/Endtime\n";
		print "-------------------------------------------------------------------------------\n";
		if (array_key_exists ("downtime", $Selection)) {
			foreach ($Selection["downtime"] as $Id => $Data) {
				$Type    = $Data["type"];
				$Name    = $Selection[$Type][$Data["$Type.id"]]["name"];
				$Author  = substr ($Data["author"], 0, 50);
				$Comment = substr ($Data["comment"], 0, 50);
				$Start   = strftime ("%Y/%m/%d %H:%M:%S", $Data["start"]);
				$End     = strftime ("%Y/%m/%d %H:%M:%S", $Data["end"]);
				printf ("%-8s %-36s %s\n", $Type, $Data["$Type.id"], $Name); 
				printf ("%-8s %-50s %s\n", "downtime", $Author, $Start); 
				printf ("%-8s %-50s %s\n", $Id, $Comment, $End); 
				print "-------------------------------------------------------------------------------\n";
			}
		}
	}
	//-------------------------------------------------------------------------
	function Command_Downtime_Set ($Selection, $Value, $User, $Comment) 
	{
		if ($Selection["type"] == "downtime") {
			$this->Abort (400, "Invalid parameters: use 'help' for instructions");
		}
		$Duration = intval ($Value);
		if     (substr($Value,-1) == "h") { $Duration *= 3600; }
		elseif (substr($Value,-1) == "m") { $Duration *= 60;   }
		else                              { $Duration  = 0;    }
		if ($Duration == 0) {
		  $this->Abort (400, "Invalid duration: use 'help downtime' for instructions");
		}
		if ($Duration >= 72*3600) $Duration = 72*3600;
		$Time  = time();
		$Start = $Time;
		$End   = $Time + $Duration;
		$From  = strftime ("%Y/%m/%d %H:%M:%S", $Start);
		$Until = strftime ("%Y/%m/%d %H:%M:%S UTC", $End);

		foreach ($Selection["host"] as $Id => $Data) {
			print "Scheduling downtime for host '$Id' ($From - $Until)\n";
			$Action  = sprintf ("[%s] SCHEDULE_HOST_DOWNTIME;%s;%s;%s;1;0;0;%s;%s\n", $Time, $Id, $Start, $End, $User, $Comment);
			$Action .= sprintf ("[%s] ADD_HOST_COMMENT;%s;1;%s;DOWNTIME SCHEDULED UNTIL %s: %s\n", $Time, $Id, $User, $Until, $Comment);
			$this->Action ($Action);
		}
		foreach ($Selection["service"] as $Id => $Data)
		{
			$Host = $Data["host.id"];
			print "Scheduling downtime for service '$Id' ($From - $Until)\n";
			$Action  = sprintf ("[%s] SCHEDULE_SVC_DOWNTIME;%s;%s;%s;%s;1;0;0;%s;%s\n", $Time, $Host, $Id, $Start, $End, $User, $Comment);
			$Action .= sprintf ("[%s] ADD_SVC_COMMENT;%s;%s;1;%s;DOWNTIME SCHEDULED UNTIL %s: %s\n", $Time, $Host, $Id, $User, $Until, $Comment);
			$this->Action ($Action);
		}
	}
	//-------------------------------------------------------------------------
	function Command_Downtime_Cancel ($Selection, $Value, $User, $Comment) 
	{
		foreach ($Selection["downtime"] as $Id => $Data)
		{
			$Type    = $Data["type"];
			$Name    = $Selection[$Type][$Data["$Type.id"]]["name"];
			$Author  = substr ($Data["author"], 0, 50);
			$Comment = substr ($Data["comment"], 0, 50);
			$From    = strftime ("%Y/%m/%d %H:%M:%S", $Data["start"]);
			$Until   = strftime ("%Y/%m/%d %H:%M:%S UTC", $Data["end"]);

			print "Canceling downtime '$Id' for $Type '".$Data["$Type.id"]."' ($From - $Until)\n";
			$Time  = time();
			
			if ($Type == "host")
			{
				$Host = $Data["host.id"];
				$Action  = sprintf ("[%s] DEL_HOST_DOWNTIME;%s\n", $Time, $Id);
				$Action .= sprintf ("[%s] ADD_HOST_COMMENT;%s;1;%s;DOWNTIME %s UNTIL %s CANCELED: %s\n", $Time, $Host, $User, $Id, $Until, $Comment);
				$this->Action ($Action);
			}
			if ($Type == "service")
			{
				$Service = $Data["service.id"];
				$Host    = $this->config["service"][$Service]["host.id"];
				$Action  = sprintf ("[%s] DEL_SVC_DOWNTIME;%s\n", $Time, $Id);
				$Action .= sprintf ("[%s] ADD_SVC_COMMENT;%s;%s;1;%s;DOWNTIME %s UNTIL %s CANCELED: %s\n", $Time, $Host, $Service, $User, $Id, $Until, $Comment);
				$this->Action ($Action);
			}	
		}
	}
	//-------------------------------------------------------------------------
}
