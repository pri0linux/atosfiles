<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
require_once ('/var/www/Nagios/Node/Client/Command.php');
class Command_Enable extends \Nagios\Node\Client\Command {
	function __construct ($Info) {
		parent::__construct ($Info); // MUST be called FIRST !!!

		if ($this->argc < 3) 
		{
			$this->Abort (400, "Missing parameters: use 'help' for instructions");
		}
		$Select = strtolower ($this->argv[1]);
		$Selection = $this->Select ($Select, 0, 1); // not withContacts, withStatus
		if ($Selection === false)
		{
			$this->Abort (400, "Invalid parameters: use 'help' for instructions");
		}
		$Author  = $this->user;
		$Comment = implode (" ", array_slice ($this->argv, 2));
		$Time     = time();
		
		foreach ($Selection["host"] as $Id => $Data) {
			if (! ($Data['active'] || $Data['passive'])) {
				print "Host check '".$Data['id']."' is configured as disabled\n";
			}
			elseif (! $Data['state.disabled']) {
				print "Host check '".$Data['id']."' has not been disabled\n";
			}
			else {
				$Action = "";
				print "Host check '".$Data['id']."' will be enabled\n";
				if ($Data['active'])  $Action .= sprintf ("[%s] ENABLE_HOST_CHECK;%s\n", $Time, $Data["id"]);
				if ($Data['passive']) $Action .= sprintf ("[%s] ENABLE_PASSIVE_HOST_CHECKS;%s\n", $Time, $Data["id"]);
				$Action .= sprintf ("[%s] ADD_HOST_COMMENT;%s;1;%s;ENABLED: %s\n", $Time, $Data["id"], $Author, $Comment);
				$this->Action ($Action);
			}
		}
		foreach ($Selection["service"] as $Id => $Data) {
			if (! ($Data['active'] || $Data['passive'])) {
				print "Service check '".$Data['id']."' is configured as disabled\n";
			}
			elseif (! $Data['state.disabled']) {
				print "Service check '".$Data['id']."' has not been disabled\n";
			}
			else {
				$Action = "";
				print "Service check '".$Data['id']."' will be enabled\n";
				if ($Data['active'])  $Action .= sprintf ("[%s] ENABLE_SVC_CHECK;%s;%s\n", $Time, $Data["host.id"], $Data["id"]);
				if ($Data['passive']) $Action .= sprintf ("[%s] ENABLE_PASSIVE_SVC_CHECKS;%s;%s\n", $Time, $Data["host.id"], $Data["id"]);
				$Action .= sprintf ("[%s] ADD_SVC_COMMENT;%s;%s;1;%s;ENABLED: %s\n", $Time, $Data["host.id"], $Data["id"], $Author, $Comment);
				$this->Action ($Action);
			}
		}
		
		exit (0);
	}
	//-------------------------------------------------------------------------
}
