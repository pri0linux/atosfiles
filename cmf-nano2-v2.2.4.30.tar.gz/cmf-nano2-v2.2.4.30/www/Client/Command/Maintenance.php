<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
require_once ('/var/www/Nagios/Node/Client/Command.php');
class Command_Maintenance extends \Nagios\Node\Client\Command {
	function __construct ($Info) {
		parent::__construct ($Info); // MUST be called FIRST !!!

		$Select = "all";
		if ($this->argc > 1) $Select = strtolower ($this->argv[1]);
		$Selection = $this->Select ($Select, 0, 0); // not withContacts, not withStatus
		if ($Selection === false) {
			$this->Abort (400, "Invalid parameters: use 'help' for instructions");
		}
		$this->Command_Maintenance_Load();
		$Function    = "Command_Maintenance_Show";
		$Value       = "";
		$User        = $this->user;
		$Comment     = "";

		if ($this->argc > 2) {
			$Function = "Command_Maintenance_Set";
			$Value   = strtolower ($this->argv[2]);
			$Action = $this->Match ($Value, "cancel");
			if ($Action == "cancel") $Function = "Command_Maintenance_Cancel";
			if ($this->argc < 4) {
				$this->Abort (400, "Missing comment: use 'help maintenance' for instructions");
			}
			$Comment = implode (" ", array_slice ($this->argv, 3));
		}
		$this->$Function ($Selection, $Value, $User, $Comment);
		exit (0);
	}
	//-------------------------------------------------------------------------
	function Command_Maintenance_Cancel ($Selection, $Value, $User, $Comment) {
		if ($Selection["type"] == "downtime") {
			$this->Abort (400, "Invalid parameters: use 'help' for instructions");
		}
		if ($Selection["type"] == "client") {
			foreach ($Selection["client"] as $Id => $Data) {
				$this->Command_Maintenance_Cancel_Entry ("client", $Data, $User, $Comment);
			}
		}
		else {
			foreach ($Selection["host"] as $Id => $Data) {
				$this->Command_Maintenance_Cancel_Entry ($Id, $Data, $User, $Comment);
			}
			foreach ($Selection["service"] as $Id => $Data) {
				$this->Command_Maintenance_Cancel_Entry ($Id, $Data, $User, $Comment);
			}
		}
		if ($Selection["type"] == "all") {
			if (array_key_exists ("client", $this->maintenance))
			{
				if (time() < $this->maintenance["client"]["end"])
				{
					$Id      = $this->maintenance["client"]["id"];
					$From    = strftime ("%Y/%m/%d %H:%M:%S", $this->maintenance["client"]["start"]);
					$Until   = strftime ("%Y/%m/%d %H:%M:%S UTC", $this->maintenance["client"]["end"]);
					print "WARNING: Client maintenance mode is still active ($From - $Until)\n";
				}
			}
		}
		$this->Command_Maintenance_Save();
	}
	//-------------------------------------------------------------------------
	function Command_Maintenance_Cancel_Entry ($Entry, $Data, $User, $Comment) 
	{
		if (! array_key_exists ($Entry, $this->maintenance)) return;
		$Type    = $this->maintenance[$Entry]["type"];
		$Id      = $this->maintenance[$Entry]["id"];
		$From    = strftime ("%Y/%m/%d %H:%M:%S", $this->maintenance[$Entry]["start"]);
		$Until   = strftime ("%Y/%m/%d %H:%M:%S UTC", $this->maintenance[$Entry]["end"]);
		print "Cancel maintenance for $Type '$Id' ($From - $Until)\n";
		$this->maintenance[$Entry]["end"] = 0;

		if ($Type == "client")
		{
			$Action = sprintf ("[%s] ADD_HOST_COMMENT;%s;1;%s;CLIENTMAINT UNTIL %s CANCELED: %s\n", time(), $Id, $User, $Until, $Comment);
			$this->Action ($Action);
		}
		elseif ($Type == "host")
		{
			$Action = sprintf ("[%s] ADD_HOST_COMMENT;%s;1;%s;MAINTENANCE UNTIL %s CANCELED: %s\n", time(), $Id, $User, $Until, $Comment);
			$this->Action ($Action);
		}
		elseif ($Type == "service")
		{
			$Host = $Data["host.id"];
			$Action = sprintf ("[%s] ADD_SVC_COMMENT;%s;%s;1;%s;MAINTENANCE UNTIL %s: %s\n", time(), $Host, $Id, $User, $Until, $Comment);
			$this->Action ($Action);
		}
	}	
	//-------------------------------------------------------------------------
	function Command_Maintenance_Load() 
	{
		$File = $this->client["path"]."/Maintenance.dat";
		$Handle = @fopen($File, "r");
		$this->maintenance = array();
		if (! $Handle) return;
		while (!feof($Handle)) 
		{
			$Line = trim (fgets ($Handle));
			if (empty($Line)) continue;
			if (! ctype_xdigit ($Line[0])) continue;
			$Line = explode ("=", $Line, 2);
			if (count($Line) != 2) continue;
			$Name  = trim($Line[0]);
			$Value = trim($Line[1]);
			if (strtolower($Name) == "client") $Name = "client";
			$Info = explode (";", $Value, 6);
			if (count($Info) != 6) continue;
			if (time() > $Info[2]) continue; 
			
			$Type = strtolower($Info[0]);
			$Id   = $Info[1];
			if (! array_key_exists ($Id, $this->config[$Type])) continue;

			$this->maintenance[$Name] = array 
			(
				"type"    => $Type,
				"id"      => $Id,
				"end"     => $Info[2],
				"author"  => $Info[3],
				"start"   => $Info[4],
				"comment" => $Info[5]
			);
		}
		fclose ($Handle);
	}
	//-------------------------------------------------------------------------
	function Command_Maintenance_Save() 
	{
		$Data = "";
		foreach ($this->maintenance as $Name => $Record)
		{
			if (! array_key_exists ($Record["id"], $this->config[$Record["type"]])) continue;
			if (time() >= $Record["end"]) continue; 
			if (strtolower($Name) == "client") $Name = "Client";
			$Info = array 
			( 
				ucfirst($Record["type"]),
				$Record["id"],
				$Record["end"],
				$Record["author"],
				$Record["start"],
				$Record["comment"]
			);
			$Data .= "$Name=".join(";",$Info)."\n";
		}
	
		$File = $this->client["path"]."/Maintenance.dat";
		if (@file_put_contents ($File, $Data) === FALSE) 
		{
			@unlink ($File);
			if (@file_put_contents ($File, $Data) === FALSE) 
			{
				$this->Abort (500, "Unable to write maintenance file $File");
			}
		}
		chmod ($File, 0664);
	}
	//-------------------------------------------------------------------------
	function Command_Maintenance_Set ($Selection, $Value, $User, $Comment) 
	{
		if ($Selection["type"] == "downtime")
		{
			$this->Abort (400, "Invalid parameters: use 'help' for instructions");
		}
		$Duration = intval ($Value);
		if     (substr($Value,-1) == "h") { $Duration *= 3600; }
		elseif (substr($Value,-1) == "m") { $Duration *= 60;   }
		else                              { $Duration  = 0;    }
		if ($Duration == 0)
		{
		  $this->Abort (400, "Invalid duration: use 'help maintenance' for instructions");
		}
		if ($Duration >= 72*3600) $Duration = 72*3600;
		$Start  = time();
		$End    = time() + $Duration;
		$From   = strftime ("%Y/%m/%d %H:%M:%S", $Start);
		$Until  = strftime ("%Y/%m/%d %H:%M:%S UTC", $End);
		$Record = array (
			"type"    => "", 
			"id"      => "", 
			"end"     => $End, 
			"author"  => $User, 
			"start"   => $Start, 
			"comment" => $Comment
		);

		if ($Selection["type"] == "client")
		{
			foreach ($Selection["client"] as $Id => $Data)
			{
				print "Set maintenance for client '$Id' ($From - $Until)\n";
				$Record["type"] = "client"; $Record["id"] = $Id; $this->maintenance["client"] = $Record;
				$Action = sprintf ("[%s] ADD_HOST_COMMENT;%s;1;%s;CLIENTMAINT UNTIL %s: %s\n", time(), $Id, $User, $Until, $Comment);
				$this->Action ($Action);
			}
		}
		else
		{
			foreach ($Selection["host"] as $Id => $Data)
			{
				print "Set maintenance for host '$Id' ($From - $Until)\n";
				$Record["type"] = "host"; $Record["id"] = $Id; $this->maintenance[$Id] = $Record;
				$Action = sprintf ("[%s] ADD_HOST_COMMENT;%s;1;%s;MAINTENANCE UNTIL %s: %s\n", time(), $Id, $User, $Until, $Comment);
				$this->Action ($Action);
			}
			foreach ($Selection["service"] as $Id => $Data)
			{
				$Host = $Data["host.id"];
				print "Set maintenance for service '$Id' ($From - $Until)\n";
				$Record["type"] = "service"; $Record["id"] = $Id; $this->maintenance[$Id] = $Record;
				$Action = sprintf ("[%s] ADD_SVC_COMMENT;%s;%s;1;%s;MAINTENANCE UNTIL %s: %s\n", time(), $Host, $Id, $User, $Until, $Comment);
				$this->Action ($Action);
			}
		}
		$this->Command_Maintenance_Save();
	}
	//-------------------------------------------------------------------------
	function Command_Maintenance_Show ($Selection, $Value, $User, $Comment) 
	{
		print "Type/Id  Type.id/Author/Comment               Type.name  /  Starttime/Endtime\n";
		print "-------------------------------------------------------------------------------\n";
		foreach ($this->maintenance as $Id => $Data)
		{
			$Type = $Data["type"];
			if (($Selection["type"] == "client") && ($Type != "client")) continue;
			if (! array_key_exists ($Data["id"], $Selection[$Type])) continue;
			$Name    = $Selection[$Type][$Data["id"]]["name"];
			$Author  = substr ($Data["author"], 0, 50);
			$Comment = substr ($Data["comment"], 0, 50);
			$From    = strftime ("%Y/%m/%d %H:%M:%S", $Data["start"]);
			$Until   = strftime ("%Y/%m/%d %H:%M:%S", $Data["end"]);
			printf ("%-8s %-36s %s\n", $Type, $Data["id"], $Name); 
			printf ("%-8s %-50s %s\n", "maint", $Author, $From); 
			printf ("%-8s %-50s %s\n", "-", $Comment, $Until); 
			print "-------------------------------------------------------------------------------\n";
		}
	}
	//-------------------------------------------------------------------------
	
	
	
	//-------------------------------------------------------------------------
}
