<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
require_once ('/var/www/Nagios/Node/Client/Command.php');
class Command_Log extends \Nagios\Node\Client\Command {
	function __construct ($Info) {
		parent::__construct ($Info); // MUST be called FIRST !!!

		if ($this->argc < 3) 
		{
			$this->Abort (400, "Missing parameters: use 'help' for instructions");
		}
		$Select = strtolower ($this->argv[1]);
		$Selection = $this->Select ($Select, 0, 0); // not withContacts, not withStatus
		if ($Selection === false)
		{
			$this->Abort (400, "Invalid parameters: use 'help' for instructions");
		}
		$Author  = $this->user;
		$Comment = implode (" ", array_slice ($this->argv, 2));
		$Time     = time();
		
		foreach (array("host","service") as $Type)
		{
			foreach ($Selection[$Type] as $Id => $Data)
			{
				$Action = "";
				if ($Type == "host")
				{
					$Action .= sprintf ("[%s] ADD_HOST_COMMENT;%s;1;%s;LOG COMMENT: %s\n", $Time, $Data["id"], $Author, $Comment);
				}
				if ($Type == "service")
				{
					$Action .= sprintf ("[%s] ADD_SVC_COMMENT;%s;%s;1;%s;LOG COMMENT: %s\n", $Time, $Data["host.id"], $Data["id"], $Author, $Comment);
				}
				$this->Action ($Action);
				print "Logged comment for $Type '".$Data['id']."'\n";
			}
		}
		
		exit (0);
	}
	//-------------------------------------------------------------------------
}
