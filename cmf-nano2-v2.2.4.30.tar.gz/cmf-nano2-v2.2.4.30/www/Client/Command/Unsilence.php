<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
require_once ('/var/www/Nagios/Node/Client/Command.php');
class Command_Unsilence extends \Nagios\Node\Client\Command {
	function __construct ($Info) {
		parent::__construct ($Info); // MUST be called FIRST !!!

		if ($this->argc < 3) 
		{
			$this->Abort (400, "Missing parameters: use 'help' for instructions");
		}
		$Select = strtolower ($this->argv[1]);
		$Selection = $this->Select ($Select, 0, 1); // not withContacts, withStatus
		if ($Selection === false)
		{
			$this->Abort (400, "Invalid parameters: use 'help' for instructions");
		}
		$Author  = $this->user;
		$Comment = implode (" ", array_slice ($this->argv, 2));
		$Time    = time();
		
		foreach ($Selection["host"] as $Id => $Data) {
			if (! $Data['notify']) {
				print "Host check '".$Data['id']."' is configured as silenced\n";
			}
			elseif (! $Data['state.silenced']) {
				print "Host check '".$Data['id']."' has not been silenced\n";
			}
			else {
				print "Host check '".$Data['id']."' will be unsilenced\n";
				$Action  = sprintf ("[%s] ENABLE_HOST_NOTIFICATIONS;%s\n", $Time, $Data["id"]);
				$Action .= sprintf ("[%s] ADD_HOST_COMMENT;%s;1;%s;UNSILENCED: %s\n", $Time, $Data["id"], $Author, $Comment);
				$this->Action ($Action);
			}
		}
		foreach ($Selection["service"] as $Id => $Data) {
			if (! $Data['notify']) {
				print "Service check '".$Data['id']."' is configured as silenced\n";
			}
			elseif (! $Data['state.silenced']) {
				print "Service check '".$Data['id']."' has not been silenced\n";
			}
			else {
				print "Service check '".$Data['id']."' will be unsilenced\n";
				$Action  = sprintf ("[%s] ENABLE_SVC_NOTIFICATIONS;%s;%s\n", $Time, $Data["host.id"], $Data["id"]);
				$Action .= sprintf ("[%s] ADD_SVC_COMMENT;%s;%s;1;%s;UNSILENCED: %s\n", $Time, $Data["host.id"], $Data["id"], $Author, $Comment);
				$this->Action ($Action);
			}
		}

		exit (0);
	}
	//-------------------------------------------------------------------------
}
