<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
require_once ('/var/www/Nagios/Node/Client/Command.php');
class Command_User extends \Nagios\Node\Client\Command {
	function __construct ($Info) {
		parent::__construct ($Info); // MUST be called FIRST !!!
		print $this->user."\n";
		exit (0);
	}
	//-------------------------------------------------------------------------
}
