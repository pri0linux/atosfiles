<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
require_once ('/var/www/Nagios/Node/Client/Command.php');
class Command_List extends \Nagios\Node\Client\Command {
	function __construct ($Info) {
		parent::__construct ($Info); // MUST be called FIRST !!!

		$Select = "all";
		if ($this->argc > 1) $Select = strtolower ($this->argv[1]);
		$Selection = $this->Select ($Select, 1, 1); // withContacts, withStatus
		if ($Selection === false)
		{
			$this->Abort (400, "Invalid parameters: use 'help' for instructions");
		}
		print "Type    Id                                State Name                           \n";
		print "-------------------------------------------------------------------------------\n";
		$Order = array("client","host","service","contact","tag");
		if ($Selection["type"] == "contact")  $Order = array("contact","host","service");
		if ($Selection["type"] == "tag")      $Order = array("tag","host","service");
		if ($Selection["type"] == "downtime") $Order = array("host","service");
		$Count = 0;
		foreach ($Order as $Type)
		{
			ksort ($Selection[$Type]);
			foreach ($Selection[$Type] as $Id => $Data)
			{
				if (! array_key_exists ("name", $Data)) $Data["name"] = "";
				$Id    = substr ($Data["id"],   0, 36);
				$Name  = $Data["name"];
				$State = "";
				if (in_array ($Type, array("host","service")))
				{
					$State .= $Data["state.disabled"] ? "D" : "-";
					$State .= $Data["state.silenced"] ? "S" : "-";
				}
				printf ("%-8s%-37s%-3s%s\n", $Type, $Id, $State, $Name);
				$Count++;
			}
		}
		if ($Count) print "-------------------------------------------------------------------------------\n";
		exit (0);
	}
	//-------------------------------------------------------------------------
}
