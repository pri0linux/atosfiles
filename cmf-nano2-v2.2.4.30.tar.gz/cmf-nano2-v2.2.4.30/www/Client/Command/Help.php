<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
require_once ('/var/www/Nagios/Node/Client/Command.php');
class Command_Help extends \Nagios\Node\Client\Command {
	function __construct ($Info) {
		parent::__construct ($Info); // MUST be called FIRST !!!
		$this->Header();
		if ($this->argc > 1) {
			$Subjects = array ("Downtime","Maintenance");
			$Subject = $this->Match ($this->argv[1], $Subjects);
			if ($Subject) {
				$Subject = "Command_Help_$Subject";
				$this->$Subject();
				exit (0);
			}
		}
		print "Disable <select> <comment>    disable the selected host/service check(s).      \n";
		print "Downtime [<settings>]         manage downtime settings (see 'help downtime').  \n";
		print "Dump <options>                dump the selected info in human-readable format. \n";
		print "Enable <select> <comment>     enable the selected host/service check(s).       \n";
		if (function_exists("json_encode"))
		{
			print "Get <select>                  retrieve the selected info in JSON format.       \n";
		}
		print "Help                          show this list of available commands.            \n";
		print "Help <command>                show more detailed instructions (if available).  \n";
		print "Info                          show some information about the client.          \n";
		print "List [<select>]               lists configured client/hosts/services/contacts. \n";
		print "Log <select> <comment>        Log a comment for selected hosts/services.       \n";
		print "Maintenance [<settings>]      show or set maintenance (see 'help maint').      \n";
		print "Silence <select> <comment>    disable notifications for the selected items.    \n";
		print "Unsilence <select> <comment>  enable notifications for the selected items      \n";
		print "User                          show the username as reported by the client.     \n";
		print "Version                       show the server's version and copyright string.  \n";
		print "-------------------------------------------------------------------------------\n";
		print "- The <select> parameter can be used in different ways:                        \n";
		print "    all             to select all hosts & services assigned to this client.    \n";
		print "    client          to select all hosts assigned to this client.               \n";
		print "    <host-id>       to select the host with the specified id.                  \n";
		print "    <service-id>    to select the service with the specified id.               \n";
		print "    <contact-id>    to select hosts & services using the specified contact id. \n";
		print "    <name>=<value>  to select hosts & services with a specific tag name/value. \n";
		print "- Comments are mandatory and MUST contain an intelligent description !!!       \n";
		print "-------------------------------------------------------------------------------\n";
		if (! function_exists("json_encode"))
		{
			print "NOTE: Install 'php-json' on the ".$this->{node}." to enable JSON mode support !!!\n";
			print "-------------------------------------------------------------------------------\n";
		}
		exit (0);
	}
	//-------------------------------------------------------------------------
	function Command_Help_Downtime()
	{
		print "Downtime [all]                          show all scheduled downtime periods.   \n";
		print "Downtime <select>                       show downtime for the selected objects.\n";
		print "Downtime <select> <duration> <comment>  set downtime for the selected objects. \n";
		print "Downtime <select> cancel <comment>      cancel downtime for selected objects.  \n";
		print "Downtime <downtime>                     show the details of a downtime period. \n";
		print "Downtime <downtime> cancel <comment>    cancel the specified downtime period.  \n";
		print "-------------------------------------------------------------------------------\n";
		print "- The <select> parameter can be used in different ways:                        \n";
		print "    all             to select all hosts & services assigned to this client.    \n";
		print "    client          to select all hosts assigned to this client.               \n";
		print "    <host-uuid>     to select the host with the specified uuid.                \n";
		print "    <service-uuid>  to select the service with the specified uuid.             \n";
		print "    <contact-uuid>  to select hosts & services with the specified contact.     \n";
		print "    <name>=<value>  to select hosts & services with a specific tag name/value. \n";
		print "- The <duration> must be specified in minutes (f.i. 30m) or hours (max 72h).   \n";
		print "- The <downtime> parameter is the unique numeric id of a downtime period.      \n";
		print "- Comments are mandatory and MUST contain an intelligent description !!!       \n";
		print "-------------------------------------------------------------------------------\n";
	}
	//-------------------------------------------------------------------------
	function Command_Help_Maintenance()
	{
		print "Maintenance [all]                          show all maintenance settings.      \n";
		print "Maintenance <select>                       show selected maintenance settings. \n";
		print "Maintenance <select> <duration> <comment>  set maintenance mode for selection. \n";
		print "Maintenance <select> cancel <comment>      cancel maintenance for selection.   \n";
		print "-------------------------------------------------------------------------------\n";
		print "- The <select> parameter can be used in different ways:                        \n";
		print "    all             to select all hosts & services assigned to this client.    \n";
		print "    client          to select the client level maintenance mode (see NOTE !!!).\n";
		print "    <host-uuid>     to select the host with the specified uuid.                \n";
		print "    <service-uuid>  to select the service with the specified uuid.             \n";
		print "    <contact-uuid>  to select hosts & services with the specified contact.     \n";
		print "    <name>=<value>  to select hosts & services with a specific tag name/value. \n";
		print "- NOTE that client level maintenance mode applies to ALL hosts & services !!!  \n";
		print "- The <duration> must be specified in minutes (f.i. 30m) or hours (max 72h).   \n";
		print "- Comments are mandatory and MUST contain an intelligent description !!!       \n";
		print "-------------------------------------------------------------------------------\n";
	}
	//-------------------------------------------------------------------------
}
