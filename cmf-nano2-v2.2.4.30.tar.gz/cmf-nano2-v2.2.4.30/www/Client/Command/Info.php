<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
require_once ('/var/www/Nagios/Node/Client/Command.php');
class Command_Info extends \Nagios\Node\Client\Command {
	function __construct ($Info) {
		parent::__construct ($Info); // MUST be called FIRST !!!
		$this->header();
		global $_SERVER;
		print "Client.address    ".$_SERVER["REMOTE_ADDR"]."\n";
		print "Client.name       ".$this->client["name"]."\n";
		print "Client.user       ".$this->user."\n";
		print "Client.id         ".$this->client["uuid"]."\n";
		print "Client.version    ".implode(".",$this->client["version"])."\n";
		print "-------------------------------------------------------------------------------\n";
		exit (0);
	}
	//-------------------------------------------------------------------------
}
