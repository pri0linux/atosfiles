<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
require_once ('/var/www/Nagios/Node/Client/Command.php');
class Command_Get extends \Nagios\Node\Client\Command {
	function __construct ($Info) {
		parent::__construct ($Info); // MUST be called FIRST !!!

		$Select = "all";
		if ($this->argc > 1) $Select = strtolower ($this->argv[1]);
		$Selection = $this->Select ($Select, 1, 1); // withContacts, withStatus
		if ($Selection === false)
		{
			$this->Abort (400, "Invalid parameters: use 'help' for instructions");
		}
		if (! function_exists("json_encode"))
		{
			$this->Abort (500, "JSON encoder not available");
		}
		print json_encode ($Selection)."\n";
	}
	//-------------------------------------------------------------------------
}
