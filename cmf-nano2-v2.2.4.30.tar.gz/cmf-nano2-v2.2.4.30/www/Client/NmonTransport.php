<?php 

  //---------------------------------------------------------------------------
  // /var/www/nacc/NmonTransport.php - Nagios Node Nmon transport script
  //---------------------------------------------------------------------------
  // $VERSION   = '1.0003';
  // $COPYRIGHT = 'Atos SE 2015-2018';
  // $AUTHOR    = 'Peter.Hoogendijk@Atos.net'; 
  //---------------------------------------------------------------------------
  header ("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
  header ("Cache-Control: post-check=0, pre-check=0", false);
  header ("Pragma: no-cache");
  //---------------------------------------------------------------------------
  // Check if the queue folder exists
  //---------------------------------------------------------------------------
  $Queue = "/var/Nagios/Node/NmonTransport";
  if (! is_dir ($Queue))
  {
    header ($_SERVER["SERVER_PROTOCOL"]." 503 Service Unavailable", true, 503);
    print "Service Unavailable: directory '$Queue' does not exist";
    exit (0);
  }
  //---------------------------------------------------------------------------
  // Check the queue folder heartbeat
  //---------------------------------------------------------------------------
  $Age = time() - @filemtime ("$Queue/.heartbeat");
  if ($Age > 3600)
  {
    header ($_SERVER["SERVER_PROTOCOL"]." 503 Service Unavailable", true, 503);
    print "Service Unavailable: queue heartbeat is $Age seconds old";
    exit (0);
  }
  //---------------------------------------------------------------------------
  // Queue the uploaded nmon data
  //---------------------------------------------------------------------------
  $File = sprintf ("%10.10f.%05d.pds", microtime(true), getmypid());
  if (! @copy ("php://input" ,"$Queue/$File"))
  {
    $Error = error_get_last();
    header ($_SERVER["SERVER_PROTOCOL"]." 503 Service Unavailable", true, 503);
    print "Service Unavailable: ".$Error['message'];
    exit (0);
  }
  //---------------------------------------------------------------------------
  // Discard empty files
  //---------------------------------------------------------------------------
  if (! filesize ("$Queue/$File")) unlink ("$Queue/$File");

?>

