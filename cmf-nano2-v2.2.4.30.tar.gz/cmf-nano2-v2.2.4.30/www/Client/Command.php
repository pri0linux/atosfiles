<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
//=============================================================================
class Command
{
	//-------------------------------------------------------------------------
	public $version   = "2.2.3.24";
	public $copyright = "Atos SE 2009-2020";
	//-------------------------------------------------------------------------
	public $argc        = 0;		// the number of command line arguments
	public $argv        = array();	// the command line arguments
	public $client      = false;	// the validated client information
	public $config      = null;		// the client configuration data
	public $grep        = false;	// the location of the 'grep' binary
	public $instance    = "";		// the Nagios Node instance name
	public $maintenance = null;		// the client maintenance data
	public $node        = "";		// the hostname of the Nagios Node
	public $skew        = 0;		// the client's clock skew
	public $user        = "";		// the client user issuing the command
    //=========================================================================
    public function __construct ($Info) {
		date_default_timezone_set ("UTC");
		header('Content-Type: text/plain');
		$this->_LoadInstance();
		$this->node = strtoupper(array_shift(explode(".",php_uname("n"))));
		$this->grep = trim(`which grep 2>/dev/null`);
		if ($this->grep == "") $this->Abort (500, "'grep' not found");
		foreach (array("argc","argv","client","user") as $Key) $this->$Key = $Info[$Key];
		if ($this->user == "") $this->Abort (400, "Missing parameters");
		if (! $this->client) $this->_ValidateClient();
    }
    //=========================================================================
    public function Abort ($Code, $Message) {
		error_log ("$Code $Message");
		$Status = $_SERVER["SERVER_PROTOCOL"]." $Code $Message";
		header ($Status, true, $Code);
		print "$Status\n";
		exit (0);
    }
    public function Action ($Action) {
   		$Path = "/var/Nagios/Node/".$this->instance."/Core/Command";
		$File = sprintf ("%0.10f.%05d.cmd", microtime(TRUE), getmypid());
		$Try = @file_put_contents ("$Path/$File", $Action);
		if (! $Try) $this->Abort (500, "Unable to write command queue");
    }
    public function Header ($noLine = false) {
		print "Nagios Client Command Handler ".$this->version." - Copyright (c) ".$this->copyright."\n";
		if ($noLine) return;
		print "-------------------------------------------------------------------------------\n";
	}
    public function Match() {
		if (! func_num_args()) return null;
		$Options = func_get_args();
		$Input = trim(array_shift($Options));
		if ($Input == "") return "";
		$Match = false;
		foreach ($Options as $Option)
		{
			if (! is_array($Option)) $Option = array($Option);
			foreach ($Option as $O)
			{
				if (strlen($Input) > strlen($O)) continue; // too long to match
				if (strcasecmp($O,$Input) == 0) return $O; // exact match
				if (substr_compare($O,$Input,0,strlen($Input),true) != 0) continue;
				if ($Match != false) return null;
				$Match = $O; // partial match, but is it unique?
			}
		}
		return $Match; // unique match
    }
    public function Select ($Select, $withContacts = 0, $withStatus = 0) {
		if (! $this->_Select_Is_Valid($Select)) return false;
   		$this->_LoadConfig();
   		if ($withContacts) $this->_LoadContacts();
   		if ($withStatus)   $this->_LoadStatus();
		$Selection = array (
			"type"    => "",
			"client"  => array(),
			"host"    => array(),
		    "service" => array(),
		    "contact" => array(),
		    "tag"     => array()
		);
		if (in_array ($Select, array("all","client"))) {
			$Selection["type"] = $Select;
			$Selection["client"] = $this->config["client"];
		}
		foreach ($this->config as $Type => $Objects) {
			foreach ($Objects as $Id => $Data) {
				if ($Select == "all") {
					if (! in_array ($Type, array("host","service"))) continue;
					$this->_Select_With_Related ($Type, $Data, $Selection);
				}
				elseif ($Select == "client") {
					if ($Type != "host") continue;
					$this->_Select_With_Related ($Type, $Data, $Selection);
				}
				elseif ($Select == $Id) {
					$Selection["type"] = $Type;
					$this->_Select_With_Related ($Type, $Data, $Selection);
				}
				elseif ($Type == "tag") { // also check with '+'-encoded spaces
					if ($Select == str_replace (" ","+",$Id)) {
						$Selection["type"] = $Type;
						$this->_Select_With_Related ($Type, $Data, $Selection);
					}
				}
			}
		}
		if ($Selection["type"] != "downtime") {
			foreach (array("host","service") as $Type) {
				foreach ($Selection[$Type] as $Id => $Data) {
					if (! array_key_exists ("downtime.id", $Data)) continue;
					foreach ($Data["downtime.id"] as $Downtime) {
						$Selection["downtime"][$Downtime] = $this->config["downtime"][$Downtime];
					}
				}
			}
		}
		return $Selection;
	}
    //=========================================================================
    private function _Find_Object ($Line, $Load) { // Find the start of an object definition
		if (substr($Line, -1) != "{") return ""; // Just to make sure ;-)
		if (substr($Line, 0, 6) != "define") return "";
		$Info = preg_split ("/[\s\{]+/", $Line);
		if (count($Info) < 2) return "";
		if (! array_key_exists ($Info[1], $Load)) return "";
		return $Info[1];
    }
    private function _Find_Status ($Line, $Load) { // Find the start of an status record
		if (substr($Line, -1) != "{") return ""; // Just to make sure ;-)
		$Info = explode (" ", $Line);
		if (count($Info) < 2) return "";
		if (! array_key_exists ($Info[0], $Load)) return "";
		return $Info[0];
    }
    private function _Index_Contacts ($Type, &$Data) { // Index the object contact information
		$Id = $Data["id"];
		if (! array_key_exists ("contacts", $Data)) return;
		$Contacts = preg_split("/[\s,]+/", $Data["contacts"]);
		unset ($Data["contacts"]);
		$Data["contact.id"] = array();
		foreach ($Contacts as $Contact) {
			if (strcasecmp($Contact,"dummy") == 0) continue;
			if (! array_key_exists ($Contact, $this->config["contact"])) {
				$this->config["contact"][$Contact] = array("id"=>$Contact,"host.id"=>array(),"service.id"=>array());
			}
			array_push ($this->config["contact"][$Contact]["$Type.id"], $Id);
			array_push ($Data["contact.id"], $Contact);
		}
    }
    private function _Index_Tags ($Type, &$Data) { // Index the object tag information
		if (array_key_exists ("tag.id", $Data)) {
			foreach ($Data["tag.id"] as $Id) {
				array_push ($this->config["tag"][$Id]["$Type.id"], $Data["id"]);
			}
		}
    }
    private function _LoadConfig() { // Load the client's host, service & contact information
   		$File = $this->client["path"]."/Config.info";
		$Handle = @fopen($File, "r");
		if (! $Handle) $this->Abort (404, "Client configuration not available");
		$Client = array (
			"id" => $this->client["uuid"],
			"name" => $this->client["name"]
		);
		$this->config = array (
			"client"  => array ($this->client["uuid"] => $Client),
			"host"    => array(),
			"service" => array(),
			"contact" => array(),
			"tag"     => array()
		);
		$Type = "";
		$Data = array();
		$Load = array (
			"host" => array (
				"host_name"              => "id",
				"display_name"           => "name",
				"contacts"               => "contacts",
				"_team"                  => "team.id",
				"active_checks_enabled"  => "active",
				"passive_checks_enabled" => "passive",
				"notifications_enabled"  => "notify"
			),
			"service" => array (
				"service_description"    => "id",
				"display_name"           => "name",
				"host_name"              => "host.id",
				"contacts"               => "contacts",
				"_team"                  => "team.id",
				"active_checks_enabled"  => "active",
				"passive_checks_enabled" => "passive",
				"notifications_enabled"  => "notify"
			),
			"contact" => array (
				"contact_name"          => "id",
				"_display_name"         => "name",
				"_team"                 => "team.id",
			)
		);
		//-------------------------------------------------------------
		// Parse the configuration file
		//-------------------------------------------------------------
		while (!feof($Handle)) {
			$Line = trim (fgets($Handle));
			if ($Type == "") { // Scan for the start of an object
				if (substr($Line, -1) != "{") continue;
				$Type = $this->_Find_Object ($Line, $Load);
				continue;
			}
			if ($Line[0] != '}') {
				$this->_Load_Object ($Type, $Line, $Load, $Data);
				continue;
			}
			if (array_key_exists ("id", $Data)) {
				if (in_array ($Type, array("host","service"))) {
					foreach (array("active","passive","notify") as $Key) {
						if (! array_key_exists ($Key, $Data)) $Data[$Key] = 0;
					}
				}
				$this->_Index_Contacts ($Type, $Data);
				$this->_Index_Tags ($Type, $Data);
				$this->config[$Type][$Data["id"]] = $Data;
			}
			$Type = "";
			$Data = array();
		}
		fclose ($Handle);
	}
    private function _LoadContacts() { // Load the contact properties from the main object configuration file
		if (count($this->config["contact"]) == 0) return;
   		$File = "/var/Nagios/Node/".$this->instance."/objects.cfg";
		$Handle = @popen("$this->grep -B10 -A40 'define contact' $File", "r");
		if (! $Handle) $this->Abort (404, "Object configuration not available");
		$Type = "";
		$Data = array();
		$Load = array (
			"contact" => array (
				"contact_name"          => "id",
				"_display_name"         => "name",
				"_team"                 => "team.id",
			)
		);
		//-------------------------------------------------------------
		// Parse the configuration file
		//-------------------------------------------------------------
		while (!feof($Handle)) {
			$Line = trim (fgets($Handle));
			if ($Type == "") { // Scan for the start of an object
				if (substr($Line, -1) != "{") continue;
				$Type = $this->_Find_Object ($Line, $Load);
				continue;
			}
			if ($Line[0] != '}') {
				$Name = $this->_Load_Object ($Type, $Line, $Load, $Data);
				if ($Name != "id") continue;
				if (array_key_exists ($Data["id"], $this->config[$Type])) continue;
				$Type = "";
				$Data = array();
				continue;
			}
			if (array_key_exists ("id", $Data)) {
				unset ($Data["tag"]); // Ignore contact tags (= multi-client)
				foreach ($Data as $Name => $Value) {
					$this->config[$Type][$Data["id"]][$Name] = $Value;
				}
			}
			$Type = "";
			$Data = array();
		}
		fclose ($Handle);
    }
    private function _LoadInstance() { // Load the information about the Nagios Node instance
		$File = dirname(__FILE__)."/index.cfg";
		$Config = @parse_ini_file ($File);
		if (! is_array ($Config)) $this->Abort (500, "Error reading $File");
		foreach ($Config as $Name => $Value)
		{
			$Config[strtolower($Name)] = $Value;
			if ( strlen($Value) < 17 ) continue;
			if (substr_compare ($Value, "/var/Nagios/Node/", 0, 17) != 0) continue;
			$Value = explode ("/", $Value);
			$this->instance = $Value[4];
		}
		if (array_key_exists ("instance", $Config)) $this->instance = $Config["instance"];
		if ($this->instance == "") $this->Abort (500, "Invalid data in $File");
		$File = "/var/Nagios/Node/".$this->instance."/Active.pid";
		if (! file_exists ($File)) $this->Abort (503, "Temporarily unavailable");
    }
    private function _Load_Object ($Type, $Line, $Load, &$Data) { // Load an entry from an object definition
		$Info = preg_split ("/[\s]+/", $Line, 2);
		if (count($Info) != 2) return "";
		$Name = strtolower($Info[0]);
		if (array_key_exists ($Name, $Load[$Type])) {
			$Data[$Load[$Type][$Name]] = $Info[1];
			return $Load[$Type][$Name];
		}
		if (! in_array ($Type, array("host","service"))) return "";
		//-------------------------------------------------------------
		// For hosts & services also process the tags
		//-------------------------------------------------------------
		if (! array_key_exists ("tag.id", $Data)) $Data["tag.id"] = array();
		if (substr_compare ($Name, "_tag_", 0, 5) != 0) return "";
		$Tag_name = strtolower(substr($Name,5)) . "=" . $Info[1];
		$Tag_id   = strtolower($Tag_name);
		array_push ($Data["tag.id"], $Tag_id);
		
		if (! array_key_exists ($Tag_id, $this->config["tag"])) {
			$this->config["tag"][$Tag_id] = array();
			$this->config["tag"][$Tag_id]["id"]         = $Tag_id;
			$this->config["tag"][$Tag_id]["name"]       = $Tag_name;
			$this->config["tag"][$Tag_id]["host.id"]    = array();
			$this->config["tag"][$Tag_id]["service.id"] = array();
		}
		return "tag";
    }
    private function _Load_Status ($Record, $Line, $Load, &$Data) { // Load an entry from a status record
		$Info = explode ("=", $Line, 2);
		if (count($Info) != 2) return "";
		$Name = strtolower($Info[0]);
		if (! array_key_exists ($Name, $Load[$Record])) return "";
		$Data[$Load[$Record][$Name]] = $Info[1];
		return $Load[$Record][$Name];
    }
    private function _LoadStatus() { // Load the host & service status & downtime information
		if ((count($this->config["host"]) + count($this->config["service"])) == 0) return;
   		$File = "/var/Nagios/Node/".$this->instance."/status.dat";
		$Handle = @popen("$this->grep '".$this->client["uuid"]."' -B10 -A90 $File", "r");
		if (! $Handle) $this->Error (404, "Object status data not available");
		$Record = "";
		$Type   = "";
		$Data   = array();
		$Load   = array (
			"hoststatus" => array (
				"host_name"              => "id",
				"active_checks_enabled"  => "active",
				"passive_checks_enabled" => "passive",
				"notifications_enabled"  => "notify",
			),
			"servicestatus" => array (
				"service_description"    => "id",
				"active_checks_enabled"  => "active",
				"passive_checks_enabled" => "passive",
				"notifications_enabled"  => "notify",
			),
			"hostdowntime" => array (
				"host_name"           => "id",
				"downtime_id"         => "downtime",
				"author"              => "author",
				"comment"             => "comment",
				"start_time"          => "start",
				"end_time"            => "end",
			),
			"servicedowntime" => array (
				"service_description" => "id",
				"downtime_id"         => "downtime",
				"author"              => "author",
				"comment"             => "comment",
				"start_time"          => "start",
				"end_time"            => "end",
			)
		);
		$this->config["downtime"] = array();
		foreach ($this->config["host"] as $Id => &$Ref) $Ref["downtime.id"] = array();
		foreach ($this->config["service"] as $Id => &$Ref) $Ref["downtime.id"] = array();
		//-------------------------------------------------------------
		// Parse the configuration file
		//-------------------------------------------------------------
		while (!feof($Handle)) {
			$Line = trim (fgets($Handle));
			if ($Record == "") { // Scan for the start of a status record
				if (substr($Line, -1) != "{") continue;
				$Record = $this->_Find_Status ($Line, $Load);
				if ($Record != "") $Type = ($Record[0] == "h") ? "host" : "service";
				continue;
			}
			if ($Line[0] != '}') {
				$Name = $this->_Load_Status ($Record, $Line, $Load, $Data);
				if ($Name != "id") continue;
				if (array_key_exists ($Data["id"], $this->config[$Type])) continue;
				$Record = "";
				$Type   = "";
				$Data   = array();
				continue;
			}
			if (($Record == "hoststatus") || ($Record == "servicestatus")) {
				$Disabled = (! ($Data["active"] || $Data["passive"]));
				if (! $Disabled) $Disabled = 0;
				$this->config[$Type][$Data["id"]]["state.disabled"] = $Disabled;
				$Silenced = (! $Data["notify"]);
				if (! $Silenced) $Silenced = 0;
				$this->config[$Type][$Data["id"]]["state.silenced"] = $Silenced;
			}
			elseif (($Record == "hostdowntime") || ($Record == "servicedowntime")) {
				// Normalize the downtime record
				$Data["type"] = $Type;
				$Data["$Type.id"] = $Data["id"];
				$Data["id"] = $Data["downtime"];
				unset ($Data["downtime"]);
				$this->config["downtime"][$Data["id"]] = $Data;
				array_push ($this->config[$Type][$Data["$Type.id"]]["downtime.id"], $Data["id"]);
			}
			$Record = "";
			$Type   = "";
			$Data   = array();
		}
		fclose ($Handle);
	}
    private function _Select_Is_Valid ($Select) {
		if (in_array ($Select, array("all","client"))) return 1;
		if (trim ($Select, "0123456789") == "") return 1;
		$Test = explode ("=", trim($Select,"="), 2);
		if (count($Test) == 2) return 1;
		$Test = '/^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$/i';
		if (preg_match ($Test, $Select)) return 1;
		return 0;
    }
    private function _Select_With_Related ($Type, $Data, &$Selection) {
		$Selection[$Type][$Data["id"]] = $this->config[$Type][$Data["id"]];
		foreach (array("host","service","contact","tag","downtime") as $T) {
			if (($Type == "service") && ($T == "host")) continue;
			if (! array_key_exists ($T, $this->config)) continue;
			if (! array_key_exists ("$T.id", $Data)) continue;
			$Relations = $Data["$T.id"];
			if ($Type == "downtime") $Relations = array($Data["$T.id"]);
			foreach ($Relations as $I) {
				if (! array_key_exists ($I, $this->config[$T])) continue;
				$Selection[$T][$I] = $this->config[$T][$I];
			}
		}
    }
    private function _ValidateClient() {
		global $_SERVER;
		$this->client = array (
			'agent'   => trim ($_SERVER['HTTP_USER_AGENT']),
			'name'    => "",
			'path'    => "",
			'serial'  => "0",
			'token'   => "0",
			'uuid'    => "",
			'version' => array (0, 0, 0, 0)
		);
		$Agent = preg_split ("/[\/\s\(\)]+/", $this->client["agent"]);
		if (count($Agent) < 4) $this->Abort (403, "Forbidden");
		$this->client['version'] = explode (".", $Agent[1]);
		$this->client['name'] = $Agent[2];
		$Uuid = $Agent[3];
		$Test = '/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/';
		if (! preg_match($Test, strtolower($Uuid))) $this->Abort (403, "Forbidden");
		$this->client['uuid'] = $Uuid;
		$this->client['path'] = "/var/Nagios/Node/".$this->instance."/Client/$Uuid";
		foreach (array("Serial","Token") as $Key) {
			if (! array_key_exists ($Key, $Cookie)) continue;
			$this->client[strtolower($Key)] = $Cookie[$Key];
		}
		$File = $this->client['path']."/Record.info";
		$Record = @parse_ini_file ($File, false, INI_SCANNER_RAW);
		if (! is_array ($Record)) $this->Abort (403, "Forbidden");
    }
    //=========================================================================
}
//=============================================================================
if (basename($_SERVER["PHP_SELF"]) == "Command.php") {
	$Error = array (400, "Bad Request"); // unless proven otherwise :-)
	$Input  = @trim (@file_get_contents ("php://input"));
	if ($Input != "") {
		$Info = array ("client" => false); // client needs validation
		$Info["argv"] = preg_split ('/\s+/', $Input);
		$Info["argc"] = count ($Info["argv"]);
		$Info["user"] = "";
		if (array_key_exists("user", $_GET)) $Info["user"] = $_GET["user"];
		$Command = ucfirst (strtolower ($Info["argv"][0]));
		$Script  = "/var/www/Nagios/Node/Client/Command/$Command.php";
		if (file_exists ($Script)) {
			@include_once ($Script);
			$Class = "\\Nagios\\Node\\Client\\Command_$Command";
			if (class_exists($Class)) {
				new $Class ($Info);
				exit (0);
			}
			else $Error = array (500, "Failed to load $Class");
		}
		else $Error = array (400, "Invalid command: use 'help' for the list of commands");
	}
	$Code = $Error[0];
	$Text = $Error[1];
	header ($_SERVER['SERVER_PROTOCOL']." $Code $Text", true, $Code);
	exit (0);
}
//=============================================================================
