<?php namespace Nagios\Node\Client; // needs php 5.3 or later !!!
//-----------------------------------------------------------------------------
// /nacc/index.php - Nagios Node Client Connector
//-----------------------------------------------------------------------------
class Connector
{
    //-------------------------------------------------------------------------
    // Possible HTTP Status Codes:
    // ---------------------------
    // 200	OK
    // 400  Bad Request (invalid query string)
    // 403  Forbidden (query from unvalidated client)
    // 403	Unrecognized HTTP User Agent (not 'NaCl' or wrong version)
    // 404  Requested file or package not found
    // 503 	No Nagios::Node::Client process (missing heartbeat)
    // 504  No Nagios::Node::Client process response (invalid or timeout)
    // 507	Error writing to the input queue
    //-------------------------------------------------------------------------
    public $client;		# Client information initialized by ValidateClient()
    public $id;     	# The connection id for the input and output filenames
    public $instance;   # Loaded from 'index.cfg' (normally "NagiosNode")
    public $path;       # The path of the main Nagios::Node::Client folder
    public $record;		# The client record maintained by the Nagios Node
    public $server;		# Server information initialized with $_SERVER
    //-------------------------------------------------------------------------
	function __construct ($Server, $Cookie) 
	{
		date_default_timezone_set ("UTC");
		if (! array_key_exists ('HTTPS', $Server)) $Server['HTTPS'] = "";
		$this->server = $Server;
		$this->LoadConfig();
		$this->path   = "/var/Nagios/Node/".$this->instance."/Client";
		$this->id     = sprintf ("%.10f.%d", microtime(true), getmypid());

		if (! file_exists ("/var/Nagios/Node/".$this->instance."/Active.pid"))
		{
			$this->Abort (503, "Temporarily unavailable");
		}
		if (! $this->CheckHeartbeat()) $this->Abort (503, "Missing Heartbeat");

		$Query = strtolower($Server['QUERY_STRING']);
		if ($Query == "debug") exit ($this->Debug()); 
		if ($Query == "help" ) exit ($this->Help()); 
		if ($Query == "test" ) exit ($this->Test()); 

		if ($this->ValidateClient ($Cookie))
		{
			if ($Query != "") exit ($this->Query());
			if (! $this->QueueInput()) $this->Abort (507, "Queue Failed");
			$this->record['cached'] = 1;
			exit ($this->SendResponse()); # return the existing response
		}
		if ($Query != "") $this->Abort (403, "Forbidden");
		if ($this->client['version'][0] < 1) $this->Abort (403, "Unsupported Client");

		if (! $this->QueueInput()) $this->Abort (507, "Queue Failed");
		$this->LoadResponse(); # wait for a new response
		$this->record['cached'] = 0;
		exit ($this->SendResponse()); // return the new response
    }
    //-------------------------------------------------------------------------
	function Abort ($Code, $Text) 
	{
		header ($this->server['SERVER_PROTOCOL']." $Code $Text", true, $Code);
		exit (0);
    }
    //-------------------------------------------------------------------------
	function CheckHeartbeat() 
	{
		$Stat = stat ($this->path."/.Heartbeat");
		if ($Stat === false) return false;
		return ((time() - $Stat[9]) <= 15); // 15 seconds or less
    }
    //-------------------------------------------------------------------------
	function Debug () 
	{
		header("Content-type: text/plain");
		$Year = strftime("%Y");
		print "Nagios Node Client Connector - Copyright (c) Atos SE $Year\n\n";
		print "  User Agent : ".$this->server['HTTP_USER_AGENT']."\n";
		$Info = @file_get_contents ("/opt/Nagios/Node/Nagios/Node/Version.pm");
		if ($Info !== false)
		{
			$Lines = explode ("\n", $Info);
			foreach ($Lines as $Line)
			{
				$Line = explode ("=", trim ($Line), 2);
				if (count ($Line) != 2) continue;
				$Line[0] = explode ("::", $Line[0]);
				if (count ($Line[0]) != 2) continue;
				$Line[0] = trim ($Line[0][1]);
				$Line[1] = trim ($Line[1], " \";");
				if ($Line[0] == "VERSION")   print "  Version    : $Line[1]\n";
				if ($Line[0] == "COPYRIGHT") print "  Copyright  : $Line[1]\n";
			}
		}
		print "  Instance   : ".$this->instance."\n\n";
		return 0;
    }
    //-------------------------------------------------------------------------
	function Help () 
	{
		header("Content-type: text/plain");
		$Year = strftime("%Y");
		print "Nagios Node Client Connector - Copyright (c) Atos SE $Year\n\n";
		print "  Usage:  ?debug[=function]\n";
		return 0;
    }
    //-------------------------------------------------------------------------
    function LoadConfig()
    {
		$File = substr_replace ($this->server["SCRIPT_FILENAME"], "cfg", -3);
		$Config = @parse_ini_file ($File, FALSE, INI_SCANNER_RAW);
		if ($Config === FALSE) $this->Abort (503, "Not Configured");
		foreach ($Config as $Name => $Value)
		{
			if (strtolower ($Name) == "instance")
			{
				$this->instance = $Value;
				return;
			}
			if (substr_compare ($Value, "/var/Nagios/Node/", 0, 17) != 0) continue;
			$Value = explode ("/", $Value);
			$this->instance = $Value[4];
			return;
		}
		$this->Abort (503, "Not Configured");
    }
    //-------------------------------------------------------------------------
    function LoadResponse()
    {
        $File = $this->path."/.Output/".$this->id.".info";
		while ((time() - $this->server['REQUEST_TIME']) <= 15)
		{
			usleep (500000);
			$this->record = @parse_ini_file ($File, false, INI_SCANNER_RAW);
			if ($this->record === false) continue;
			if ($this->client['agent'] == $this->record['agent']) return;
			$this->Abort (504, "Invalid Response");
		}
		$this->Abort (504, "Response Timeout");
    }
    //-------------------------------------------------------------------------
    function Query()
    {
		$Query = explode ("=", $this->server['QUERY_STRING'], 2);
		if ($Query[0] == "command") return $this->QueryCommand ();
		if ($Query[0] == "file")    return $this->QueryFile    ($Query[1]);
		if ($Query[0] == "package") return $this->QueryPackage ($Query[1]);
		$this->Abort (400, "Bad Request");
	}
    //-------------------------------------------------------------------------
    function QueryCommand()
    {
   		$Input = @explode ("\n", @trim (@file_get_contents ("php://input")));
		if (count($Input) < 2) $this->Abort (400, "Bad Request");
		$Info = array ("client"=>$this->client); // already validated
		$Info["argv"] = preg_split ('/\|/', $Input[1]);
		$Info["argc"] = count ($Info["argv"]);
		$Info["user"] = $Input[0];
		$Command = strtolower ($Info["argv"][0]);
		$Select = false;
		$Files = scandir ("/var/www/Nagios/Node/Client/Command");
		foreach ($Files as $File)
		{
			$File = explode (".", strtolower($File));
			if (count($File) < 2) continue;
			if ($File[1] != "php") continue;
			if (strpos ($File[0], $Command) !== 0) continue;
			if ($Select !== false) {
				$this->Abort (400, "Invalid command: use 'help' for the list of commands");
			}
			$Select = ucfirst ($File[0]);
		}
		if ($Select === false) {
			$this->Abort (400, "Invalid command: use 'help' for the list of commands");
		}
		@include_once ("/var/www/Nagios/Node/Client/Command/$Select.php");
		$Class = "\\Nagios\\Node\\Client\\Command_$Select";
		if (! class_exists($Class)) 
		{
			$this->Abort (500, "Failed to load $Class");
		}
		new $Class ($Info);
		return 0;
	}
    //-------------------------------------------------------------------------
    function QueryFile ($File)
    {
		$Path = $this->path."/".$this->client['uuid']."/Files";
		$File = basename ($File);
		if ($File[0] == ".") $this->Abort (404, "Not Found");
		if ($File[0] == "_") $this->Abort (404, "Not Found");
		if (! file_exists ("$Path/$File")) $this->Abort (404, "Not Found");
		if (is_dir("$Path/$File")) $this->Abort (404, "Not Found");
		
		$Data = @file_get_contents ("$Path/$File");
		if ($Data === false) $this->Abort (404, "Not Found");
		$Data = gzencode ($Data);
		$Size = strlen ($Data);

		header ('Content-Type: application/octet-stream');
		header ('Expires: 0');
		header ('Cache-Control: must-revalidate');
		header ('Pragma: public');
		header ('Content-Disposition: attachment; filename="'.$File.'"');
		header ('Content-Length: '.$Size);
		echo $Data;
		return 0;
	}
    //-------------------------------------------------------------------------
    function QueryPackage ($Package)
    {
		$Path = dirname($this->path)."/Packages";
		$Parts = explode ("/", $Package);
		foreach ($Parts as $Part)
		{
			if ($Part[0] == ".") $this->Abort (404, "Not Found");
			if ($Part[0] == "_") $this->Abort (404, "Not Found");
		}
		if (! file_exists ("$Path/$Package")) $this->Abort (404, "Not Found");
		if (is_dir("$Path/$Package")) $this->Abort (404, "Not Found");
		
		$Data = @file_get_contents ("$Path/$Package");
		if ($Data === false) $this->Abort (404, "Not Found");
		$Data = gzencode ($Data);
		$Size = strlen ($Data);

		header ('Content-Type: application/octet-stream');
		header ('Expires: 0');
		header ('Cache-Control: must-revalidate');
		header ('Pragma: public');
		header ('Content-Disposition: attachment; filename="'.$Package.'"');
		header ('Content-Length: '.$Size);
		echo $Data;
		return 0;
	}
    //-------------------------------------------------------------------------
    function QueueInput() {
		// copy the data file to the input queue
		$File = $this->path."/.Input/".$this->id.".data";
		if (! @copy ("php://input", $File)) return false;
		// generate the info record for the info file
        $Info = array (
			'address'  => $this->server['REMOTE_ADDR'],
			'agent'    => trim ($this->server['HTTP_USER_AGENT']),
			'https'    => $this->server['HTTPS'],
			'serial'   => $this->client['serial'],
			'time'     => $this->server['REQUEST_TIME'],
			'token'    => $this->client['token'],
			'protocol' => 'none',
			'cipher'   => 'none'
		);
		// translate extra $_SERVER entries into the info
		foreach (array(
			'REQUEST_TIME_FLOAT' => 'time',
			'SSL_PROTOCOL'       => 'protocol',
			'SSL_CIPHER'         => 'cipher'   
		) as $From => $To) {
			if (array_key_exists ($From, $this->server)) {
				$Info[$To] = $this->server[$From];
			}
		}
		// generate the info file in the input queue
        $File = $this->path."/.Input/".$this->id.".info";
    	$Contents = "";
    	foreach ($Info   as $Name => $Value) $Contents .= "$Name=$Value\n";
		return (@file_put_contents ($File, $Contents, LOCK_EX));
    }
    //-------------------------------------------------------------------------
    function SendResponse()
    {
		if (array_key_exists ("http.status", $this->record))
		{
			$Status = explode ("|", $this->record["http.status"]);
			$this->Abort ($Status[0], $Status[1]);
		}
		header ('Content-Type: application/octet-stream');
		header ('Expires: 0');
		header ('Cache-Control: must-revalidate');
		header ('Pragma: public');
		$Path = $this->path."/".$this->client['uuid'];

		if ($this->client['version'][0] >= 3) // NaCl 3.x and later
		{
			header ('Set-Cookie: token='.strtoupper(md5($this->id)));
			foreach ($this->record as $Name => $Value)
			{
				if ($Name != "") print "$Name=$Value\n";
			}
			print "\n";
			@readfile ("$Path/Config.v".$this->client['version'][0]);
		}
		else // NaCl 1.x and NaCl 2.x
		{
			$File = "$Path/Config.v".$this->client['version'][0].".gz";
			if (file_exists($File))
			{
				$Serial = filectime ($File);
				$Size   = filesize  ($File);
				if ($Serial != $this->client['serial'])
				{
					setcookie ("Serial", $Serial);
					header ('Content-Length: '.$Size);
					@readfile ($File);
					exit (0);
				}
			}
			$Files = @file_get_contents ("$Path/Files.dat");
			if ($Files === false) $Files = "";
			$Files = trim ($Files);
			$Count = 0;
			if ($Files != "") $Count = count (explode ("\n", $Files));
			setcookie ("Files", $Count);
			echo gzencode ("$Files\n[eof]\n");
		}
		//-----------------------------------------------------------------
		return;
    }
    //-------------------------------------------------------------------------
    function Test()
    {
		header("Content-type: text/plain");
		echo "Hello ".$this->server['HTTP_USER_AGENT']."\n";
		echo "Please do NOT share YOUR unique ID with other clients !!!\n";
		return 0;
    }
    //-------------------------------------------------------------------------
	function ValidateClient ($Cookie) 
	{
		$this->client = array
		(
			'agent'   => trim ($this->server['HTTP_USER_AGENT']),
			'name'    => "",
			'path'    => "",
			'serial'  => "0",
			'token'   => "0",
			'uuid'    => "",
			'version' => array (0, 0, 0, 0)
		);
		$Agent = preg_split ("/[\/\s\(\)]+/", trim($this->client['agent'],")"));
		$this->record = false;
		if ($Agent[0] != "NaCl") return false;
		$this->client['version'] = explode (".", $Agent[1]);
		
		if (intval ($this->client['version'][0]) > 2)  // NaCl 3.x and later
		{
			ini_set('zlib.output_compression', 1);
		}
		
		$this->client['name'] = $Agent[2];
		$Uuid = $Agent[3];
		$Test = '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i';
		if (! preg_match($Test, strtolower($Uuid))) return false;
		//$Variant = strtoupper ($Uuid[19]);
		//if ($Variant >= 'E') return false;
		//if ($Variant >= '8') {
		//	$Version = strtoupper ($Uuid[14]);
		//	if (($Version < '1') || ($Version > '5')) return false;
		//}
		$this->client['uuid'] = $Uuid;
		$this->client['path'] = $this->path."/$Uuid";

		foreach (array("Serial","Token") as $Key)
		{
			if (! array_key_exists ($Key, $Cookie)) continue;
			$this->client[strtolower($Key)] = $Cookie[$Key];
		}
		$File = $this->path."/$Uuid/Record.info";
		$this->record = @parse_ini_file ($File, false, INI_SCANNER_RAW);
		if (! is_array ($this->record)) return false;
		if ($this->client['agent'] != $this->record['agent']) return false;
		return true;
    }
    //-------------------------------------------------------------------------
}
//-----------------------------------------------------------------------------
new Connector ($_SERVER, $_COOKIE);
//-----------------------------------------------------------------------------
?>
