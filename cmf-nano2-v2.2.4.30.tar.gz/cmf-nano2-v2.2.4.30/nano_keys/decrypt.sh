#!/usr/bin/env sh

pass=$1;

shift;

for file in "$@"; do
   echo "Decrypting $file...";
   file_plain=`echo $file | sed 's/\.gpg//g'`;
   gpg --batch -o $file_plain --passphrase $pass -d $file; 
done

