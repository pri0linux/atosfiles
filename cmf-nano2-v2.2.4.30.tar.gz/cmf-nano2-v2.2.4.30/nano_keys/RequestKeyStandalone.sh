#!/usr/bin/env bash

NodeId=$1;
Enviroment=$2;
Mode=$3;

if [ "$#" -lt 2 ]; then
  echo "Usage: $0 nodeid prod|cat [verify]";
  echo -e "\tExample: $0 nagios1 cat";
  exit 1;
fi

if [[ "${Mode}" == "verify" ]]; then
  if [ ! -f $NodeId.crt ]; then
    echo "File $NodeId.crt does not exist, place it here.";
    exit 1;
  fi
  CrtId=$(openssl x509 -text -in $NodeId.crt | awk -F'CN=' '/Subject:/ { if($2 != "") {print $2;} }');
  CsrId=$(openssl req -text -in  $NodeId.csr | awk -F'CN=' '/Subject:/ { if($2 != "") {print $2;} }');
  if [[ "${CrtId}" != "${CsrId}" ]]; then
    echo "Error: CSR CN does not match CRT CN, check it again, and place here corect certificate";
    exit 1;
  else
    cat $NodeId.key $NodeId.crt > $NodeId.key.crt;
    mv $NodeId.key.crt $NodeId.key;
    chmod 600 *.crt *.csr *.key;
    echo "Certificate OK!";
    exit 0;
  fi
fi

if [[ "${Enviroment}" == "cat" ]]; then
  subj="/C=NL/ST=Netherlands/O=Atos/OU=Tooling&Monitoring /CN=$NodeId/";
elif [[ "${Enviroment}" == "prod" ]]; then
  subj="/C=NL/O=Atos Origin/OU=Tooling&Monitoring/CN=$NodeId/";
else
  echo "Incorrect env specified.";
  exit 1;
fi

openssl genrsa 1024 > $NodeId.key
openssl req -new -text -key $NodeId.key \
  -subj "${subj}" > $NodeId.csr

cat $NodeId.key $NodeId.csr > $NodeId.key.csr;
mv $NodeId.key.csr $NodeId.key;



#openssl rsa -in $NodeId.key
#openssl req -text -in $NodeId.key
