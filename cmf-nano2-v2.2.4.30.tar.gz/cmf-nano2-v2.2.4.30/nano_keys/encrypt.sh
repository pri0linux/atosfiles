#!/usr/bin/env sh

pass=$1;

shift;

for file in "$@"; do
   echo "Encrypting $file...";
   gpg --batch -o "$file.gpg" --symmetric --cipher-algo AES256 --passphrase "${pass}" --armor "$file"; 
done
