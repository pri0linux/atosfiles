# How to obtain a  key

## Generate CSR and key
```bash
$ ./RequestKeyStandalone.sh
Usage: ./RequestKeyStandalone.sh nodeid prod|cat [verify]
       Example: ./RequestKeyStandalone.sh nagios1 cat
```
Example:
```bash
$ ./RequestKeyStandalone.sh nagios10_cat cat
Generating RSA private key, 1024 bit long modulus (2 primes)
..................................+++++
.....+++++
e is 65537 (0x010001)
```
It should generate two files: `nagios10_cat.csr` and `nagios10_cat.key`.
Keep `nagios10_cat.key` secret. This is your private key.

## Generate certificate using CA
Send your CSR file to owner of CA and ask him to generate
certificate. Usually it is not you who have to generate certificate,
just find appropriate person and make him do it.

But if you have to privilige to be the one who owns CA, then
run this on the server where your CA is placed (as root):
```bash
> openssl x509 -req -days 3600 -in /tmp/nagios10_cat.csr -CA /etc/pki/CA_CAT/cacert.pem -CAkey /etc/pki/CA_CAT/cakey.pem -CAcreateserial -out /tmp/nagios10_cat.crt -sha256  
Signature ok
subject=/C=NL/ST=Netherlands/O=Atos/OU=Tooling&Monitoring /CN=nagios10_cat
Getting CA Private Key
```

Adjust paths to match our enviroment. It will create file `nagios10_cat.crt`.
Copy it back to your machine.

Protip: at the moment of writting this CAT CA is located in `nlctmdx1` and Dawid Sadecki is its father :)

Person who owns production CA is: Peter Hoogendijk, Marco Kranenburg and Willem Weldkamp (order matters!).

## Encrypt key and certificate and store them in repository
When you receive certificate you can verify if it is correct by running command:
```bash
$ ./RequestKeyStandalone.sh nagios10_cat cat verify
Certificate OK!
```

Once you will have certificate you should store it in repository
so CI/CD pipieline would be able to make use of it.

`encrypt.sh` is what you are looking for. It takes passphrase as
first parameter, and it encrypts files provided by 2nd and following
parameters.

You have to use passphrase which is setup in CI/CD pipieline.

Example:
```bash
$ ./encrypt.sh mysupersecretpass nagios10_cat.*
Encrypting nagios10_cat.crt...
Encrypting nagios10_cat.csr...
Encrypting nagios10_cat.key...
```

It generated `nagios10_cat.crt.gpg` `nagios10_cat.key.gpg` and `nagios10_cat.csr.gpg`.

After that you have to remove original, non encrypted files, example:
```bash
rm nagios10_cat.crt nagios10_cat.key nagios10_cat.csr
```

And commit to repository encrypted versions, for example:
```bash
git add nagios10_cat.crt.gpg nagios10_cat.key.gpg nagios10_cat.csr.gpg
git commit -m 'New keys for nagios10_cat'
```

## Deploy
In order to add new NaNo to deploy script you have to edit `../.gitlab-ci.yml` and add new deploy step.

You can inherit from genereic `.deploy` step, so for example just add:
```yaml
deploy_nagios10_cat:
   extends: .deploy
   variables:
      CONTAINER_NAME: "nagios10_cat"
      NACL_UUID: "28602284-5d68-426c-bd1f-00cb754c9900"
```

`CONTAINER_NAME` must match SSL key name, and `NACL_UUID` has to be unique.

Also you have to create new config file for your newly created instance.
You may just copy old one and adjust it if needed, example:
```bash
cp nano_configs/nagios1_cat.cfg nano_configs/nagios10_cat.cfg
vim nano_configs/nagios10_cat.cfg
```

After that just add it to the repository, and push.
```bash
git add .gitlab-ci.yml nano_configs/nagios10_cat.cfg
git commit -m 'New nano instance added'
git push
```
