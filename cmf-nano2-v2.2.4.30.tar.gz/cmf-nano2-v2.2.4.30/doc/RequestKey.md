# RequestKey.pl
```
RequestKey.pl v2.2.3.23 - Copyright (C) Atos SE 2009-2019

  Usage:  RequestKey.pl <instance> [<node-ID>|<CRT-file>]

  - Only specify <instance> to show the key (default instance 'NagiosNode').
  - Specify <node-ID> to generate a Certificate Signing Request (CSR-file).
  - Specify <CRT-file> to install the Certificate from the specified file.

This script is part of the Nagios Node (UMF) software. Only use this script as
instructed by the department responsible for Nagios Node (UMF) Operations.
```

`RequestKey.pl` checks if the key-file contains a CSR and/or a CRT section.

*  If the key-file does not exist and a no parameters are given:
   *  usage information is displayed.
*  If the key-file does not exist and a Nagios Node ID is specified:
   *  it will generate a KEY and a CSR for the specified Nagios Node ID,
   *  store both the KEY and the CSR in the key-file, and the CSR in the csr-file,
   *  and instruct you to mail the csr-file to UMF Operations.
*  If the key-file does not contains a CRT and a crt-file is specified:
   *  it will validate if the specified crt-file matches the CSR in the key-file,
   *  and store both the KEY and the CRT in the key-file (so not the CSR anymore).
*  Otherwise detailed information about the key-file is displayed.

I addition the key-file is validated for use by the NSS library, as this library 
is strict about the format of the key-file. If the format is no correct, it will
give instructions to cleanup the key-file with `RequestKey.pl <instance> cleanup`.
