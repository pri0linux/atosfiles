# `nmon` and `njmon` support

The Nagios Node stores and forwards the `nmon` and `njmon` data collected by the clients to the NMON Server.

## `Nagios::Node::Client::Nmon`

All data uploaded by the clients is processed by `Nagios::Node::Client::Handler`,
where data from NaCl version 3.x is delegated to `Nagios::Node::Client::Handler3`.

This handler passes all `nmon` and `njmon` data to `Nagios::Node::Client::Nmon` causing
the records to be queued in `<var>/Nmon` (grouped in a separate folder per minute).

## `Nagios::Node::Nmon`

To upload the data efficiently to the NMON Server, `Nagios::Node::Nmon` bundles
the records from `<var>/Nmon` in a gzipped file until it has collected 10 MB of
uncompressed data, or until it has processed all queued records.

The gzipped data, together with an info file, is moved into the TMDX Client's
transmit queue (typically `<var>/tmdx/tx`). From here the `Tmdx::Client::Post`
process will take care of the actual transfer of the data via the TMDX Servers.

This process is repeated until the `<var>/Nmon` queue is empty, and starts again
as soon as new records get queued.

## Time-to-live

Data collected at the clients will normally not get lost as long as any outages do not take longer then 24 hours:
*  The client stores the collected data for up to 24 hours if it is unable to upload the data to the Nagios Node.
*  The data queued in `<var>/Nmon` is allowed to stay in the queue for 24 hours from the moment it is queued.
*  The data gets a fresh 'TTL' of 24 hours from the moment it is moved into the TMDX Client's transmit queue.




