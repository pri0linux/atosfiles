# Upload support

Starting with CMF Server 'NaNo' software 2.2.4.28, files can be uploaded by the CMF Client 'NaCl' systems to a central 'upload' server. 
This obviously *does* require CMF Client 'NaCl' software with support for this functionality:

- [NaCl 3.0.3.18 or later for Windows](https://gitlab.cmf.atos-srv.net/repo/nagiosknights/cmf-client/cmf-nacl3w)
- [NaCl 3.0.3.21 or later for Unix/Linux](https://gitlab.cmf.atos-srv.net/repo/nagiosknights/cmf-client/cmf-nacl3x)

Locate the `Upload` directory, a subdirectory of the NaNo data directory. If it doesn't exist, the NaNo version does not implement upload support.

- Files uploaded by the CMF Clients are stored as `Upload/<client-uuid>_<filename>` by the client upload handler.
- The NaNo upload handler queues one of those files per second for upload to a [central 'upload' server](https://gitlab.cmf.atos-srv.net/repo/nagiosknights/cmf-central/cmf-upload).
- Once a file has been queued for upload it is removed from the `Upload` directory.

The upload will use the secure TMDX Client/Server communication mechanism to transfer the files.
The [central 'upload' server](https://gitlab.cmf.atos-srv.net/repo/nagiosknights/cmf-central/cmf-upload)
uses a TMDX Client script to retrieve these files from the TMDX Servers.
