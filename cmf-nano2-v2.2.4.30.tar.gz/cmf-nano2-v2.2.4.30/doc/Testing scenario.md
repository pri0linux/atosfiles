Nagios Node test cases
======================

# Introduction

This document specifies areas of Nagios Node software that should be tested either by manual testing process or automatic tests. Initial version focuses on manual testing so translating this into automatic process may be challenging.

# NaNo features

## Handling communication from Nagios Client (and Command)

This part is done with httpd/php. According to httpd configuration NaCl reaches php script (usually located in /appl/Nagios/Node/www/Client/index.php). This php script first validate the client, next saving the client data to .Input directory and data is processed further by separate perl scripts/daemons. After storing the data php script waits for Response from NaNo software (perl part) and sends this response to client. Such reponse may contain list of files available for the client, afterwards client decides if it wants to download those.
Commands are processed separately, by different PHP scripts. Those are mostly used to setup downtime period from the client. All options of command are described in help (`~/NaCl/Command.pl -C help`) or documentation (HQ3 wiki).

1. **Processing results from clients**  
Choose UUID of the client and check if NaNo files for this Client are up to date (path /var/Nagios/Node/NagiosNode/Client/<UUID>/): Record.info and Record.pds; also check if value of `time` parameter in Record info is current. Next check if host and service status was pushed to nagios - e.g. grep <UUID> in nagios.log and check timestamp. All those timestamp should be at most 2 minutes old.

2. **Processing commands from clients**  
To test this again some NaCl with Command is needed. Most used feature is downtime, so testing this is most important (however other options could be also tested).  

 * Define downtime using Command on client  (`~/NaCl/Command.pl -C downtime all 5m testing`), wait 1 minute to let Nagios process the request (faster on small NaNos)  
 * check if downtime is configured, using Command (`~/NaCl/Command.pl -C downtime`) - result should containt few lines per each service on this client    
 *Note:* there were issues with Command on php7, so preferably this should be tested with both php5 and php7.



## Handling communication from Nagios Headquarters (NaHq) and other components

Headquarters are responsible for preparing configuration for the Nagios, configuration for NaCls and transferring files for ASE (prepared by SecoDB). NaNo should be able to properly process this incoming data. Moreover NaNo should process information from TMDX GW about ticket opening and resolution.

First step of test is to configure new check in CMF GUI for the client that is using this NaNo, e.g. new process check for process `nano_testing`. After translation completes and 10 more minutes (NaHq creating configuration for NaNo and sending this to NaNo, this 10 minutes may vary, depending on load of NaHq):

3. **Providing new objects.cfg to Nagios**  
Find in objects.cfg configured check (there should be block `define service` that contains `nano_testing`). Then search for same definition in status.dat to see if Nagios has started using this new config.

4. **Storing NaCl configuration**  
As we are using different versions of NaCl configuration is stored in all possible formats in `/var/Nagios/Node/NagiosNode/Client/<UUID>/`. Check in 3 files `Config.v[123].gz` if configured check is visible.

5. **Storing ASE configuration**  
Ase configuration (and additional ASE related files, e.g. plugins) are stored in `/var/Nagios/Node/NagiosNode/Client/<UUID>/Files`. Check if `ASEP.cnf` contains configured check. Moreover list of files from `Files` directory that will be provided to client is preprepared and stored in `/var/Nagios/Node/NagiosNode/Client/<UUID>/` in files `Files.dat` (test file) and `Files.pds` (perl format, use `/opt/Nagios/Node/pdxdump.pl Files.pds` to read it) - check in those files if timestamp of ASEP.cnf is updated with current time.

6. **Processing information from TMDX Gateway**  
If check for `nano_testing` process was configured with default options then it should trigger a ticket in ServiceNow. Feedback with ticket number should be provided to NaNo and stored as comment in Nagios (it takes up to 15minutes after new configuration reaches ASE - be patient). So using e.g. `grep INC /var/Nagios/Node/NagiosNode/nagios.log | tail` this information should be found (it is then provided to NaHq and visible in GUI).  

Afterwards please remember to clean-up: remove the check defintion in GUI and resolve the ticket.

## Reporting NaNo status to NaHq
By default every 2 minute (according to crontab entry) NaNo processes `status.dat` file (Nagios part), extracts relevant information and stores to `Status.ref` file, then sends this to NaHq.

7. **Checking if host/services status was gathered and pushed towards NaHq**  
This can be done in CMF GUI by checking timestamp of this NaNo in `Gateways` section if the `Heartbeat` value is current (max few minues old) and also by choosing random host from this NaNo and checking in `Monitored items` section if `Last check` value is current and also checking service on this host, if `Last check` is current (here it could be 10-15 minutes old, as some checks are not executed so often).
This test could be also done locally, by looking for `nano.status` string in `/var/Nagios/Node/NagiosNode/tmdx/log/20210215-post.log` (adjust date) - it should look like:
```
    10:13:12.624 CURL POST https://161.89.118.99/Tmdx/Server/?to=nahq&ttl=300&event=nano.status  
    10:13:13.627     200 OK  
    10:13:13.627     Posted '1613383989.00208746' to 'nahq' via '161.89.118.99' as '0' ...  
```
However this only means that NaNo has sent some status to NaHq, we are not checking the content.
. 

## Creating notification
Initial decision about creating notification/event happens on ASE level (there thresholds are checked), this information comes to NaNo, is pushed to Nagios and Nagios decides to create Notification - due to our configuration Nagios calls `Notify.pl` script that sends notifications to TMDX Gateway (configuration of contact) and to NaHq.  
In fact easiest way to verify this area is to configure some fake check, as described in chapter above.

## Handling NMON/NJMON information
Perform separately whole scenario for NMON and NJMON.
Prerequisite here is to have a client (NaCl) connected to the NaNo that provides Nmon/Njmon data:

1. NaCl 3.0.2.20 for Unix/Linux (not PROD yet, available at [hq3](https://hq3.cmf.myatos.net/Nagios/Downloads/Nagios/Client/Linux/binaries/))
2. having nmon/njmon available on the client (doesn't come with NaCl)
3. configuration for NaCl - see [Nmon.md](https://gitlab.cmf.atos-srv.net/repo/nagiosknights/cmf-client/cmf-nacl3x/-/blob/master/doc/Nmon.md) and [Check/Nmon.md](https://gitlab.cmf.atos-srv.net/repo/nagiosknights/cmf-client/cmf-nacl3x/-/blob/master/doc/Check/Nmon.md) - similarly for Njmon.

There are not additional activities needed on the NaNo level. To test if NaNo is forwarding data to Nmon Server (even if it is not deployed) you can look on TMDX Servers, in directory with data addressed to `nmon` if there is some data (it is `/var/Tmdx/Server/Output/nmon/` (by default this data has 24 hours TTL))

## Auto-update
To be described.

## Special tests
* test case for [issue #48](https://gitlab.cmf.atos-srv.net/repo/nagiosknights/cmf-server/cmf-nano2/-/issues/48) (Fix auto-update package assignment)  
Worthy to test this also before applying fix to confirm that test fails.  
To test this we need:  
    1. client (end-point) that has no *files* assigned (which is not so common, as each ASE config file is a *file* in the NaNo meaning). This can be done by connecting new client (e.g. NaCl re-registration on existing server) and not triggering translation (so not assigning any template/local settings).  
    2. Choose some available packages to assign to a client
    ```
        [nagios@nlcnano1 /] (cat) $ ls /var/Nagios/Node/NagiosNode/Packages/  

        ASE  AU_CAT_test_1.0  AU_Test  file_test_333  perl-Class-Inspector-1.28-2.el7.noarch.rpm  R3D3_monapache  test_file  test_file_2  UMF_RHEL6_x64_NaCl-1.8.0.5_ase-1.05-26.run
    ```
    We need to choose some example package from the result, in my case I choose `file_test_333`.
    3. We need to send request to Headquarters to assign chosen package (point ii) to our client (point i) - this will be done someday by some backend (probably secodb), but for now we need to simulate this somehow. Go to Headquarters server (hopefully CAT), prepare two files with following content:    
    ```
    [nagios@nlcnahq1 rg_requests_client_packages] (cat) $ cat 1614262688.00528598.info
    to: nagios1cat  
    ttl: 60  
    event: nano.request  
    [nagios@nlcnahq1 rg_requests_client_packages] (cat) $ zcat 1614262688.00528598.data  
    client=9659499b-523f-4fc3-a32c-99cc8bcf1250  
    action=client/packages  


    file_test_333  
    ```  
    Be aware that second file `.data` is gzipped (so after preparing text just gzip and rename it). Replace `to:<NaNo>`, `client=<uuid>` and last lines in `.data` file (after two new lines) with chosen package (it can be multiline for more files). It is also important to change filename of both files, so first part (before `.`) is current epoch (make it e.g. ten seconds in the future, usefull command is `date +%s`). Copy both prepared files to `/var/Nagios/Headquarters/tmdx/tx/` so headquarters will send it to chosen Nagios Node.
    Last step is to check if our request to assign the package to the client was processed - check content of `/var/Nagios/Node/NagiosNode/Client/<uuid>/Config.v3` and `Config.v3.gz` if it contains chosen package (should not contain any lines with `file` as this is the prerequisite for this test).
    ```
    [nagios@nlcnano1 9659499b-523f-4fc3-a32c-99cc8bcf1250] (cat) $ tail -2 Config.v3
    package|file_test_333|14|1591619413|0663CAC77B1B0C5E537D867FF76E46B1A77C167B
    [eof]
    [nagios@nlcnano1 9659499b-523f-4fc3-a32c-99cc8bcf1250] (cat) $ zcat Config.v3.gz | tail -2
    package|file_test_333|14|1591619413|0663CAC77B1B0C5E537D867FF76E46B1A77C167B
    [eof]
    ```