# Auto-update support

Auto-update support on the Nagios Nodes offers the following functionality:
*  Replicate the *active* auto-update packages from the TMDX Servers once an hour.
*  Assign packages to Nagios Clients based on 'client/packages' requests from Nagios Headquarters.
*  Provide the Nagios Clients with the list of *assigned* packages and allow them to download these packages.

See the TMDX Server, Nagios Headquarters and Nagios Client 3.x auto-update 
documentation for information how this functionality is implemented there
(Nagios Clients prior to 3.x have no auto-update support).

## Replicating auto-update packages from TMDX Servers

Once an hour [`opt/Nagios/Node/Batch/Hourly/Packages.pm`](../opt/Nagios/Node/Batch/Hourly/Packages.pm)
performs the following tasks:
*  Retrieve the list of available packages from all of the configured TMDX Servers at `https://tmdx.server/Tmdx/Server/Packages.php/Update`.
*  Merge these lists into one list. In case of conflicts the newest entry is used.
*  Load the list of packages present in the `var/<instance>/Packages` directory.
*  Download and validate any new or updated packages from the TMDX Servers via `https://tmdx.server/Tmdx/Server/Packages.php/Update/<package>`.
*  Delete any local packages that are no longer available on the TMDX Servers.
*  Save the list of packages on the Nagios Node in `var/<instance>/Packages.pds` (in perl 'Storable' format).
  
Note that hourly batch jobs start *5 minutes* after every full hour.

## Assigning auto-update packages to Nagios Clients

Whenever a Nagios Node receives a request from Nagios Headquarters:
*  [`opt/Nagios/Node/Receive/Request.pm`](../opt/Nagios/Node/Receive/Request.pm)
delegates this request to [`opt/Nagios/Node/Request.pm`](../opt/Nagios/Node/Request.pm).
*  [`opt/Nagios/Node/Request.pm`](../opt/Nagios/Node/Request.pm) calls `opt/Nagios/Node/Request/<action>.pm`.
*  `client/packages` requests are being handled by [`opt/Nagios/Node/Request/Client/Packages.pm`](../opt/Nagios/Node/Request/Client/Packages.pm).
*  [`opt/Nagios/Node/Request/Client/Packages.pm`](../opt/Nagios/Node/Request/Client/Packages.pm)
saves the list of assigned packages as `var/<instance>/Client/<client>/Packages.acl`.

Every 9 seconds [`opt/Nagios/Node/Client/Configure.pm`](../opt/Nagios/Node/Client/Configure.pm)
checks if any of the client configuration files or the list of packages on the
Nagios Node in `var/<instance>/Packages.pds` has been updated. For all clients 
with updates, `var/<instance>/Client/<client>/config.v3` is updated (only NaCl 
3.x supports auto-update):
*  For each *assigned* package in `var/<instance>/Client/<client>/Packages.acl` the script checks if that package is available in `var/<instance>/Packages.pds`.
*  If it is, an entry for that package is added in `var/<instance>/Client/<client>/config.v3`.
*  Set the timestamp of `var/<instance>/Client/<client>/config.v3` to the time of the newest configuration file that was used to generate it.

## Nagios Client access to assigned auto-update packages

Every time NaCl 3.x posts its results via `https://nagios.node/Nagios/Node/Client/`
or `https://nagios.node/nacc/` (the legacy path), the Nagios Node returns the 
configuration information for that client. For NaCl 3.x this includes the
list of assigned auto-update packages.
If this list contains new or updated packages, the client can download the required 
packages via `https://nagios.node/Nagios/Node/Client/?package=<package>`.
A client should always validate the package size and sha1 before saving the package.


