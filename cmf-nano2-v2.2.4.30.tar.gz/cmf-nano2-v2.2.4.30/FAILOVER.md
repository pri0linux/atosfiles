# Nagios Node Failover Support

This document *includes* the instructions about Nagios Node Failover Support
from the original Nagios Node documentation, but *excludes* all deprecated
information:
- the deprecated method to implement IP address failovers (`keepalived` using `vrrp`).
- the deprecated methods to determine which node is active (`ifconfig` and `ipaddr`).

Nagios Node Failover Support is based on:
- Two Nagios Nodes with the *SAME* key (so *only* request a Nagios Node key *once*).
  After installing the key on one Nagios Node, copy it to the other Nagios Node.
- `rsync` and correctly configured SSH keys, to allow both nodes to synchronize
  the data from the active node to the passive node (see below).
- A third, virtual IP address, that either connects to one node, or connects to the 
  other node. For more details see the description below.
- Nagios Node configuration `failover` and `isactive` settings to let the two Nagios
  Nodes know about each other and about the virtual IP address (see below).

To make sure that both Nodes are operational and there are no network/connection 
issues failover should be forced occasionally, e.g. on daily basis.

## Rsync Data Synchronization 

`rsync` over SSH is used to synchronize the data from the active node to the passive
node. Install `rsync` on both systems from system installation repository, and
configure the SSH keys to allow `rsync` to connect without the need for a password.

- Login as 'nagios' on one of the systems and check for the files '/home/nagios/.ssh/id_dsa' and '/home/nagios/.ssh/id_dsa.pub'. 
- If these files do NOT exist: Use the command 'ssh-keygen -t dsa' to create these files (as user 'nagios' !!!).
- Copy both files to the other system and make sure they are owned by 'nagios' and have mode '0600'.
- On the both systems add the contents of '/home/nagios/.ssh/id_dsa.pub' to the file '/home/nagios/.ssh/authorized_keys'.

> We use `dsa` keys to prevent conflicts with the commonly used `rsa` keys which might already be present on a CMF system.

On *both* systems login as 'nagios' and try to connect with `ssh` to the other
system. This should succeed without a password prompt as the keys will be used. 
If this does NOT succeed first solve the issue before continuing !!!

## Virtual IP Address
A third, virtual IP address, that either connects to one node, or connects to the 
other node is used to allow the clients to connect to the active Nagios Node.

In the past `keepalived` was used for this purpose, but it uses the `vrrp` protocol
but this protocol is now known to be vulnerable so it should not be used anymore.
Some of the possible methods to implement a virtual IP address are currently:
- Pacemaker (used by redhat clustering) offers a �floating ip� feature (be aware
  that other standard features are not needed, eg. common storage or start/stop application). 
- The network team often can deliver a VIP (virtual IP address) as a service (be
  aware that it needs to be very "sticky": do *NOT* use a load balancing mode).

> *ALL* traffic via the virtual IP address must go to *one* node until a full failover
occurs. From that moment on *ALL* traffic must go to the *other* node. After a failover
*FIVE MINUTES* are needed to allow the new active node to get started and synchronize
its state back to the now passive node. During those 5 minutes there should *NOT*
be a failback to the previously active node. If a failback occurs, the Nagios Node
failover pair will *NOT* be available for the remainder of those 5 minutes.
  
Whatever method is chosen to implement a virtual IP address, is *NOT* in scope
of the CMF team: it is a service that is *required* by Nagios Node Failover Support
but this service has to be delivered and managed by *another* team.

## Configuring `NagiosNode.cfg`

Two settings in `NagiosNode.cfg` determine how failover support will function:

#### `failover = <ip-address-of-other-node>`

Configure the *real* IP address of the other Nagios Node. This address will be 
used by `rsync` to synchronize data with the other node. If this setting is NOT
configured, failover support is disabled.

#### `isactive = <isactive-mode>:<virtual-ip-address>`

Configure the way to check whether or not this Nagios Node is the active node.
For external failover support two modes are available:

*  prefered mode `httpsget` will use an HTTPS connection to the failover address
   to check which node is 'at the other end'.
*  alternative mode `httpget` will use an HTTP connection to the failover address
   to check which node is 'at the other end'.

> The old `ifconfig` and `ipaddr` modes are still supported but strongly deprecated.

The `failover-address` should be the *virtual IP address* that will be used by
*all* clients to connect to the Nagios Node failover pair.

## Failover Status

On *both* systems use the command '/opt/Nagios/Node/NagiosNode.pl NagiosNode status':
- On the active node you should see the list of active Nagios Node processes.
- On the passive node should see the output: 'This Nagios Node is not active'.
