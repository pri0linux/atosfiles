#!/usr/bin/env perl
#------------------------------------------------------------------------------
package Nagios::Node;                   # Customized Setup.pl - March 4th, 2019
#------------------------------------------------------------------------------
use strict;
use warnings;
use Cwd;
use File::Basename;
use File::Copy;
use File::Path;
use POSIX;

exit Setup();
#------------------------------------------------------------------------------
# Based on generic Setup.pl v1.0.0.2 but fully customized for Magios Node Setup
#------------------------------------------------------------------------------
sub Setup {
	my ($Setup);
	#----------------------------------------------------------------------
	$Setup = bless ({}, __PACKAGE__);
	$Setup->{msg} = "";
	
	$Setup->LoadSource();
	$Setup->CheckSelinux();
	$Setup->CheckModules();
	$Setup->CheckTools();
	$Setup->LoadTarget();
	$Setup->CheckKey();

    unlink ("$Setup->{dst}/NmonTransport.pl"); # REMOVE OLD VERSION

	print "Installing '$Setup->{dst}/opt-$Setup->{version}'\n";
	$Setup->Install ("$Setup->{src}/opt", "$Setup->{dst}/opt-$Setup->{version}");
	print "Installing '$Setup->{dst}/www-$Setup->{version}'\n";
	$Setup->Install ("$Setup->{src}/www", "$Setup->{dst}/www-$Setup->{version}");

	print "Updating the symlinks for version $Setup->{version}\n";
	$Setup->Symlink ("opt", "opt-$Setup->{version}");
	$Setup->Symlink ("www", "www-$Setup->{version}");
	die ("\nSetup aborted !!!\n\n") if (! $Setup->Configure());
	
	if ($Setup->{msg} eq "") {
		$Setup->{msg} = "$Setup->{name} v$Setup->{version} Setup finished successfully\n";
	  print "$Setup->{msg}\n";
  }
  else {
	  print STDERR "$Setup->{msg}\n";
  }
	#----------------------------------------------------------------------
	return 0;
}
sub CheckFolder {
	my ($Setup, $Root, $Dir) = @_;
	my ($Folder, $Link, $Linkdir, $Current);
	#--------------------------------------------------------------------
	$Folder = "$Setup->{dst}/$Dir";
	if (! -d $Folder) {
		print "Creating target directory '$Folder'\n";
		unlink ($Folder);
		eval { mkpath ($Folder); };
		if ($@)
		{
			print STDERR "    ERROR creating directory: $!\n";
			$Setup->{err}++;
			return;
		}
	}
	else {
		print "Checking target directory '$Folder'\n";
	}
	if (! chown ($Setup->{uid}, $Setup->{gid}, $Folder)) {
		print STDERR "    ERROR changing owner: $!\n";
		$Setup->{err}++;
	}
	if (! chmod (0750, $Folder)) {
		print STDERR "    ERROR changing mode: $!\n";
		$Setup->{err}++;
	}
	#----------------------------------------------------------------------
	$Link    = "$Root/$Setup->{path}";
	$Linkdir = dirname ($Link);
	if (! -d $Linkdir) {
		if ($>) {
			print STDERR "    ERROR creating '$Linkdir'\n";
			$Setup->{err}++;
			return;
		}
		print "    Creating directory '$Linkdir'\n";
		unlink ($Linkdir);
		eval { mkpath ($Linkdir); };
		if ($@) {
			print STDERR "    ERROR creating directory: $!\n";
			$Setup->{err}++;
			return;
		}
	}
	chown ($Setup->{uid}, $Setup->{gid}, $Linkdir); # Best effort, no error
	chmod (0755, $Linkdir);  # Best effort, no error
	#----------------------------------------------------------------------
	if (-l $Link) {
		$Current = readlink ($Link);
		return if ($Current eq $Folder);
		if ($>) {
			print STDERR "    ERROR changing '$Link'\n";
			$Setup->{err}++;
			return;
		}
		unlink ($Link);
	}
	if ($>) {
		print STDERR "    ERROR creating '$Link'\n";
		$Setup->{err}++;
		return;
	}
	print "    Creating symlink '$Link'\n";
	eval { symlink ($Folder, $Link) || die(); };
	if ($@) {
		print STDERR "    ERROR creating symlink: $!\n";
		$Setup->{err}++;
		return;
	}
	#----------------------------------------------------------------------
	return;
}
sub CheckHttpd {
	my ($Setup) = @_;
	my ($Rpm, $File, $Ssl, $User, $Handle, $Line, @Group);
	my ($Httpd, $Httpd_exec, $Httpd_root, $Httpd_config, $Httpd_config_additional);
	my (@Members, $IsMember, $Member, $Link, $Current);
	#--------------------------------------------------------------------
	print "Checking the httpd configuration ...\n";
	$Httpd_exec = `which httpd`;
	if ( ! $Httpd_exec ) { 
	    ($Httpd_exec) = `ps -eo args | cut -d' ' -f1 | grep -E "httpd|apache" | grep -v grep `;
	}
	die ("\nhttpd not found: the 'httpd' package MUST be installed !!!\n\n") if (! $Httpd_exec);
	chomp ($Httpd_exec);
	($Httpd) = `$Httpd_exec -v 2>/dev/null`;
	chomp ($Httpd); (undef, $Httpd) = split (/:\s*/, $Httpd, 2);
	print "    Found $Httpd\n";
	($Httpd) = ($Httpd =~ /[^\.](\d+\.\d+)/);
	die ("\nUnable to determine httpd version\n\n") if (! $Httpd);
	$File = "$Setup->{src}/etc/httpd-$Httpd.conf";
	die ("\nUnsupported version: httpd-$Httpd (needs 'etc/httpd-$Httpd.conf')\n") if (! -r $File);
	$Setup->{httpd} = $Httpd = "httpd-$Httpd";
	if (! $>) {
		($Ssl) = `$Httpd_exec -M | grep ssl 2>/dev/null`;
		die ("\nhttpd ssl module not found: the httpd ssl module MUST be installed !!!\n\n") if (! $Ssl);
		$Ssl =~ s/^\s+//; $Ssl =~ s/\s+$//;
		print "    Found $Ssl\n";
	}
	#--------------------------------------------------------------------
	$Httpd_root   = `$Httpd_exec -V | grep _ROOT | cut -d'"' -f2`;
	$Httpd_config = `$Httpd_exec -V | grep SERVER_CONFIG_FILE | cut -d'"' -f2`;
	chomp ($Httpd_root, $Httpd_config);
	$File         = "$Httpd_root/$Httpd_config";
	$User = undef;
	open ($Handle, $File) || die ("\nUnable to read '$File': $!\n\n");
	while ($Line = <$Handle>) {
		if ($Line =~ /^\s*User\s/) {
		    ($User) = ($Line =~ /^\s*User\s+(\S+)/);
		}
        elsif ($Line =~ /^\s*Include(Optional)?\s+\S*conf\.d/) {
            (undef,$Httpd_config_additional) = ($Line =~ /^\s*Include(Optional)?\s+(\S*conf\.d\S*)/);
        }
        elsif ($Line =~ /^\s*Include(Optional)?\s+\S*extra/) {
            (undef,$Httpd_config_additional) = ($Line =~ /^\s*Include(Optional)?\s+(\S*extra\S*)/);
        }
        elsif ($Line =~ /^\s*Include(Optional)?\s+\S*enabled/) {
            (undef,$Httpd_config_additional) = ($Line =~ /^\s*Include(Optional)?\s+(\S*enabled\S*)/);
        }
		else {
		    next;
		}
	}
	close ($Handle);
	print "    httpd is running as user '$User'\n";
	if (! $>) { 
		print "    Adding user '$User' to group '$Setup->{group}'\n";
		$IsMember = `usermod -a -G $Setup->{group} $User 2>&1`; 
		$IsMember =~ s/^\s+//; $IsMember =~ s/\s+$//;
		print "    $IsMember\n" if ($IsMember ne "");
	}
	@Group = getgrgid ($Setup->{gid});
	@Members = split (/\s+/, $Group[3]);
	$IsMember = 0;
	foreach $Member (@Members) { $IsMember++ if ($User eq $Member); }
	if (! $IsMember) {
		print STDERR "    ERROR adding '$User' to group '$Setup->{group}': please run setup as 'root'\n";
		$Setup->{err}++;
		return;
	}
	print "    User '$User' is a member of group '$Setup->{group}'\n";
	#--------------------------------------------------------------------
	if ( $Httpd_config_additional ) {
	    #relative or absolute path
	    if ( $Httpd_config_additional =~ /^\// ) {
	        $Httpd_config_additional = dirname ($Httpd_config_additional);
	    }
	    else {
	        $Httpd_config_additional = $Httpd_root . "/" . dirname ($Httpd_config_additional);
	    }
	    print "    httpd configs directory chosen as '$Httpd_config_additional'\n";
	}
	else {
	    die ("No Include directive in apache config file, so apache won't include NagiosNode conf. Ask OS team to add Include to $Httpd_root/$Httpd_config");
	}
	$File = "$Setup->{path}.conf";
	$File =~ s/\///g;
	$Link = "$Httpd_config_additional/$File";
	$File = "/etc/$Setup->{path}/$Httpd.conf";
	if (-l $Link) {
		$Current = readlink ($Link);
		return if ($Current eq $File);
		if ($>) {
			print STDERR "    ERROR changing '$Link': please run setup as 'root'\n";
			$Setup->{err}++;
			return;
		}
		unlink ($Link);
	}
	if ($>) {
		print STDERR "    ERROR creating '$Link': please run setup as 'root'\n";
		$Setup->{err}++;
		return;
	}
	if (! -r $File) {
		print "    Installing 'etc/$Httpd.conf'\n";
		if (! copy ("$Setup->{src}/etc/$Httpd.conf", $File))
		{
			print STDERR "    ERROR copying file : $!\n";
			$Setup->{err}++;
			return;
		}
		chown ($Setup->{uid}, $Setup->{gid}, $File);
		chmod (0640, $File);
	}
	print "    Creating symlink '$Link'\n";
	eval { symlink ($File, $Link); };
	if ($@) {
		print STDERR "    ERROR creating symlink: $!\n";
		$Setup->{err}++;
		return;
	}
	system ("service httpd restart");
	#--------------------------------------------------------------------
	return;
}
sub CheckKey {
	my ($Setup) = @_;
	my ($File, $Key, $Crt, $Id, $Handle, $Data);
	#--------------------------------------------------------------------
	$File = "$Setup->{dst}/etc/NagiosNode.key";
	return if (! -r $File);
	print "Checking if the existing KEY-file is clean\n";
	$Key = `openssl rsa -in $File 2>/dev/null`; chomp $Key;
	$Crt = `openssl x509 -text -in $File 2>/dev/null`; chomp $Crt;
	($Id) = ($Crt =~ /\sCN=(\w+)\s*\n/);
	open ($Handle, $File) || die ("Error reading '$File': $!\n");
	$Data = do { local $/ = <$Handle>; }; close ($Handle);
	return if ($Data eq "$Key\n$Crt\n");
	print "    Cleaning '$File' ('$Id')\n";
	move ($File, "$File.dirty") || die ("Error moving key: $!\n");
	open ($Handle, ">$File") || die ("Error writing key: $!\n");
	print $Handle "$Key\n";
	print $Handle "$Crt\n";
	close $Handle;
	chmod (0600, $File);
	print "    The KEY-file has been updated to be acceptable by the NSS library.\n";
	print "    The original KEY-file has been saved as 'NagiosNode.key.dirty'.\n";
	#--------------------------------------------------------------------
	return;
}
sub CheckModules {
	my ($Setup) = @_;
	my ($Error, $Module, $Version);
	#--------------------------------------------------------------------
	print "Checking if the required perl modules are available\n";
	$Error = 0;
	foreach $Module (sort keys %{$main::MODULES}) {
		eval ("require $Module;"); 
		if ($@) {
			$Version = $main::MODULES->{$Module};
			$Version = "module" if (! defined $Version);
			print STDERR "!!! $Module ($Version is required) !!!\n";
			$Error++;
			next;
		}
		$Version = undef;
		eval ("\$Version = \$$Module\::VERSION;");
		$Version = "" if (! defined $Version);
		if (! defined $main::MODULES->{$Module}) {
			print "    $Module $Version\n";
			next;
		}
		if (($Version =~ /^\d+\.\d+$/) && ($main::MODULES->{$Module} =~ /^\d+\.\d+$/)) {
			if ($Version >= $main::MODULES->{$Module}) {
				print "    $Module $Version\n";
				next;
			}
		}
		print STDERR "!!! $Module $Version (".$main::MODULES->{$Module}." is required) !!!\n";
		$Error++;
	}
	if ($Error) {
		print STDERR "\nSetup aborted !!!\n\n";
		exit (2);
	}
	#--------------------------------------------------------------------
	return;
}
sub CheckNacc {
	my ($Setup) = @_;
	my ($Path, $Link);
	#--------------------------------------------------------------------
	print "Checking the /var/www/html/nacc symlink ...\n";
	$Path = "$Setup->{dst}/www";
	$Link = "/var/www/html/nacc";
	if (-l $Link) {
		return if (readlink ($Link) eq $Path);
		if ($>) {
			print STDERR "    ERROR changing '$Link'\n";
			$Setup->{err}++;
			return;
		}
		unlink ($Link);
	}
	if ($>) {
		print STDERR "    ERROR creating '$Link'\n";
		$Setup->{err}++;
		return;
	}
	print "    Creating symlink '$Link'\n";
	rmtree ($Link) if (-d $Link);
	unlink ($Link) if (-r $Link);
	eval { symlink ($Path, $Link) || die(); };
	if ($@) {
		print STDERR "    ERROR creating symlink: $!\n";
		$Setup->{err}++;
		return;
	}
	#--------------------------------------------------------------------
	return;
}
sub CheckSelinux {
	my ($Setup) = @_;
	my (@Status, $Status, $Line, @Line);
	#--------------------------------------------------------------------
	print "Checking SELinux ...\n";
	@Status = `sestatus 2>/dev/null`;
	$Status = {};
	foreach $Line (@Status) {
		$Line =~ s/^\s+//;
		$Line =~ s/\s+$//;
		@Line = split (/\s*\:\s*/, $Line, 2);
		next if ($#Line != 1);
		$Status->{lc $Line[0]} = lc $Line[1];
	}
	return if (! exists $Status->{'selinux status'});
	if ($Status->{'selinux status'} eq "disabled") {
		print "    SELinux status: $Status->{'selinux status'}\n";
		return;
	}
	#--------------------------------------------------------------------
	if ((exists $Status->{'current mode'}) && (exists $Status->{'mode from config file'})) {
		print "    SELinux status:        $Status->{'selinux status'}\n";
		print "    Current mode:          $Status->{'current mode'}\n";
		print "    Mode from config file: $Status->{'mode from config file'}\n";
		if (($Status->{'current mode'} ne "permissive") || ($Status->{'mode from config file'} ne "permissive")) {
			print STDERR "\nSELinux MUST be in permissive mode !!!\n";
			print STDERR "Setup aborted !!!\n\n";
			exit (2);
		}
	}
	else { print STDERR "\n    Unable to determine SELinux mode\n"; }
	#--------------------------------------------------------------------
	return;
}		
sub CheckTools {
	my ($Setup) = @_;
	my ($Error, $Tools, @Tools, $Serials, @Found, @Missing, $t, $Tool);
	my ($Binary, $Line, $Version, @Version, $Serial);
	#--------------------------------------------------------------------
	print "Checking if the required system tools are available\n";
	$Error = 0;
	foreach $Tools (sort keys %{$main::TOOLS}) {
		@Tools   = split (/\|/, $Tools);
		$Serials = $main::TOOLS->{$Tools};
		$Serials = [$Serials] if (ref($Serials) ne "ARRAY");
		@Found   = ();
		@Missing = ();
		for ($t = 0; $t <= $#Tools; $t++) {
			$Tool   = $Tools[$t];
			$Binary = `which $Tool 2>/dev/null`; 
			chomp $Binary;
			$Tool  .= " '$Serials->[$t]'" if (defined $Serials->[$t]);
			if ($Binary) {
				if ($Binary =~ /openssl/i) { 
					($Line) = `$Binary version 2>/dev/null`;
				}
				else {
					($Line) = `$Binary -V 2>/dev/null`;
				}
				$Line = "" if (! defined $Line);
				($Version) = ($Line =~ /(\d[\d\.]+\d)/);
				if (defined $Version) {
					@Version = split (/\./, $Version);
					push (@Version, 0, 0, 0);
					$Serial = sprintf ("%d%03d%03d", @Version);
				}
				else { 
					$Version = "?.?";
					$Serial = 0; 
				}
				print "    Found $Binary $Version ('$Serial')\n";
				if (! defined $Serials->[$t]) {
					push (@Found, $Tool);
					next;
				}
				if ($Serials->[$t] <= $Serial) {
					push (@Found, $Tool);
					next;
				}
			}
			push (@Missing, $Tool);
		}
		next if ($#Found >= 0);
		print STDERR "!!! ".join(" or ",@Missing)." is required !!!\n";
		$Error++;
	}
	if ($Error) {
		print STDERR "\nSetup aborted !!!\n\n";
		exit (2);
	}
	#--------------------------------------------------------------------
	return;
}		
sub Configure {
	my ($Setup) = @_;
	my ($Link, $Path, @Data, $Line, $Data, $Plugins, $Atos, $Handle);
	my (@Files, $File, @Check, @Pids, $Module, $Pid, $Cmd, $Try);
	#--------------------------------------------------------------------
	# Locate the Nagios binary
	#--------------------------------------------------------------------
	print "Locating the Nagios binary\n";
	$Link = "$Setup->{dst}/opt/nagios";
	unlink ($Link) if (-l $Link);
	rmtree ($Link) if (-d $Link);
	unlink ($Link) if (-r $Link);
    foreach $Path ("/appl/Nagios/Node/nagios", "/usr/bin/nagios","/usr/sbin/nagios") {
		next if (! -x $Path);
		print "    $Link => $Path\n";
		symlink ($Path, $Link) || die ("  $!\n");
		last;
    }
	if (-x $Link) {
		@Data = `$Link`;
		$Line = undef;
		while (($#Data >= 0) && (! $Line)) { $Line = shift @Data; chomp $Line; }
		$Line =~ s/[^\d\.]//g;
		if ($Line !~ /^3/) {
			print STDERR "    Nagios $Line is not supported: Nagios 3.x is required\n";
			unlink ($Link);
		}  
	}
	if (! -x $Link) {
		print STDERR "\nPlease install Nagios 3.x or provide a symlink at '/appl/Nagios/Node/nagios'\n";
		print STDERR "Setup aborted !!!\n\n";
		exit (2);
	}
	#--------------------------------------------------------------------
	# Locate the Nagios Plugins directory
	#--------------------------------------------------------------------
	$Plugins = "/usr/lib64/nagios/plugins";
	$Plugins = "/usr/lib/nagios/plugins"     if (! -d $Plugins);
	$Plugins = "/appl/Nagios/Plugins/Nagios" if (! -d $Plugins);
	$Plugins = "/appl/Nagios/Plugins/nagios" if (! -d $Plugins);
	if (! -d $Plugins) {
		print STDERR "\nNagios plugins not found: please install the Nagios plugins first\n"; 
		print STDERR "Setup aborted !!!\n\n";
		exit (2);
	}
	$Plugins = Cwd::abs_path ("$Plugins/.");
	$Atos = "";
	$Atos = readlink "$Plugins/Atos" if (-l "$Plugins/Atos");
	if ($Atos eq "") { # Should never happen here !!!
		print STDERR "\nThe Nagios/Atos plugins symlink is missing\n";
		print STDERR "Setup aborted !!!\n\n";
		exit (2);
	}
	#--------------------------------------------------------------------
	# Adjust the links to the nagios Plugins directory
	#--------------------------------------------------------------------
	print "Updating the symlinks to '$Plugins'\n";
	if (! -d $Atos) {
		print "    Creating '$Atos/'\n";
		mkpath ($Atos) || die ("$!\n"); # Should never fail !!!
	}
	chmod (0750, "/appl/Nagios/Plugins", $Atos);
	foreach $Link ("/appl/Nagios/Plugins/Nagios", "/appl/Nagios/Plugins/nagios", "$Setup->{dst}/opt/plugins") {
		print "    $Link => $Plugins/\n";
		next if (Cwd::abs_path($Link) eq $Plugins);
		if (-l $Link) {
			$Path = readlink ($Link);
			next if ($Path eq $Plugins);
			unlink ($Link);
		}
		else {
			rmtree ($Link) if (-d $Link);
			unlink ($Link) if (-r $Link);
		}
		symlink ($Plugins, $Link) || die("$!\n"); # Should never fail !!!
	}
	#--------------------------------------------------------------------
	# Relocate the NaCl Plugins
	#--------------------------------------------------------------------
	$Link = "/home/nagios/NaCl/plugins/Atos";
	if (-d $Link) {
		if (Cwd::abs_path("$Link/.") ne Cwd::abs_path("$Atos/.")) {
			print "Moving '$Link/*' to '$Atos/*'\n";
			`mv -f $Link/* $Atos >/dev/null 2>&1`;
		}
	}	
	$Link = "/home/nagios/NaCl/plugins";
	if (-d $Link) {
		if (Cwd::abs_path("$Link/.") ne Cwd::abs_path("$Plugins/.")) {
			print "    $Link => $Plugins/\n";
			unlink ($Link) if (-l $Link);
			rmtree ($Link) if (-d $Link);
			unlink ($Link) if (-r $Link);
			symlink ($Plugins, $Link) || die("$!\n");
		}
	}	
	#--------------------------------------------------------------------
	# Create the CheckNagiosNode.pl symlink
	#--------------------------------------------------------------------
	print "Creating the 'ChecknagiosNode.pl' and 'Notify.pl' symlinks\n";
	foreach $Link ("$Atos/CheckNagiosNode.pl", "/opt/Nagios/Node/CheckNagiosNode.pl", "/opt/Nagios/Node/Notify.pl") {
		unlink ($Link) if (-l $Link);
		rmtree ($Link) if (-d $Link);
		unlink ($Link) if (-r $Link);
		print "    $Link => /opt/Nagios/Node/NagiosNode.pl\n";
		symlink ("/opt/Nagios/Node/NagiosNode.pl", $Link) || die ("  $!\n"); # Should never fail !!!
	}
	#--------------------------------------------------------------------
	# Check the configuration directory
	#--------------------------------------------------------------------
	print "Checking '$Setup->{dst}/etc/'\n";
	if (! opendir ($Handle, "$Setup->{src}/etc")) {
		print STDERR "    ERROR reading directory: $!\n"; # Should never fail !!!
		return 0;
	}
	@Files = sort readdir ($Handle);
	closedir ($Handle);
	foreach $File (@Files) {
		next if ($File =~ /^\.+$/);
		next if (-r "$Setup->{dst}/etc/$File");
		print "    $Setup->{dst}/etc/$File\n";
		if (! copy ("$Setup->{src}/etc/$File", "$Setup->{dst}/etc/$File")) {
			print STDERR "    ERROR copying file : $!\n"; # Should never fail !!!
			$Setup->{err}++;
		}
	}
	return 0 if $Setup->{err};
	#--------------------------------------------------------------------
	# Check the webserver configuration
	#--------------------------------------------------------------------
	print "Checking '$Setup->{dst}/etc/$Setup->{httpd}.conf'\n";
	if (! open ($Handle, "$Setup->{src}/etc/$Setup->{httpd}.conf")) {
		print STDERR "    ERROR reading '$Setup->{src}/etc/$Setup->{httpd}.conf' : $!\n"; 
		return 0;
	}
	$Data[0] = join ("", (<$Handle>));
	close ($Handle);
	if (! open ($Handle, "$Setup->{dst}/etc/$Setup->{httpd}.conf")) {
		print STDERR "    ERROR reading '$Setup->{dst}/etc/$Setup->{httpd}.conf' : $!\n";
		return 0;
	}
	$Data[1] = join ("", (<$Handle>));
	close ($Handle);
	if ($Data[0] ne $Data[1]) {
		print "    $Setup->{dst}/etc/$Setup->{httpd}.conf\n";
		if (! copy ("$Setup->{src}/etc/$Setup->{httpd}.conf", "$Setup->{dst}/etc/$Setup->{httpd}.conf")) {
			print STDERR "    ERROR copying file : $!\n";
			return 0;
		}
		$Setup->{msg} .= "Restart 'httpd' to finish the installation ('service httpd restart') !!!\n";
	}
	#--------------------------------------------------------------------
	# Check for the required crontab entries
	#--------------------------------------------------------------------
	@Data = `crontab -l`;
	@Check = (0,0,0);
	foreach $Line (@Data) {
		$Check[0]++ if ($Line =~ /^\s*\*\/?\d?\s+\*\s+\*\s+\*\s+\*\s+\/opt\/$Setup->{path}\/cronjob.sh/);
		$Check[1]++ if ($Line =~ /^\s*\*\/?\d?\s+\*\s+\*\s+\*\s+\*\s+\/opt\/$Setup->{path}\/NagiosNode.pl\s+NagiosNode/);
		$Check[2]++ if ($Line =~ /^\s*\*\/?\d?\s+\*\s+\*\s+\*\s+\*\s+\/opt\/$Setup->{path}\/NmonTransport.pl/);
	}
	if ($Check[0] || $Check[2]) {
		$Setup->{msg} .= "Please REMOVE the following line(s) from the '$Setup->{user}' crontab:\n\n";
		if ($Check[0]) {
            $Setup->{msg} .= "    * * * * * /opt\/$Setup->{path}\/cronjob.sh ...\n";
        }
		if ($Check[2]) {
            $Setup->{msg} .= "    * * * * * /opt\/$Setup->{path}\/NmonTransport.pl ...\n";
        }
		$Setup->{msg} .= "\n";
	}
	if (! $Check[1]) {
		$Setup->{msg} .= "Please add the following line(s) to the '$Setup->{user}' crontab:\n\n";
		if (! $Check[1]) {
			$Setup->{msg} .= "    * * * * * /opt\/$Setup->{path}\/NagiosNode.pl NagiosNode >/dev/null 2>&1 &\n";
		}
		$Setup->{msg} .= "\n";
	}
	#--------------------------------------------------------------------
	# Restart all processes
	#--------------------------------------------------------------------
	print "Checking for active $Setup->{name} processes\n";
	@Files = `ls /var\/$Setup->{path}/*.pid /var\/$Setup->{path}/*/*.pid /var\/$Setup->{path}/*/*/*.pid 2>/dev/null`;
	@Pids  = ();
	foreach $File (sort @Files) {
		chomp ($File);
		$Pid  = `cat $File`;
		chomp ($Pid);
		next if ($Pid !~ /^\d+$/);
		$Module = basename(dirname($File));
		$File = basename($File);
		$File =~ s/\.pid$//;
		$Cmd  = `cat /proc/$Pid/cmdline 2>/dev/null`;
		$Cmd  =~ s/\0/ /g;
		next if (($Cmd !~ /^$Setup->{name}\(/) && ($Cmd !~ /^\/opt\/$Setup->{path}\//));
		next if ($File eq "nagios");
		print "    Process $Pid: $Module/$File\n";
		push (@Pids, $Pid);
	}
	if (kill (0, @Pids)) {
		print "Stopping all $Setup->{name} processes ...\n" if ($#Pids >= 0);
		for ($Try = 10; $Try > 0; $Try--)
		{
			$Pid = kill (($Try>1)?-6:-9, @Pids) + kill (($Try>1)?6:9, @Pids);
			if (! $Pid) {
				print "    All $Setup->{name} processes have been stopped\n";
				last;
			}
			print "    Trying to ".(($Try>1)?"stop":"kill")." all processes ...\n";
			sleep (1);
		}
		`killall curl 2>&1`; `killall wget 2>&1`; # just to make sure ...
	}
	if (! -r "/etc/Nagios/Node/NagiosNode.key") {
		print "\n    Use '/opt/Nagios/Node/RequestKey.pl' to request a key for this Node\n";
		print "    or install an existing key-file as '/etc/Nagios/Node/NagiosNode.key'.\n\n";
		return 1;
	}
	print "Restarting all $Setup->{name} processes ...\n\n    Check the logfiles for any issues !!!\n\n";
	system ("/opt/Nagios/Node/NagiosNode.pl NagiosNode");
	if ($? == -1) {
        print STDERR "Failed to execute NagiosNode.pl: $!\n";
    }
    elsif ($? & 127) {
        printf STDERR "NagiosNode.pl died with signal %d, %s coredump\n",
            ($? & 127),  ($? & 128) ? 'with' : 'without';
    }
    else {
		  return 1 if (! ($? >> 8));
    }	
	#--------------------------------------------------------------------
	return 0;
}
sub Dump {
	my ($Setup, @Dump) = @_;
	#--------------------------------------------------------------------
	require Data::Dumper;
	$Data::Dumper::Sortkeys = 1; $Data::Dumper::Sortkeys = 1;
	print Data::Dumper->Dump (@Dump);
	#--------------------------------------------------------------------
	return;
}
sub Install {
	my ($Setup, $Src, $Dst) = @_;
	my ($Mode, $Handle, @Files, $File);
	#--------------------------------------------------------------------
	if (! -d $Src) {
		print "    $Dst\n";
		if (! copy ($Src, $Dst)) {
			print STDERR "    ERROR copying file : $!\n";
			$Setup->{err}++;
			return;
		}
		$Mode = 0640;
		$Mode = 0750 if ($Dst =~ /\.pl$/);
		chmod ($Mode, $Dst);
		return;
	}
	#--------------------------------------------------------------------
	print "    $Dst/\n";
	if (-r $Dst) {
		unlink ($Dst) if (! -d $Dst);
		`rm -rf $Dst/*` if (-d $Dst);
	}
	if (! -d $Dst) {
		eval { mkpath ($Dst); };
		if ($@) {
			print STDERR "    ERROR creating directory: $!\n";
			$Setup->{err}++;
			return;
		}
		chmod (0750, $Dst);
	}
	if (! opendir ($Handle, $Src)) {
		print STDERR "    ERROR reading '$Src': $!\n";
		$Setup->{err}++;
		return;
	}
	@Files = sort readdir ($Handle);
	closedir ($Handle);
	foreach $File (@Files) {
		next if ($File =~ /^\.+$/);
		$Setup->Install ("$Src/$File", "$Dst/$File");
	}
	#--------------------------------------------------------------------
	return;
}
sub LoadSource {
	my ($Setup) = @_;
	my ($File, @Uname, $Release);
	#--------------------------------------------------------------------
	$Setup->{src}  = dirname (Cwd::abs_path ($0));
	$Setup->{name} = __PACKAGE__;
	$Setup->{path} = join ("/", split (/\:\:/, __PACKAGE__));
	$File = "$Setup->{src}/opt/$Setup->{path}/Version.pm";
	if (! -r $File) {
		print STDERR "Missing 'opt/$Setup->{path}/Version.pm'\n";
		print STDERR "Setup aborted !!!\n\n";
		exit (2);
	}
	require "$File";
	$Setup->{version}   = $main::VERSION   = $main::VERSION;   # Hack to keep perl happy ...
	$Setup->{copyright} = $main::COPYRIGHT = $main::COPYRIGHT;
	print "------------------------------------------------------------------------------\n";
	print "$Setup->{name} v$Setup->{version} Setup - Copyright $Setup->{copyright}\n";
	print "------------------------------------------------------------------------------\n";
	@Uname = POSIX::uname();
	if ($Uname[4] ne "x86_64") {
		print STDERR "$Setup->{name} needs an 'x86_64' system to function correctly.\n";
		print STDERR "Setup aborted !!!\n\n";
		exit (2);
	}
	$Release = `cat /etc/redhat-release 2>/dev/null`;
	($Release) = ($Release =~ /(\d+\.\d+)/);
	$Release = "0.0" if (! defined $Release);
	if (($Release < 6.0) || ($Release >= 8.0)) {
		print STDERR "$Setup->{name} needs a RHEL 6.x or 7.x system to function correctly.\n";
		print STDERR "Setup aborted !!!\n\n";
		exit (2);
	}
	#--------------------------------------------------------------------
	$Setup->{user} = $main::USER = $main::USER;
    (undef, undef, $Setup->{uid}, $Setup->{gid}) = getpwnam ($Setup->{user});
	die ("User '$Setup->{user}' does not exist.\n\n") if (! $Setup->{uid});
	($Setup->{group}) = getgrgid ($Setup->{gid});
	if (($>) && ($< != $Setup->{uid})) {
		print STDERR "Setup MUST be run as user 'root' or as user '$Setup->{user}'.\n";
		print STDERR "Setup aborted !!!\n\n";
		exit (2);
	}
	#--------------------------------------------------------------------
	return;
}
sub LoadTarget {
	my ($Setup) = @_;
	my ($Root, $Plugins, @Stat, $Atos);
	#--------------------------------------------------------------------
	# Check for the /appl/Nagios directory and the Nagios plugins
	#--------------------------------------------------------------------
	$Setup->{err} = 0;
	$Setup->{dst} = "/appl/$Setup->{path}";
	$Root = dirname ($Setup->{dst});
	if (! -d $Root) {
		print STDERR "Target volume '$Root' not found: please create this volume first!\n";
		$Setup->{err}++;
	}
	$Plugins = "/usr/lib64/nagios/plugins";
	$Plugins = "/usr/lib/nagios/plugins"     if (! -d $Plugins);
	$Plugins = "/appl/Nagios/Plugins/Nagios" if (! -d $Plugins);
	$Plugins = "/appl/Nagios/Plugins/nagios" if (! -d $Plugins);
	if (! -d $Plugins) {
		print STDERR "Nagios plugins not found: please install the Nagios plugins first!\n";
		$Setup->{err}++;
	}
	if ($Setup->{err}) {
		print STDERR "Setup aborted !!!\n\n";
		exit (2);
	}
	#--------------------------------------------------------------------
	# Check the /appl/Nagios/Node directory
	#--------------------------------------------------------------------
	if (! -d $Setup->{dst}) {
		eval { mkpath ($Setup->{dst}); } if (! -d $Setup->{dst});
		if (! -d $Setup->{dst}) {
			print STDERR "Target directory '$Setup->{dst}' does not exist.\n";
			$Setup->{err}++;
		}
	}
	if (-d $Setup->{dst}) {
		chown ($Setup->{uid}, $Setup->{gid}, "/appl/Nagios/Node");
		chmod (0750, "/appl/Nagios/Node");
		@Stat = stat ($Setup->{dst});
		$Setup->{err} = 0;
		if (($Stat[4] != $Setup->{uid}) || ($Stat[5] != $Setup->{gid})) {
			print STDERR "Target directory '$Setup->{dst}' is not owned by '$Setup->{user}:$Setup->{group}'.\n";
			$Setup->{err}++;
		}
		if (($Stat[2] & 07777) != 0750) {
			print STDERR "Target directory '$Setup->{dst}' mode is not 0750.\n";
			$Setup->{err}++;
		}
	}
	if ($Setup->{err}) {
		print STDERR "\nRun setup as user 'root' to fix the issues !!!\n\n";
		exit (1);
	}
	#--------------------------------------------------------------------
	# Check the location of the Nagios plugins
	#--------------------------------------------------------------------
	$Plugins = Cwd::abs_path ("$Plugins/.");
	print "Found the Nagios plugins at '$Plugins'\n";
	$Atos = "";
	$Atos = readlink "$Plugins/Atos" if (-l "$Plugins/Atos");
	if ($Atos ne "/appl/Nagios/Plugins/Atos") {
		if (! -d "/appl/Nagios/Plugins/Atos") {
			print "    Creating '/appl/Nagios/Plugins/Atos/'\n";
			eval { mkpath ("/appl/Nagios/Plugins/Atos"); };
			if (! -d "/appl/Nagios/Plugins/Atos") {
				print STDERR "    ERROR creating '/appl/Nagios/Plugins/Atos'\n";
				$Setup->{err}++;
			}
		}
		if (-d "/appl/Nagios/Plugins/Atos") {
			print "    $Plugins/Atos => /appl/Nagios/Plugins/Atos\n";
			eval { symlink ("/appl/Nagios/Plugins/Atos", "$Plugins/Atos"); };
			if ($@) {
				print STDERR "    ERROR creating symlink '$Plugins/Atos'\n";
				$Setup->{err}++;
			}
		}
	}
	chown ($Setup->{uid}, $Setup->{gid}, "/appl/Nagios/Plugins");
	chown ($Setup->{uid}, $Setup->{gid}, "/appl/Nagios/Plugins/Atos");
	chmod (0750, "/appl/Nagios/Plugins", "/appl/Nagios/Plugins/Atos");
	#--------------------------------------------------------------------
	# Check and/or create the installation target
	#--------------------------------------------------------------------
	$Setup->CheckFolder ("/etc",     "etc", 0);
	$Setup->CheckFolder ("/opt",     "opt", 1);
	$Setup->CheckFolder ("/var",     "var", 0);
	$Setup->CheckFolder ("/var/www", "www", 1);
	$Setup->CheckHttpd();
	$Setup->CheckNacc();
	if ($Setup->{err}) {
		print STDERR "\nRun setup as user 'root' to fix the issues !!!\n\n";
		exit (1);
	}
	if (! $>) {
		print STDERR "\nRun setup as user '$Setup->{user}' to continue !!!\n\n";
		exit (1);
	}
	#--------------------------------------------------------------------
	return;
}
sub Symlink {
	my ($Setup, $Src, $Dst) = @_;
	my ($Link, $Path);
	#--------------------------------------------------------------------
	$Link = "/appl/$Setup->{path}/$Src";
	$Path = "/appl/$Setup->{path}/$Dst";
	print "    $Link => $Path/\n";
	if (! -r $Path) {
		print STDERR"    ERROR creating symlink: $!\n";
		$Setup->{err}++;
		return;
	}
	unlink ($Link) if (-l $Link);
	if (-d $Link) {
		unlink ($Link."-old") if (-l $Link."-old");
		rmtree ($Link."-old") if (-d $Link."-old");
		unlink ($Link."-old") if (-r $Link."-old");
		move ($Link, $Link."-old");
	}
	rmtree ($Link) if (-d $Link);
	unlink ($Link) if (-r $Link);
	eval { symlink ($Path, $Link) || die(); };
	if ($@) {
		print STDERR "    ERROR creating symlink: $!\n";
		$Setup->{err}++;
	}
	#--------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
#[eof]

