# Nagios Node 2.2.4.30
<sup>November 22nd, 2021</sup>
- From #56: Implement `nmon` debug logging.
- Remove `NmonTransport.pl` from the project and during setup.
- Instruct to remove `NmonTransport.pl` crontab entry during setup.
- From #45: Improve the error message when the `IsActive/<method>.pm` is not available and/or the failover configuration is incorrect.
- From #45: Improve the sample configuration file with a pointer to the documentation in `FAILOVER.md`.
- From #59: Deliver okay notifications during maintenance
- Improve `FAILOVER.md` as it currently does not describe all options.
- Bump the version to 2.2.4.30 and update `README.md` (this file)

# Nagios Node 2.2.3.19 ... 2.2.4.29
- Nagios Node 2.2.4.29 - September 3rd, 2021 - Implement upload support.
- Nagios Node 2.2.3.27 - May 21st, 2021 - Implement n(j)mon support.
- Nagios Node 2.2.3.24 - July 2nd, 2020 - Added support for external failover solutions (see [`FAILOVER.md`](FAILOVER.md)).
- Nagios Node 2.2.3.23 - May 9th, 2020 - Added processing of client SSL_PROTOCOL and SSL_CIPHER information.
- Nagios Node 2.2.3.22 - November 4th, 2019 - Fixed bug which caused that sometimes message was truncated in transaction from NaCl to NagiosNode.
- Nagios Node 2.2.3.21 - October 7rd, 2019 - Improved Setup.pl, now it reports errors to stderr.
- Nagios Node 2.2.3.20 - October 3rd, 2019 - Improved Setup.pl (part that identifies httpd).
- Nagios Node 2.2.3.19 - July 24th, 2019 - Relaxed UUID validation, as we need to support all current clients.

# Nagios Node 2.2.3.18
<sup>May 7th, 2019</sup>

Just version numbering change according to Peters proposition:

To get this situation cleared and be able to start converging the code, my proposal is:
1.	The base branch will continue to use the 2.2.2.x numbering.
2.	The branch with Radek’s code will start using the 2.2.3.x numbering.
3.	The branch with my new notification handler will start using the 2.2.4.x numbering.

Note: The 2.2.4.x branch mentioned here has been discontinued in 2021 - See issue #59 for a newer notification handler.

# Nagios Node 2.2.2.18
<sup>April 28th, 2019</sup>

Improved Setup.pl script to handle custom apache deployments.


# Nagios Node 2.2.2.17
<sup>March 29th, 2019</sup>

Merge of flood detection/suppresion functionality with improvements:

- flood detection doesn't count OK notifications
- new scenario that counts only host DOWN/UNREACHABLE notifications (config 
  entry `notify.flood.hostdown= 4:60`)

# Nagios Node 2.2.2.16
<sup>March 18th, 2019</sup>

Starting with build 16 _every_ release will have a unique incrementing build
number, instead of using a date suffix to indicate the 'for testing' releases.

The following issues have been solved in this build:

- Merged code that corrected the client config (v1 and v2) generation (RG)
  and re-ordered config (v1 and v2) generation for better code readability.
- Merged code that corrected timeperiod processing of 'NaNo' checks (RG)
  and removed timeperiod checking for 'NaNo' checks as this info is not used.
- Improved error handling in 'nano' checks in case a check returns invalid data.
- Fixed a bug in the 'nano!client' check handler that returned invalid data.
- Added 'not yet implemented' code for the 'nano!bot' and 'nano!node' checks
  as a preparation for implementing more 'nano' checks in future versions.

__NOTICE:__ Nagios Node versions 2.2.2.10b and later require 'curl' or 'wget'.

---
# Nagios Node 2.2.2.15_20190304 for testing
<sup>March 4th, 2019</sup>

__Important notice:__ the Nagios Node 2.2.2.15 software requires 'curl' or 'wget'.

The following issues have been addressed in this release of the NaNo software:

- Auto-update support part 3 (#4): synchronize packages from the TMDX Servers 
  to the Nagios Nodes.
- Auto-update support part 7 (#5): assign packages to clients by processing 
  the client/packages requests from NAHQ.
- Modify the TMDX Server URL (#13): use the '/Tmdx/Server/' path instead of '/'
  for all TMDX Server requests.
- Auto-update support part 9c (#16): modify the client command handler to be 
  NaCl 3.x compatible.

To address those issues, the following changes have been implemented:

- implemented 'opt/Nagios/Node/Batch/Hourly/Packages.pm'. This batch module will
  synchronize the packages from the TMDX Servers onxe an hour to the 'Packages'
  directory on the Nagios Node.
  
- Finished 'opt/Nagios/Node/Receive/Request.pm' and 'opt/Nagios/Node/Request.pm'
  as this code wasn't used until now (a basic implementation already existed).

- Implemented 'opt/Nagios/Node/Request/Client/Packages.pm' to save the assigned
  packages as specified in the request as 'Client/<uuid>/Packages.acl'.
  
- Updated the 'opt/Nagios/Node/Request/Client/Unregister.pm' template (not yet
  functional) to support the finished version of 'opt/Nagios/Node/Request.pm'.

- NOT update the v3 client config in 'opt/Nagios/Node/Receive/Config/Client.pm' 
  and 'opt/Nagios/Node/Receive/Files/Install.pm' anymore to avoid conflicts.

- Implemented 'opt/Nagios/Node/Client/Configure.pm' to update client v3 configs
  if either of the parts of this config (checks, files and packages) has been
  updated since the last time the client v3 config has been generated.

- Modified 'opt/Tmdx/Client/Get.pm' and 'opt/Tmdx/Client/Post.pm' to use
  the '/Tmdx/Server/' path instead of '/' for all TMDX Server requests

- Rewritten 'www/Client/Command.php' and 'www/Client/Command/*.php' into a fully
  object oriented structure so the commands can be invoked in a standard way.
  
- Modified 'www/Client/index.php' to delegate client commands from NaCl 3.x to
  the command objects defined in the 'www/Client/Command/*.php' scripts (NaCl
  3.x uses a single connection to 'index.php' for all communications).

- Fixed a large number of small Setup.pl issues when used on RHEL7.

---
# Nagios Node 2.2.1.14
<sup>October 15th, 2018</sup>

__Important notice:__ the Nagios Node 2.2.1.14 software requires 'curl' or 'wget'.

The main purpose of this release is to implement auto-update support for the 
clients connecting to this node (part 8 of the auto-update support epic).

- The client connector in 'www/nacc' has been rewritten from scratch to be able
  to implement the new functionality and to improve apache/php performance.
  All client related files are now kept in 'var/Client/<uuid>' (was 'Clients').
- A 'Client' background process has been added to unload the client connector.
  It validates the clients and passes reported results to the 'Core' process.
- A 'Core' background process has been added to control the Nagios(tm) process.
  For now it only takes care of feeding external commands to the Nagios process.
  In future versions this background process gets more responsibilities.
- The 'Receive' background process has been adjusted to the new situation:
  - External commands (command requests) are now passed to the 'Core' process.
  - Separate configuration files are generated for the v1, v2 and v3 clients.
  - An index with some object configuration data is saved in var/Index.pds.
  - Received client files are stored at the new location ('var/Client/<uuid>').
  - Separate file lists are generated for v1+2 and for v3 clients.
  - Improved detection of notification responses without a known ID.
- The 'Transmit' background process has been adjusted to the new situation:
  - The client & maintenance data is loaded from the new location ('Client').
  - Client tags are now included in the client info being sent to HQ.
  - Based on tags that end with '.bot' some additional data is being collected
    and send to the TMDX Server to enable a short and very efficient data path
    for transfering information to non-CMF systems without extra load for CMF.
- Two additional scripts, 'opt/Test/Curl.pl' and 'opt/Test/Wget.pl' have
  been added to allow easy testing of the connectivity to the TMDX Servers.
- The 'www/Command.php' interface has been adjusted to the new location of the
  client files and now passes all external commands for Nagios(tm) to the new
  'Core' process. In addition the output of the 'list' command has been modified
  so the display names of the host and the services are not truncated anymore.

---
## Nagios Node 2.2.0.12
<sup>September 24th, 2018</sup>

__Important notice:__ the Nagios Node 2.2.0.12 software requires 'curl' or 'wget'.

The archive (`NagiosNode-2.2.0.12.tgz`) contains the full setup of the Nagios 
Node 2.2.0.12 software. Extract the archive, run 'Setup.pl' and read & follow
the instructions. 
This is the first version of the software that is fully maintained in GitLab at 
'https://bsaum.nl.ms.myatos.net/repo/nagiosknights/cmf-server/cmf-nano2'.
The main changes in this version are:

* A new 'Setup.pl' script has been added that checks the prerequisites and
  gives instructions about what needs to be done to finish the installation.
* Both 'curl' (prefered) and 'wget' (fallback) are now supported for the
  SSL connections to the TMDX Servers. Note that 'curl' is more reliable.
* The nagios account & password expiration check in the CheckNagiosNode.pl
  plugin is now implemented as a separate check, instead as part of each check.
* The NmonTransport scripts are now included in the Nagios Node installation.
* On systems that have Nagios 4.x installed, the required Nagios 3.x binary can
  be provided at '/appl/Nagios/Node/nagios' (either the binary or a symlink).
  
---
## Nagios Node 2.2.0.11
<sup>"opt" only - Not released</sup>

__Important notice:__ the Nagios Node 2.2.0.11 software requires 'curl' or 'wget'.

---
## Nagios Node 2.2.0.10b
<sup"opt" only - June 25th, 2018</sup>

__Important notice:__ the Nagios Node 2.2.0.10b software requires 'wget'

This archive ONLY contains the contents of the /opt/Nagios/Node/ directory.
The contents of /var/www/html/nacc/ are not included in this release.

This version fixes the support for SSL connections via a proxy that became
unreliable by the method implemented in version 2.2.0.10a. It seems that SSL
proxy support in the Perl LWP::UserAgent library becomes worse with each new
version. LWP::UserAgent has been replaced by using 'wget' for all SSL calls.

---
## Nagios Node 2.2.0.10a
<sup>"opt" only - October 9th, 2017</sup>

This archive ONLY contains the contents of the /opt/Nagios/Node/ directory.
The contents of /var/www/html/nacc/ are not included in this release.

This version is based on a merge of version 2.2.0.8, fix 1 for this version,
and the SSL-fix. In addition support for SSL 'connect' via a proxy was added
and a number of other issues were solved (including some cosmetic changes).

Version 2.2.0.10a contains the symlinks that were missing in version 2.2.0.10:
* CheckNagiosNode.pl &rArr; NagiosNode.pl
* cronjob.sh &rArr; NagiosNode.pl
* Notify.pl &rArr; NagiosNode.pl

---
## Nagios Node 2.2.0.10
<sup>"opt" only</sup>

* LWP/* + URI/* (support for SSL 'connect' via a proxy server)
* Nagios/Node.pm (fixed 'stop' parameters)
* Nagios/Node/Receive/Notify.pm (improved logging details)
* Nagios/Node/Stop.pm (increased stop time to 30 seconds, improved logging)
* Nagios/Node/Transmit/Status.pm (disabled sending of unchanged status records)
* RestartNagios.pl (increased stop time to 30 seconds before killing nagios)
* Tmdx/Client.pm (SSL-fix: improved configuration pre-processing)
* Tmdx/Client/Get.pm (SSL-fix: LWP code is now in Request.pm)
* Tmdx/Client/Post.pm (SSL-fix: LWP code is now in Request.pm)
* Tmdx/Client/Request.pm (SSL-fix + fixed proxy 'connect' support)
* Tmdx/Client/Check.pm (SSL-fix: fixed wrong result state)
