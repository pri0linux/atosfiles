# Testing the CMF Nagios Node Software

Testing in interactive mode will also show any error messages that are
not being logged and are invisible when running in the background.
To be able to test the CMF Nagios Node software in interactive mode:

- Complete the setup and registration procedure successfully.
- Disable the CMF Nagios Node entry in the crontab to keep it from running
in the background.
- Stop all active background processes with the following command:

> `/opt/Nagios/Node/NagiosNode.pl NagiosNode stop`

Don't forget to re-enable the crontab entry after testing the software!

## Transmitting data to the TMDX Servers

Open a _first_ command shell as user 'nagios' and start the 'post' 
process with the following command:

> `/opt/Nagios/Node/NagiosNode.pl NagiosNode post`

This will start the process that posts data to the TMDX Servers. 
It should show '200 OK' responses for each connection.
Now open a _second_ command shell and issue the same command again:

> `/opt/Nagios/Node/NagiosNode.pl NagiosNode post`

As the 'post' process is already active, this time a self-test is being
performed. Note that it can take three minutes before the self-test 
reports OK for all three TMDX Server connections.

In the _second_ command shell issue the following command to transmit
the status to the Nagios Headquarters servers:

> `/opt/Nagios/Node/NagiosNode.pl NagiosNode transmit`

Carefully check the output for any issues. The last line should show that the
transmit process posted 'nano.status' for 'nahq'. The 'post' process in the
_first_ command shell should show that this information was posted to the
TMDX Servers.

## Receiving data from the TMDX Servers

Stop any processes that are still running before executing this test.
Delete the 'get' index files to reset the state of the 'get' processes:

> `rm /var/Nagios/Node/NagiosNode/tmdx/*.idx`

Now you need _three_ ommand shells to start the three 'get' processes.
Issue the following commands, each in its own command shell:

> `/opt/Nagios/Node/NagiosNode.pl NagiosNode get 161.89.118.99`
> `/opt/Nagios/Node/NagiosNode.pl NagiosNode get 161.89.112.88`
> `/opt/Nagios/Node/NagiosNode.pl NagiosNode get 161.89.177.69`

The commands might show a 'Not Found' response if the TMDX Servers never got
data for this Nagios Node before. In normal situation '200 OK' shows that data
was received, or '204 No Data' if no new data is available.

Now open a _fourth_ command shell and issue the three commands shown above
again. This will perform a self-test on each of the connections as the 'get'
processes are already active in the first three command shells.

Use the _fourth_ command shell to process the received data with the following command:

> `/opt/Nagios/Node/NagiosNode.pl NagiosNode receive`

To be continued ...










  
  