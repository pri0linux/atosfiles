# Test Report

## Environment

Used `nltnano33a` and `nltnano33b` for test purposes.

## Installation

Installed by downloading branch `.tar.gz` archive, unpacking and running `Setup.pl` both as `root` and `nagios` user.

## Tests

Test cases from [here](https://gitlab.cmf.atos-srv.net/repo/nagiosknights/cmf-server/cmf-nano2/-/blob/46-client-command-php-not-php7-compatible/doc/Testing%20scenario.md). `[...]` in output means it has been omitted (if for example too many irrelevant lines show).

### :heavy_check_mark: Check 1

UUID of NaCl:

```
[nagios@nltnano33a NaCl]$ cat NaCl.cfg  | grep uuid
uuid         = 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6
```

So checked files are in `/var/Nagios/Node/NagiosNode/Client/0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6`.

First checked if files `Record.info` and `Record.pds` are up to date:

```
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ date +'%s'
1613991917
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ grep time Record.info
time=1613991908
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ ll Record.*
-rw-rw-r-- 1 nagios nagios 320 Feb 22 12:07 Record.info
-rw-r--r-- 1 nagios nagios 391 Feb 22 12:07 Record.pds
```

And they are - files' modification time is at the same exact minute as the `ls -l` command has been called.

After installing PHP 7 it still works as intended:

```
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ ll Record.*
-rw-rw-r--  1 nagios nagios   325 Feb 22 14:04 Record.info
-rw-r--r--  1 nagios nagios   396 Feb 22 14:04 Record.pds
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ date +'%s'
1613999072
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ grep time Record.info
time=1613999048.2363
```

### :heavy_check_mark: Check 2

First tested for PHP 5 that was already installed. Run command:

```
[nagios@nltnano33a NaCl]$ ~/NaCl/Command.pl -C downtime all 5m testing
Scheduling downtime for host '0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6' (2021/02/22 11:54:27 - 2021/02/22 11:59:27 UTC)
Scheduling downtime for service 'b19675dc-72b5-11eb-9130-005056ab6993' (2021/02/22 11:54:27 - 2021/02/22 11:59:27 UTC)
Scheduling downtime for service 'af01adcb-f2c8-11ea-928a-005056ab6993' (2021/02/22 11:54:27 - 2021/02/22 11:59:27 UTC)
Scheduling downtime for service 'b16d244a-72b5-11eb-9130-005056ab6993' (2021/02/22 11:54:27 - 2021/02/22 11:59:27 UTC)
[...]
```

First few lines of command output:
```
[nagios@nltnano33a NaCl]$ ./Command.pl -C downtime
Type/Id  Type.id/Author/Comment               Type.name  /  Starttime/Endtime
-------------------------------------------------------------------------------
host     0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6 nltnano33a.stn.nl.ao-srv.com
downtime nagios@nltnano33a                                  2021/02/22 11:54:27
457      testing                                            2021/02/22 11:59:27
-------------------------------------------------------------------------------
service  b19675dc-72b5-11eb-9130-005056ab6993 nagios33-nltnano33a-app_Exec_SECODB_VERSION
downtime nagios@nltnano33a                                  2021/02/22 11:54:27
458      testing                                            2021/02/22 11:59:27
-------------------------------------------------------------------------------
service  af01adcb-f2c8-11ea-928a-005056ab6993 LOG_SYSTEM_TEST
downtime nagios@nltnano33a                                  2021/02/22 11:54:27
459      testing                                            2021/02/22 11:59:27
-------------------------------------------------------------------------------
service  b16d244a-72b5-11eb-9130-005056ab6993 nagios33-nltnano33a-app_Filesystem_/opt
downtime nagios@nltnano33a                                  2021/02/22 11:54:27
460      testing                                            2021/02/22 11:59:27
[...]
```

Now after installing PHP7 from Remi repository:

```
[nagios@nltnano33a ~]$ php --version
PHP 7.3.25 (cli) (built: Nov 24 2020 14:31:55) ( NTS )
Copyright (c) 1997-2018 The PHP Group
Zend Engine v3.3.25, Copyright (c) 1998-2018 Zend Technologies
[nagios@nltnano33a ~]$ ~/NaCl/Command.pl -C downtime # before the downtime setting
Type/Id  Type.id/Author/Comment               Type.name  /  Starttime/Endtime
-------------------------------------------------------------------------------
[nagios@nltnano33a ~]$ ~/NaCl/Command.pl -C downtime all 5m testing
Scheduling downtime for host '0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6' (2021/02/22 12:49:27 - 2021/02/22 12:54:27 UTC)
Scheduling downtime for service 'b19675dc-72b5-11eb-9130-005056ab6993' (2021/02/22 12:49:27 - 2021/02/22 12:54:27 UTC)
Scheduling downtime for service 'af01adcb-f2c8-11ea-928a-005056ab6993' (2021/02/22 12:49:27 - 2021/02/22 12:54:27 UTC)
Scheduling downtime for service 'b16d244a-72b5-11eb-9130-005056ab6993' (2021/02/22 12:49:27 - 2021/02/22 12:54:27 UTC)
[...]
[nagios@nltnano33a ~]$ ~/NaCl/Command.pl -C downtime
Type/Id  Type.id/Author/Comment               Type.name  /  Starttime/Endtime
-------------------------------------------------------------------------------
host     0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6 nltnano33a.stn.nl.ao-srv.com
downtime nagios@nltnano33a                                  2021/02/22 12:49:27
522      testing                                            2021/02/22 12:54:27
-------------------------------------------------------------------------------
service  b19675dc-72b5-11eb-9130-005056ab6993 nagios33-nltnano33a-app_Exec_SECODB_VERSION
downtime nagios@nltnano33a                                  2021/02/22 12:49:27
523      testing                                            2021/02/22 12:54:27
-------------------------------------------------------------------------------
service  af01adcb-f2c8-11ea-928a-005056ab6993 LOG_SYSTEM_TEST
downtime nagios@nltnano33a                                  2021/02/22 12:49:27
524      testing                                            2021/02/22 12:54:27
-------------------------------------------------------------------------------
[...]
```

Works the same for both PHP versions.

### :heavy_check_mark: Check 3

Added check for process `nano_testing` in CMF GUI, waited for the translation to end.

In `/appl/Nagios/Node/var/NagiosNode/objects.cfg` this entry could be found:

```
define service{
        _TEAM 321
        _FOLLOW_HOST 1
        _HOST_DISPLAY_NAME nltnano33a.stn.nl.ao-srv.com
        active_checks_enabled 0
        check_command NaCl!Passive!Process_nano_testing
        check_interval 2
        check_period 7x24
        contacts c3328168-c277-4db8-a3e9-b5bda66ea67f
        display_name Process_nano_testing
[...]
```

In `/appl/Nagios/Node/var/NagiosNode/status.dat`:
```
servicestatus {
        host_name=0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6
        service_description=3624e8f4-7510-11eb-9130-005056ab6993
        modified_attributes=0
        check_command=NaCl!Passive!Process_nano_testing
        check_period=7x24
[...]
```

### :heavy_check_mark: Check 4

After unpacking the `.gz` files:

```
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ gzip -d Config.v[123].gz
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ grep 'nano_testing' Config.v[123]
Config.v1:3624e8f4-7510-11eb-9130-005056ab6993;0;1;2;1;NaCl!Passive!Process_nano_testing
Config.v2:      check_command   NaCl!Passive!Process_nano_testing
Config.v2:      display_name    Process_nano_testing
Config.v3:check|3624e8f4-7510-11eb-9130-005056ab6993|0|2|1|NaCl!Passive!Process_nano_testing
```

### :heavy_check_mark: Check 5

#### `ASEP.cnf`

```
[nagios@nltnano33a Files]$ grep nano_testing ASEP.cnf
NAME nano_testing
NAHQ_NAME Process_nano_testing
PRC nano_testing
```

Full entry:

```
NAME nano_testing
NAHQ_UUID 3624e8f4-7510-11eb-9130-005056ab6993
NAHQ_NAME Process_nano_testing
PRC nano_testing
CIID SNC.G.P01.006278348
CLASS ZZ-Event.Server Management.Hosting.Linux
USER .*
_STAT .*
_REP 1
MIN 1
MAX 999
SEV_MIN 1
SEV_MAX 1
```

#### `Files.dat`

```
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ date +%s
1614001048
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ grep ASEP.cnf Files.dat
ASEP.cnf;2395;1614000145
```

The timestamp seems correct.

#### `Files.pds`

```
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ /opt/Nagios/Node/pdxdump.pl Files.pds  | grep 'ASEP.cnf' -A3
         'ASEP.cnf' => [
                         '2395',
                         '1614000145',
                         'E93CBBEADA14A57BD010AEE814D14DE3A450B3C1'
```

The same timestamp as above.

### :heavy_check_mark: Check 6

Checked the log:

```
[nagios@nltnano33a 0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6]$ grep INC /var/Nagios/Node/NagiosNode/nagios.log | tail
[1613986994] EXTERNAL COMMAND: ADD_SVC_COMMENT;1565bcae-01ba-486b-b277-03e2d35a13f6;c3880bda-6356-11ea-aa0d-0050568c6f1a;1;(Sia@tmdx1);TICKET_CREATED: Ticket INC020825369
[1613992633] EXTERNAL COMMAND: ADD_SVC_COMMENT;0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6;b18909c7-72b5-11eb-9130-005056ab6993;1;(Sia@tmdx1);TICKET_CREATED: Ticket INC020827746
[1614001027] EXTERNAL COMMAND: ADD_SVC_COMMENT;0ca72c03-5bd4-408a-9cb0-cd6a056f2fe6;3624e8f4-7510-11eb-9130-005056ab6993;1;(Sia@tmdx1);TICKET_CREATED: Ticket INC020831024
```

Opened the ticket (`INC020831024`) in SNOW and it shows that the process cannot be found:

```
[...]
EMKR: UMF
 :  
TicketSummary: nltnano33a (Process_nano_testing) Process nano_testing is not running 1x!
EventSteadyState: Stateful
[...]
```

So it seems it is working correct as well.

Removed the `nano_testing` check after tests.

### :heavy_check_mark: Check 7

Datetime of check: **22/02/2021 15:20**

First checked the log file:

```
[nagios@nltnano33a bin]$ grep nano.status -A2 /var/Nagios/Node/NagiosNode/tmdx/log/20210222-post.log | tail
14:14:13.025     200 OK
14:14:13.025     Posted '1614003250.00118061' to 'nahq' via '161.89.177.69' as '0' ...
--
14:16:11.157 CURL POST https://161.89.118.99/Tmdx/Server/?to=nahq&ttl=300&event=nano.status
14:16:12.160     200 OK
14:16:12.160     Posted '1614003369.00120488' to 'nahq' via '161.89.118.99' as '0' ...
--
14:18:12.311 CURL POST https://161.89.118.99/Tmdx/Server/?to=nahq&ttl=300&event=nano.status
14:18:13.313     200 OK
14:18:13.313     Posted '1614003489.00222112' to 'nahq' via '161.89.118.99' as '0' ...
```

And in CMF GUI checked **Heartbeat** of NaNo in **Gateways** and it was recent:

| Heartbeat     | 2021-02-22 15:18:12 |
|---------------|---------------------|
| Heartbeat Age | a few seconds ago   |

Also checked **Monitored Hosts**, at 15:24 **Last check** time was **2021-02-22 15:21:44** so it was pretty recent.

For **Monitored Services** of the host, at 15:27 it was **2021-02-22 15:25:45**.

## :page_with_curl: Test Report - Summary

All checks passed.

* :heavy_check_mark: **Check 1** - *passed*
* :heavy_check_mark: **Check 2** - *passed*
* :heavy_check_mark: **Check 3** - *passed*
* :heavy_check_mark: **Check 4** - *passed*
* :heavy_check_mark: **Check 5** - *passed*
* :heavy_check_mark: **Check 6** - *passed*
* :heavy_check_mark: **Check 7** - *passed*
