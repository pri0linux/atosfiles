# Test Report

## Environment

Used `nltnano33a` and `nltnano33b` for test purposes.

## Installation

Installed by downloading branch `.tar.gz` archive, unpacking and running `Setup.pl` both as `root` and `nagios` user.

## Tests

As the NaNo's above are already set up with keepalived, we can use them just by changing method from `ipaddr` to `httpget` and `httpsget`.

### :heavy_check_mark: Check A - `httpget` method

Edited failover method in `/appl/Nagios/Node/etc/NagiosNode.cfg` on both nodes:

```ini
isactive = httpget:161.89.177.80 # ip of virtual node here
```

Restarted `keepalived` service on `nltnano33a` (active node) to provoke the failover active node change:

```
[nagios@nltnano33a Node]$ ./NagiosNode.pl NagiosNode
[nagios@nltnano33a ~]$ sudo service keepalived restart
Stopping keepalived:                                       [  OK  ]
Starting keepalived:                                       [  OK  ]
[nagios@nltnano33a Node]$ ./NagiosNode.pl NagiosNode
This Nagios Node is not active
```

And now `nltnano33b` should be an active node:

```
[nagios@nltnano33b ~]$ /opt/Nagios/Node/NagiosNode.pl NagiosNode
```

No output means no error, so it is the active node now. As can be seen, even after changing the method the failover works.

### :heavy_check_mark: Check B - `httpsget` method

Did the same for `httpsget` method, first changing the cfg file again:

```
isactive = httpsget:161.89.177.80
```

At first I've restarted the `keepalived` service too soon so it gave an error:

```
[nagios@nltnano33b ~]$ /opt/Nagios/Node/NagiosNode.pl NagiosNode
Stuck at ACTIVE until 10:16:42 UTC !!!
```

But it is expected because the sync needs 5 minutes of break. After the time passed, it worked as intended like for `httpget` method:

```
[nagios@nltnano33b ~]$ /opt/Nagios/Node/NagiosNode.pl NagiosNode
Switching to PASSIVE at 10:15:53 UTC
Stopping PID 21499: 11:11 Nagios::Node('NagiosNode')->Receive()
Stopping PID 21528: 11:11 /opt/Nagios/Node/nagios -d /var/Nagios/Node/NagiosNode/nagios.cfg
Stopping PID 21475: 11:11 Nagios::Node('NagiosNode')->Client()
Stopping PID 21464: 11:11 Nagios::Node('NagiosNode')->Tmdx::Client->Get('161.89.118.99')
Stopping PID 21491: 11:11 Nagios::Node('NagiosNode')->Nmon()
Stopping PID 21459: 11:11 Nagios::Node('NagiosNode')->Tmdx::Client->Get('161.89.112.88')
Stopping PID 21467: 11:11 Nagios::Node('NagiosNode')->Tmdx::Client->Post()
Stopping PID 21481: 11:11 Nagios::Node('NagiosNode')->Core()
This Nagios Node is not active
```