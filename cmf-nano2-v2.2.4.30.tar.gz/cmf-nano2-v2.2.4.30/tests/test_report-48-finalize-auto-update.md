# Test Report

## Environment

Used `nlcnano1` for test purposes.

## Installation

Installed by downloading branch `.tar.gz` archive, unpacking and running `Setup.pl` both as `root` and `nagios` user.

## Tests

Tests are taken from [here](https://gitlab.cmf.atos-srv.net/repo/nagiosknights/cmf-server/cmf-nano2/-/blob/master/doc/Testing%20scenario.md) - in this case it's **Special tests** section.

### :heavy_check_mark: Check A

In this test we check if everything works as intended for Nagios Client with no files or translation run. For this we need to generate new UUID as files are assigned according to it. Renamed `NaCl.cfg` (which contains UUID) to `NaCl.cfg.old` and generated new config file with same parameters:

``` txt
[nagios@nlcnano1 NaCl] (cat) $ ./NaCl -s 161.89.30.24
```

The available files in packages directory:

```
[nagios@nlcnano1 NaCl] (cat) $ ls /var/Nagios/Node/NagiosNode/Packages
ASE  AU_CAT_test_1.0  AU_Test  file_test_333  perl-Class-Inspector-1.28-2.el7.noarch.rpm  R3D3_monapache  test_file  test_file_2  UMF_RHEL6_x64_NaCl-1.8.0.5_ase-1.05-26.run
```

I picked `file_test_333` for the test. Now I am simulating request HQ->client for the package.

```
[nagios@nlcnahq1 rg_requests_client_packages] (cat) $ cat 1614866683.00528598.info
to: nagios1cat
ttl: 60
event: nano.request
[nagios@nlcnahq1 rg_requests_client_packages] (cat) $ zcat 1614866683.00528598.data
client=64234544-3f92-4d8d-b69a-5ac7284aa71b
action=client/packages


file_test_333
```

Copied the files to `/var/Nagios/Headquarters/tmdx/tx` and waited for the file to update:

```
[nagios@nlcnano1 64234544-3f92-4d8d-b69a-5ac7284aa71b] (cat) $ tail -2 Config.v3
[eof]
```

After some time passed:

```
[nagios@nlcnano1 64234544-3f92-4d8d-b69a-5ac7284aa71b] (cat) $ tail -2 Config.v3
package|file_test_333|14|1591619413|0663CAC77B1B0C5E537D867FF76E46B1A77C167B
[eof]
[nagios@nlcnano1 64234544-3f92-4d8d-b69a-5ac7284aa71b] (cat) $ zcat Config.v3.gz | tail -2
package|file_test_333|14|1591619413|0663CAC77B1B0C5E537D867FF76E46B1A77C167B
[eof]
```
