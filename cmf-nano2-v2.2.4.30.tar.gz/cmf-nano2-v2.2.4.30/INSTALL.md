# Nagios Node Installation Guide

This installation guide contains the detailed procedure for both initial
installations and for upgrades of existing Nagios Nodes.

This guide covers installation on RedHat 7 and Oracle Linux 7 as well as `oraclelinux:latest` Docker image.
It _may_ work also on other distributions, but has not been tested anywhere else.
If you know more universal ways of doing things, go ahead and update this document,
but only if it _also_ works on RedHat7 or Oracle Linux 7.

Aside of that, if you are changing anything here you _have_ to update automated
install process as well. This process is described in files `Dockerfile`, `.gitlab-ci.yml`
and `docker-entrypoint.sh`. Each section have a reference to this files just below a section title.

Also, please do not commit to master branch updates that have _not_ been tested on: 
 - RedHat7 standalone machine
 - Oracle Linux 7 standalone machine,
 - `oraclelinux:latest` Docker image

## Manual install

### Internet access
This step covers what is done automagicly in:
 - `Dockerfile` lines 3-5
 - `.gitlab-ci.yml` lines 56-59
Think twice if you _really_ want do do it manuall. There are automagic ways!

Ensure that you have Internet access. This guide assumes that you have.
If not - you have to find a way, on your own, to get needed packages from
Internet repositories. If you will find out a good, universal way to do this
- go ahead, and feel free to add this to guide.

In most cases you may want to dig some kind of tunnel over ssh, and setup
a proxy enviromental variable by invoking:
```bash
export HTTP_PROXY=http://127.0.0.1:1234;
export HTTPS_PROXY="${HTTP_PROXY}";
```

If you do have a working proxy in network where your destination machine is placed - lucky you - just
use it instead ssh tunnel.

### Prepare your system
This step covers what is done automagicly in:
 - `Dockerfile` lines 7-25
 - `.gitlab-ci.yml` line 12
Think twice if you _really_ want do do it manuall. There are automagic ways!

I won't copy and paste commands here, just open Docker file, and execute commands
between 7-25 lines. There are comments there, so don't be afraid. If you think that smth
could be done better - change it, test it (and then test it again, everywhere), and commit
back to repository.

## Docker install

### Build

Normally docker container is builded with automated CI/CD process.
This proces is described in `.gitlab-ci.yml` and it is started
at every commit. Image is automaticlly pushed to GitLab docker
registry and can be downloaded from there. 

However if you want to build it manually for some reason, just 
clone this repository and run:

```bash
CONTAINER_IMAGE="bsaum.nl.ms.myatos.net:4567/nagiosknights/cmf-server/cmf-nano2";
CI_COMMIT_SHA="$(git rev-parse --short HEAD)";
CI_BUILD_REF="manual_$(date '+%Y-%m-%d_%H:%M')";
docker build \
   --cache-from $CONTAINER_IMAGE:latest \
   --tag $CONTAINER_IMAGE:$CI_BUILD_REF 
   --tag $CONTAINER_IMAGE:latest \
   --tag $CONTAINER_IMAGE:$CI_COMMIT_SHA .
```


### Transfer image

#### Manual
You may save docker image to file (it may be useful when you have troubles
with access to intrastructure where you are goin to install new NaNo (for example
7 restricted stepping stones etc.):

```bash
docker save --output "cmf-nano2_$CI_BUILD_REF_$CI_COMMIT_SHA.tar" $CONTAINER_IMAGE:$CI_BUILD_REF
```

Now you have a file, which you can take with you and use as you wish.  You can use it later by `docker import` command.

#### Docker Registry

Much better way is to use Docker registry. To push images there just run:
```bash
docker push $CONTAINER_IMAGE:$CI_BUILD_REF
docker push $CONTAINER_IMAGE:latest
```
End it will be magically uploaded there.


### Run

#### Deploy using GitLab CI/CD
... to be described ...

#### Deploy manually
... to be described ...
