#!/usr/bin/env perl
#------------------------------------------------------------------------------
# pdxdump.pl - Dump contents of a 'pds' or 'pdx' file in human readable format
#------------------------------------------------------------------------------
use strict;
use warnings;

use Compress::Zlib;
use Data::Dumper;
use Storable;

die ("Usage: pdxdump.pl <filename>\n") if ($#ARGV < 0);
foreach (@ARGV) { pdxdump ($_); }
exit 0;
#------------------------------------------------------------------------------
sub pdxdump
{
  my ($File) = @_;
  my ($Type, $Data, $Unzip);
  #--------------------------------------------------------------------
  ($Type) = ($File =~ /\.(pd.?)$/);
  $Data = Storable::lock_retrieve ($File);
  if ($Type eq "pdx")
  {
    $Unzip = Compress::Zlib::memGunzip ($Data);
    $Data  = Storable::thaw ($Unzip);
  }
  $Data::Dumper::Sortkeys = 1;
  print Data::Dumper->Dump ([$Data],[$Type]);
  #--------------------------------------------------------------------
  return;
}
#------------------------------------------------------------------------------
#[eof]
