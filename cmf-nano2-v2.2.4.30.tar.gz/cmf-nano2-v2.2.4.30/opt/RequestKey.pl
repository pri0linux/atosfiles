#!/usr/bin/env perl
#------------------------------------------------------------------------------
use strict;
use warnings;

use Cwd;
use File::Basename;
use File::Copy;
use lib "".dirname(Cwd::abs_path($0));
use Nagios::Node::Version;

my ($ETC, $Instance, $NodeId, $CrtFile, $Key, $Cmd, $Csr, $CsrId, $Crt, $CrtId);
my ($Before, $After);
#------------------------------------------------------------------------------
# Initialize
#------------------------------------------------------------------------------
$ETC  = '/etc/Nagios/Node';
die "Access denied: run as 'nagios' !!!\n" if (getpwuid($>) ne 'nagios');
die "Nagios Node software not found !!!\n" if (! -d $ETC);
#------------------------------------------------------------------------------
# Check the commandline parameters
#------------------------------------------------------------------------------
if (($#ARGV < 0) || ($#ARGV > 1)) { Usage(); }
$Instance = $ARGV[0];
if (! -r "/etc/Nagios/Node/$Instance.cfg") 
{ 
  Usage ("Error:  '$Instance' is NOT a valid instance !!!");
}
$NodeId   = undef;
$CrtFile  = undef;
if ($#ARGV > 0)
{
  if ($ARGV[1] =~ /^[A-Za-z0-9_]+$/) { $NodeId = lc($ARGV[1]); }
  elsif (-r $ARGV[1]) { $CrtFile = $ARGV[1]; }
  else { Usage ("Error:  '$ARGV[1]' is NOT a valid node-ID or CRT-file !!!"); }
}
$NodeId = "" if (! defined $NodeId);
#------------------------------------------------------------------------------
# Generate the KEY and CSR if they don't exist yet
#------------------------------------------------------------------------------
if (! -r "$ETC/$Instance.key")
{
  Usage ("Error:  Please specify a valid node-ID !!!") if ($NodeId eq ""); 
  $Key = `openssl genrsa 1024 2>/dev/null`; chomp $Key;
  die "Error creating private key !!!\n" if ($Key !~ /--BEGIN RSA PRIVATE KEY--/);
  die "$!\n" if (! open (KEY, ">$ETC/$Instance.key"));
  print KEY "$Key\n";
  close KEY;
  chmod (0600, "$ETC/$Instance.key");

  $Cmd = "openssl req -new -text -key $ETC/$Instance.key -subj '/C=NL/O=Atos Origin/OU=Tooling&Monitoring/CN=$NodeId/'";
  $Csr = `$Cmd 2>/dev/null`; chomp $Csr;
  die "Error creating request !!!\n" if ($Csr !~ /--BEGIN CERTIFICATE REQUEST--/);
  die "$!\n" if (! open (CSR, ">$ETC/$Instance.csr"));
  print CSR "$Csr\n";
  close CSR;
  die "$!\n" if (! open (KEY, ">$ETC/$Instance.key"));
  print KEY "$Key\n";
  print KEY "$Csr\n";
  close KEY;
  chmod (0600, "$ETC/$Instance.key");

  print STDERR "RequestKey.pl v$main::VERSION - Copyright (C) $main::COPYRIGHT\n";
  print STDERR "\n";
  print STDERR "  The Certificate Signing Request for Nagios Node '$NodeId'\n";
  print STDERR "  has been saved as '$ETC/$Instance.csr'.\n";
  print STDERR "\n";
  print STDERR "  Please send the CSR-file by mail to UMF Operations for signing.\n";
  print STDERR "  Do NOT include the KEY-file as it contains the PRIVATE key !!!.\n";
  print STDERR "\n";
  print STDERR "This script is part of the Nagios Node (UMF) software. Only use this script as\n";
  print STDERR "instructed by the department responsible for Nagios Node (UMF) Operations.\n";
  exit (0);
}
chmod (0600, "$ETC/$Instance.key");
$Key = `openssl rsa -in $ETC/$Instance.key 2>/dev/null`; chomp $Key;
$Csr = `openssl req -text -in $ETC/$Instance.key 2>/dev/null`; chomp $Csr;
($CsrId) = ($Csr =~ /\sCN=(\w+)\s*\n/);
$Crt = `openssl x509 -text -in $ETC/$Instance.key 2>/dev/null`; chomp $Crt;
($CrtId) = ($Crt =~ /\sCN=(\w+)\s*\n/);
#------------------------------------------------------------------------------
# If a CRT-file was specified ...
#------------------------------------------------------------------------------
if (defined $CrtFile)
{
  die ("'$ETC/$Instance.key' already contains a certificate !!!\n") if (defined $CrtId);
  $Crt = `openssl x509 -text -in $CrtFile 2>/dev/null`; chomp $Crt;
  die "Error loading certificate !!!\n" if ($Crt !~ /--BEGIN CERTIFICATE--/);
  ($CrtId) = ($Crt =~ /\sCN=(\w+)\s*\n/);
  die "Unable to validate certificate !!!\n" if ((! defined $CsrId) || (! defined $CrtId));
  die "Invalid certificate: the Node-ID does not match the request!!!\n" if ($CsrId ne $CrtId);
  die "$!\n" if (! open (KEY, ">$ETC/$Instance.key"));
  print KEY "$Key\n";
  print KEY "$Crt\n";
  close KEY;
  chmod (0600, "$ETC/$Instance.key");
}
#------------------------------------------------------------------------------
# Display the info
#------------------------------------------------------------------------------
($Before) = ($Crt =~ /Before:\s*(\w.+)\n/i); $Before = ""  if (! defined $Before);
($After)  = ($Crt =~ /After :\s*(\w.+)\n/i); $After  = ""  if (! defined $After);
$NodeId   = "";
if (defined $CsrId) { $NodeId = $CsrId; }
if (defined $CrtId) { $NodeId = $CrtId; }

print STDERR "RequestKey.pl v$main::VERSION - Copyright (C) $main::COPYRIGHT\n";
print STDERR "\n";
print STDERR "  Nagios Node instance : $Instance\n";
if (! -l "$ETC/$Instance.key")
{
	print STDERR "  Nagios Node KEY-file : $ETC/$Instance.key\n";
}
else
{
	print STDERR "  Nagios Node KEY-file : $ETC/$Instance.key => ".basename(Cwd::abs_path("$ETC/$Instance.key"))."\n";
}
print STDERR "  Nagios Node ID       : $NodeId\n";
if ($Before eq "")
{
  if (-r "$ETC/$Instance.csr")
  {
    print STDERR "  Nagios Node CSR-file : $ETC/$Instance.csr\n";
    print STDERR "\n";
    print STDERR "  Please send the CSR-file by mail to UMF Operations for signing.\n";
    print STDERR "  Do NOT include the KEY-file as it contains the PRIVATE key !!!.\n";
   }
   else { print STDERR "\n  '$ETC/$Instance.key' does NOT contain a certificate !!!\n"; }
}
else
{
  print STDERR "  Valid from           : $Before\n";
  print STDERR "  Valid until          : $After\n";
  Format ($ETC, $Instance, $Key, $Crt);
}
print STDERR "\n";
print STDERR "This script is part of the Nagios Node (UMF) software. Only use this script as\n";
print STDERR "instructed by the department responsible for Nagios Node (UMF) Operations.\n";
exit (0);
#------------------------------------------------------------------------------
sub Format
{
	my ($ETC, $Instance, $Key, $Crt) = @_;
	my ($File, $Handle, $Data);
	#----------------------------------------------------------------------
	$File = Cwd::abs_path ("$ETC/$Instance.key");
	open ($Handle, $File) || die ("Error reading key: $!\n");
	$Data = do { local $/ = <$Handle>; }; close ($Handle);
	return if ($Data eq "$Key\n$Crt\n");
	print STDERR "\n";
	if ($#ARGV > 0)
	{
		if ($ARGV[1] =~ /^cleanup$/i)
		{
			move ($File, "$File.dirty")  || die ("Error moving key: $!\n");
			open ($Handle, ">$File") || die ("Error writing key: $!\n");
			print $Handle "$Key\n";
			print $Handle "$Crt\n";
			close $Handle;
			chmod (0600, $File);
			$File = basename ($File);
			print STDERR "NOTICE: The KEY-file has been updated to be acceptable by the NSS library.\n";
			print STDERR "        The original KEY-file has been saved as '$File.dirty'.\n";
			return;
		}
	}
	print STDERR "WARNING: The KEY-file is 'dirty' and would be rejected by the NSS library.\n";
	print STDERR "         Use 'RequestKey.pl $Instance cleanup' to regenerate the KEY-file.\n";
	#----------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
sub Usage
{
	my ($Message) = @_;
	print STDERR "RequestKey.pl v$main::VERSION - Copyright (C) $main::COPYRIGHT\n";
	print STDERR "\n";
	if (defined $Message) { print STDERR "  $Message\n\n"; }
	print STDERR "  Usage:  RequestKey.pl <instance> [<node-ID>|<CRT-file>]\n";
	print STDERR "\n";
	print STDERR "  - Only specify <instance> to show the key (default instance 'NagiosNode').\n";
	print STDERR "  - Specify <node-ID> to generate a Certificate Signing Request (CSR-file).\n";
	print STDERR "  - Specify <CRT-file> to install the Certificate from the specified file.\n";
	print STDERR "\n";
	print STDERR "This script is part of the Nagios Node (UMF) software. Only use this script as\n";
	print STDERR "instructed by the department responsible for Nagios Node (UMF) Operations.\n";
	exit (1);
}
#------------------------------------------------------------------------------
#[eof]
