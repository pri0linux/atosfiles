#!/usr/bin/env perl
#------------------------------------------------------------------------------
# /opt/Nagios/Node/NagiosNode.pl - Nagios Node script
#------------------------------------------------------------------------------
use strict;
use warnings;

die "Do NOT run as root" if ($< == 0);
die "MUST run as nagios\n" if (getpwuid($<) ne "nagios");

use lib "/opt/Nagios/Node";
use Nagios::Node;

$main::Stop = 0;
$SIG{'INT'}  = sub { $main::Stop++; print "\r"; }; 
$SIG{'TERM'} = sub { $main::Stop++; print "\r"; }; 

exit Nagios::Node(@ARGV);
#------------------------------------------------------------------------------
#[eof]
