#!/usr/bin/env perl
#------------------------------------------------------------------------------
package Nagios::Node::Test; # Test 'curl' connection to the TMDX Servers
#------------------------------------------------------------------------------
use strict;
use warnings;

use Fcntl qw(:DEFAULT :flock);
use File::Path;
use POSIX;
use Sys::Hostname;

die "Do NOT run as root" if ($< == 0);
die "MUST run as nagios\n" if (getpwuid($<) ne "nagios");

exit Test();
#------------------------------------------------------------------------------
sub Test
{
	my ($This, $Path, $File, $Lock, $Config, $Handle, $Pid, $Limit, $Output);
	#----------------------------------------------------------------------
	# Initialize
	#----------------------------------------------------------------------
	$This = bless ({ hostname => hostname() }, "Nagios::Node::Test");
	chomp ($This->{curl} = `which curl 2>/dev/null`);
	die "curl not found\n" if (! $This->{curl});
	die ("Usage: $0 <key-file> <tmdx-server> [<proxy-server>]\n") if ($#ARGV<1);
	($This->{key}, $This->{server}, $This->{proxy}) = @ARGV;
	die "$This->{key} not found\n" if (! -r $This->{key});
	$ENV{https_proxy} = $This->{proxy};
	$ENV{HTTPS_PROXY} = $This->{proxy};
	delete ($ENV{'https_proxy'}) if (! $This->{proxy});
	delete ($ENV{'HTTPS_PROXY'}) if (! $This->{proxy});
	$Path = "/var/Nagios/Node/Test"; mkpath ($Path) if (! -d $Path);
	$File = "$Path/Curl.lock"; 
	die ("$!\n") if (! sysopen ($Lock, $File, O_WRONLY | O_NONBLOCK | O_CREAT));
    die ("$!\n") if (! flock ($Lock, LOCK_EX | LOCK_NB));
	#----------------------------------------------------------------------
	# Compose the curl command
	#----------------------------------------------------------------------
	$Config = "$Path/Curl.config";
	die ("$!\n") if (! open ($Handle, ">$Config"));
	print $Handle "-A NagiosNode/TestCurl ($This->{hostname})\n";
	print $Handle "-E $This->{key}\n";
	print $Handle "--header \"Cookie: Time=".time()."\"\n";
	print $Handle "-D $Path/Curl.head\n";
	print $Handle "-o $Path/Curl.body\n";
	print $Handle "-k\n";     # don't check the server certificate
	print $Handle "-s\n-S\n"; # silent except for error messages
	print $Handle "--url https://$This->{server}/Tmdx/Server/Test.php?".time()."\n";
	close ($Handle);
	#----------------------------------------------------------------------
	# Execute the curl command
	#----------------------------------------------------------------------
	print "GET https://$This->{server}/Test.php ...\n";
	unlink ("$Path/Curl.head");
	unlink ("$Path/Curl.body");
	$Pid  = fork();
	die ("$!\n") if (! defined $Pid);
	if (! $Pid) # child
	{ 
		exec ($This->{curl},"-K",$Config) || print $!; 
		exit (0); 
	}
	$Limit = time() + 15;
	while (! waitpid ($Pid, WNOHANG))
	{
		if (time() >= $Limit) { kill (9, $Pid); die ("TIMEOUT !!!\n"); }
		sleep (1);
	}
	#----------------------------------------------------------------------
	# Show the results
	#----------------------------------------------------------------------
	$Output = "";
	if (open ($Handle, "$Path/Curl.head"))
	{
		$Output .=  do { local $/ = <$Handle> };
		close ($Handle);
	}
	if (open ($Handle, "$Path/Curl.body"))
	{
		$Output .=  do { local $/ = <$Handle> };
		close ($Handle);
	}
	print "\n$Output\n";
	#----------------------------------------------------------------------
	return 0;
}
#------------------------------------------------------------------------------
#[eof]
