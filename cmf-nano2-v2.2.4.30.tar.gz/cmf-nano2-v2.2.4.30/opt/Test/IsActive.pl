#!/usr/bin/env perl
#------------------------------------------------------------------------------
package Nagios::Node::Test; # Test the Nagios Node 'IsActive' fucntionality
#------------------------------------------------------------------------------
use strict;
use warnings;

use File::Basename;

die "Do NOT run as root" if ($< == 0);
die "MUST run as nagios\n" if (getpwuid($<) ne "nagios");

exit Test();
#------------------------------------------------------------------------------
sub Test
{
    my ($This, $Method, $Params, $Module, $Warn, $Node, $Eval, $Active);
	#----------------------------------------------------------------------
	$This = bless ({}, "Nagios::Node::Test");
	die ("Usage: $0 <instance> <method>:<parameters>\n") if ($#ARGV < 1);

    ($Method, $Params) = split (/:/, $ARGV[1], 2);
    $Method = "" if (! defined $Method);
    $Params = "" if (! defined $Params);

    $Module = "/opt/Nagios/Node/Nagios/Node/IsActive/".lc($Method).".pm";
    if (! -r $Module) {
        $Warn = "Module not found: $Module\n";
        $Module = dirname($0)."/".lc($Method).".pm";
        die ($Warn."Module not found: $Module\n") if (! -r $Module);
    }
    
	$Node = bless ({}, "Nagios::Node");
	$Node->{Instance} = $ARGV[0];
    
    $Eval  = "require \"$Module\";\n";
    $Eval .= "\$Active = \$Node->IsActive_".lc($Method)."(\$Params);\n";
    eval ($Eval);
    $Node->{Error} = $@ if ($@);
    die ("$Node->{Error}\n") if ($Node->{Error});
    print "Active = $Active\n";
	#----------------------------------------------------------------------
	return 0;
}
#------------------------------------------------------------------------------
#[eof]
