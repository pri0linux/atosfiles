#!/usr/bin/env perl
#------------------------------------------------------------------------------
package Nagios::Node::Test; # Test 'wget' connection to the TMDX Servers
#------------------------------------------------------------------------------
use strict;
use warnings;

use Fcntl qw(:DEFAULT :flock);
use File::Path;
use POSIX;
use Sys::Hostname;

die "Do NOT run as root" if ($< == 0);
die "MUST run as nagios\n" if (getpwuid($<) ne "nagios");

exit Test();
#------------------------------------------------------------------------------
sub Test
{
	my ($This, $Path, $File, $Lock, @Wget, $Handle, $Pid, $Limit, $Output);
	#----------------------------------------------------------------------
	# Initialize
	#----------------------------------------------------------------------
	$This = bless ({ hostname => hostname() }, "Nagios::Node::Test");
	chomp ($This->{wget} = `which wget 2>/dev/null`);
	die "wget not found\n" if (! $This->{wget});
	die ("Usage: $0 <key-file> <tmdx-server> [<proxy-server>]\n") if ($#ARGV<1);
	($This->{key}, $This->{server}, $This->{proxy}) = @ARGV;
	die "$This->{key} not found\n" if (! -r $This->{key});
	$ENV{https_proxy} = $This->{proxy};
	$ENV{HTTPS_PROXY} = $This->{proxy};
	delete ($ENV{'https_proxy'}) if (! $This->{proxy});
	delete ($ENV{'HTTPS_PROXY'}) if (! $This->{proxy});
	$Path = "/var/Nagios/Node/Test"; mkpath ($Path) if (! -d $Path);
	$File = "$Path/Wget.lock"; 
	die ("$!\n") if (! sysopen ($Lock, $File, O_WRONLY | O_NONBLOCK | O_CREAT));
    die ("$!\n") if (! flock ($Lock, LOCK_EX | LOCK_NB));
	#----------------------------------------------------------------------
	# Compose the wget command
	#----------------------------------------------------------------------
	@Wget = ($This->{wget});		
	push (@Wget, "-U", "NagiosNode/TestWget ($This->{hostname})");
	push (@Wget, "--certificate=$This->{key}");
	push (@Wget, "--header", "Cookie: Time=".time());
	push (@Wget, "--no-proxy") if (! $This->{proxy});
	push (@Wget, "-O", "$Path/Wget.data"); # response file
	push (@Wget, "--save-headers"); # include response headers in response file
	push (@Wget, "--no-check-certificate"); # don't check the server certificate
	push (@Wget, "-nv"); # only show error messages and basic information
	push (@Wget, "https://$This->{server}/Tmdx/Server/Test.php?".time());
	#----------------------------------------------------------------------
	# Execute the wget command
	#----------------------------------------------------------------------
	print "GET https://$This->{server}/Test.php ...\n";
	unlink ("$Path/Wget.data");
	$Pid  = fork();
	die ("$!\n") if (! defined $Pid);
	if (! $Pid) # child
	{ 
		exec (@Wget) || print $!; 
		exit (0); 
	}
	$Limit = time() + 15;
	while (! waitpid ($Pid, WNOHANG))
	{
		if (time() >= $Limit) { kill (9, $Pid); die ("TIMEOUT !!!\n"); }
		sleep (1);
	}
	#----------------------------------------------------------------------
	# Show the results
	#----------------------------------------------------------------------
	$Output = "";
	if (open ($Handle, "$Path/Wget.data"))
	{
		$Output .=  do { local $/ = <$Handle> };
		close ($Handle);
	}
	print "\n$Output\n";
	#----------------------------------------------------------------------
	return 0;
}
#------------------------------------------------------------------------------
#[eof]
