#!/usr/bin/env perl
#------------------------------------------------------------------------------
# /opt/Nagios/Node/RestartNagios.pl - Nagios Restart script
#------------------------------------------------------------------------------

  use strict;
  use warnings;

  die "Do NOT run as root" if ($< == 0);
  die "MUST run as nagios\n" if (getpwuid($<) ne "nagios");
  die "Usage: RestartNagios.pl <instance>\n" if ($#ARGV != 0);

  my ($Var, $Pid, $Try, $Kill, $Restart);
  #--------------------------------------------------------------------
  # Validate the specified instance
  #--------------------------------------------------------------------
  $Var = "/var/Nagios/Node/$ARGV[0]";
  die "File not found: '$Var/nagios.cfg'\n" if (! -r "$Var/nagios.cfg");
  #--------------------------------------------------------------------
  # Stop the specified nagios process
  #--------------------------------------------------------------------
  $Pid = `cat /var/Nagios/Node/$ARGV[0]/nagios.pid 2>/dev/null`;
  chomp $Pid;
  if ($Pid)
  {
    print "Stopping nagios process $Pid ...\n";

    for ($Try = 0, $Kill = 15; $Try < 60; $Try++)
    {
      $Kill = 9 if ($Try >= 60); # Force kill after 60 seconds
      last if (! kill ($Kill, $Pid));
      if ($Kill == 9)
      {
        print "KILL(-9) nagios process $Pid !!!\n";
      }
	  if ($Try == 10) { print "  ... trying for another 50 seconds ...\n";}
	  if ($Try == 20) { print "  ... trying for another 40 seconds ...\n";}
	  if ($Try == 30) { print "  ... trying for another 30 seconds ...\n";}
	  if ($Try == 40) { print "  ... trying for another 20 seconds ...\n";}
	  if ($Try == 50) { print "  ... trying for another 10 seconds ...\n";}
      sleep (1);
    }
  }
  #--------------------------------------------------------------------
  # Start the nagios process again
  #--------------------------------------------------------------------
  unlink "$Var/rw/nagios.cmd";
  $Restart = system ("/opt/Nagios/Node/nagios -d $Var/nagios.cfg");
  if ($Restart == -1) 
  {
    die "Nagios failed to start: $!\n";
  }
  elsif ($Restart & 127) 
  {
    die sprintf ("Nagios died with signal %d (%s coredump)\n", ($Restart & 127),  ($Restart & 128) ? 'with' : 'without');
  }
  elsif ($Restart != 0)
  {
    die sprintf ("Nagios exited with value %d\n", $Restart >> 8);
  }
  print "Started nagios successfully\n";
  #--------------------------------------------------------------------
  exit (0);

#------------------------------------------------------------------------------
#[eof]
