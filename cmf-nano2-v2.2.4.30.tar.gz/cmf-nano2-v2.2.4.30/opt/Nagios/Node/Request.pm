package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Request.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Request
{
	my ($This, $Info, $Data) = @_;
	my ($Config, $Instance, $Var, $Log, @Action, $Module, $Method);
	#----------------------------------------------------------------------
	$Config   = $This->{"Config"};
	$Instance = $This->{"Instance"};
	$Var      = "/var/Nagios/Node/$Instance";
	$Log      = $This->{"Log"};
	if (! exists $Info->{action})
	{
		$Log->Log ("  Ignoring request without 'action' parameter."); 
		return undef;
	}
	@Action = split (/\//, $Info->{action});
	foreach (@Action) { $_ = ucfirst(lc($_)); }
	$Module = join ("/", "/opt/Nagios/Node/Nagios/Node/Request", @Action).".pm";
	if (! -r $Module)
	{
		$Log->Log ("  Ignoring unsupported '$Info->{action}' request."); 
		return undef;
	}
	eval ("require \"\$Module\";");
	if ($@)
	{
		$Log->Log ("  Failed to load $Module\n  $@"); 
		return undef;
	}
	$Method = join ("_", "Request", @Action);
	eval ("\$This->$Method (\$Info, \$Data);");
	if ($@)
	{
		$Log->Log ("  Failed to execute '\$This->$Method (\$Info, \$Data)'\n  $@"); 
		return undef;
	}
	#----------------------------------------------------------------------
	return undef;
}
#------------------------------------------------------------------------------
1;
 