package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Nmon.pm
#------------------------------------------------------------------------------
@Nagios::Node::Nmon::ISA = ("Nagios::Node");

use strict;
use warnings;

use Tmdx::Lock;
use Tmdx::Log;

use Nagios::Node::Nmon::Upload;
#------------------------------------------------------------------------------
sub Nmon
{
	my ($This, $Command) = @_;
	my ($Config, $Instance, $Var, $Lock, $Log, $Wait);
	#----------------------------------------------------------------------
	# Initialize, lock & start logging
	#----------------------------------------------------------------------
	# die ("") if ($#ARGV < 1); # Interactive only !!!
	#----------------------------------------------------------------------
	die ("Usage: Nagios::Node->Nmon();") if (ref($This) ne "Nagios::Node");
	$This->{"Lock"} = undef;
	$This->{"Log"}  = undef;
	bless ($This, "Nagios::Node::Nmon");

	$Config   = $This->{"Config"};
	$Instance = $This->{"Instance"};
	$Var      = "/var/Nagios/Node/$Instance";

	$This->{Debug} = $Config->{"debug"} || $Config->{"debug.nmon"};

	$Lock     = Tmdx::Lock->new ("$Var/Nmon.pid");
	die ($Lock->Error()."\n") if (defined $Lock->Error());
	if (! $Lock->Lock()) 
	{ 
		die ($Lock->Error()."\n") if (defined $Lock->Error());
		die "The Nagios Node Nmon process is already active ...\n";
	}
	$This->{"Lock"} = $Lock;

	$0 = $Command."->Nmon()";
	$Log = Tmdx::Log->new ("$Var/log", "Nmon.log", undef, undef, 1);
	$Log->Log ("------------------------------------------------------------------------------",
	           "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
	$This->{"Log"} = $Log;
	#------------------------------------------------------------------------
	# Start processing until the end of time ...
	#------------------------------------------------------------------------
	while (! $main::Stop)
	{
		$Lock->Touch();
		last if (time() >= $Config->{'endtime'});
		next if ($This->Upload()); # no sleep if more data is waiting
		for ($Wait = 0; $Wait < 20; $Wait++) {
			last if ($main::Stop);
			sleep (1);
		}
	} 
	$Log->Log ("Done ...");
	$Log->Close();
	$Lock->Unlock();
	#------------------------------------------------------------------------
	return 0;
}
#------------------------------------------------------------------------------
1;
 