package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Checks.pm
#------------------------------------------------------------------------------
@Nagios::Node::Checks::ISA       = ("Nagios::Node");

use strict;
use warnings;
use Storable;

use Nagios::Node::CoreCommand;

use Tmdx::Lock;
use Tmdx::Log;

#------------------------------------------------------------------------------
sub Checks
{
  my ($Checks, $Command) = @_;
  my ($Config, $Instance, $Var, $Lock, $Objects, $Status, $Delete, $Log);
  my (@Report, $Object, $Uuid, $Check, @Command, $Require, $Period, $Time);
  my ($Eval, @Result, $Report);
  #------------------------------------------------------------------------
  # Initialize, lock & start logging
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->Checks();") if (ref($Checks) ne "Nagios::Node");
  $Checks->{"Lock"} = undef;
  $Checks->{"Log"}  = undef;
  bless ($Checks, "Nagios::Node::Checks");

  $Config   = $Checks->{"Config"};
  $Instance = $Checks->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";

  $Lock     = Tmdx::Lock->new ("$Var/Checks.pid");
  die ($Lock->Error()."\n") if (defined $Lock->Error());
  if (! $Lock->Lock()) 
  { 
    die ($Lock->Error()."\n") if (defined $Lock->Error());
    die "The Nagios Node Checks process is already active ...\n";
  }
  $Checks->{"Lock"} = $Lock;
  $0 = $Command."->Checks()";

  eval { $Objects = Storable::lock_retrieve ("$Var/Checks.pds"); };
  return 0 if (ref($Objects) ne "HASH");

  eval { $Status = Storable::lock_retrieve ("$Var/Checkstatus.pds"); };
  $Status = {} if (ref($Status) ne "HASH");
  foreach $Uuid (keys %$Status)
  {
    $Delete = 1;
    foreach $Object (keys %$Objects)
    {
      foreach (keys %{$Objects->{$Object}})
      {
        next if ($_ ne $Uuid);
        $Delete = 0;
      }
    }
    delete $Status->{$Uuid} if ($Delete);
  }

  #------------------------------------------------------------------------
  # Process all passive NaNo checks
  #------------------------------------------------------------------------
  $Log = Tmdx::Log->new ("$Var/log", "Checks.log", undef, undef, 1);
  $Log->Log ("------------------------------------------------------------------------------",
             "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
  $Checks->{"Log"} = $Log;

  $Log->Log ("  Parsing timeperiods not yet implemented: assuming '7x24'");

  @Report = ();
  foreach $Object (keys %$Objects)
  {
    foreach $Uuid (keys %{$Objects->{$Object}})
    {
      $Check = $Objects->{$Object}{$Uuid};
      $Status->{$Uuid} = {} if (! exists $Status->{$Uuid});
      next if (! exists $Check->{"host_name"});

      next if (! exists $Check->{"check_command"});
      next if ($Check->{"check_command"} !~ /^nano\s*\!/i);

      next if (! exists $Check->{"check_period"});
      $Period = $Check->{"check_period"}; # Not yet parsed: assuming '7x24'
      
      $Log->Log ("Checking $Object '$Uuid': $Check->{check_command}");

      @Command = split (/\!/, $Check->{"check_command"}, 3);
      $Command[1] =~ s/\s//g;
      $Command[1] = ucfirst(lc($Command[1]));
      $Command[1] = "Bot" if ($Command[1] =~ /\.bot$/);
      $Require = "/opt/Nagios/Node/Nagios/Node/Checks/$Command[1].pm";
      $Time = time();
      if (-r $Require)
      {
        $Eval  = "require \"$Require\";\n";
        $Eval .= "\@Result = \$Checks->$Command[1](\$Check,\@Command);\n";
        eval ($Eval);  
        if ($@)
        {
          $@ =~ s/\n.*$//;
          $Log->Log ("  $@");
          @Result = (3, "Internal 'NaNo!$Command[1]' error");
        }
      }
      else { @Result = (3, "Unsupported 'NaNo!$Command[1]' command"); }

      $Status->{$Uuid}{"checked"} = $Time;
      next if ($#Result < 1);
      $Status->{$Uuid}{"state"}   = $Result[0];

      $Result[1] =~ s/\\/\\\\/g;
      $Result[1] =~ s/\n/\\n/g;
      $Log->Log ("  $Result[0]: $Result[1]");

      $Report  = "PROCESS_".uc($Object)."_CHECK_RESULT;".$Check->{"host_name"};
      $Report .= ";".$Check->{"service_description"} if (exists $Check->{"service_description"});
      $Report .= ";$Result[0];$Result[1]";
      push (@Report, $Report);
    }
    if ($Checks->CoreCommand (@Report))
    {
      eval { Storable::lock_nstore ($Status, "$Var/Checkstatus.pds"); };
    }
  }

  $Log->Log ("Done ...");
  $Log->Close();
  $Lock->Unlock();
  #------------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
 
