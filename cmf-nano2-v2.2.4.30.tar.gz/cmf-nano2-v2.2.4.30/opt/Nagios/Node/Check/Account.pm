package Nagios::Node::Check;
#------------------------------------------------------------------------------
# Nagios/Node/Check/Account.pm - Check the nagios account
#------------------------------------------------------------------------------
use strict;
use warnings;
use POSIX;
#------------------------------------------------------------------------------
sub Account
{
	my ($Check, @Arg) = @_;
	my ($User, $Eval, @Chage, $Warn, $Crit, @M, $M, $Count, $State, $Output);
	my ($Perfdata, $Chage, $Item, $Action, $Date, $Days, @Date, @Time, $Time);
	#----------------------------------------------------------------------
	if (ref($Check) ne "Nagios::Node::Check")
	{
		print "Usage: Nagios::Node::Check->Account();\n"; 
		return 3;
	}
	$User = getpwuid($<);
	$Eval = "\@Chage = `chage -l $User`";
	eval ($Eval);
	if ($@)
	{
		print "Unable to check 'Account': failed to execute 'chage -l $User'\n";
		return 3;
	}
	$Warn     = ($#ARGV>1) ? int($ARGV[2]) : 0;
	$Crit     = ($#ARGV>2) ? int($ARGV[3]) : 0;
	@M        = ("jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec");
	$Count    = 0;
	$State    = 0;
	$Output   = "";
	$Perfdata = "";
	for $Chage (@Chage) 
	{
		chomp ($Chage = lc($Chage));
		($Item, $Action, $Date) = ($Chage =~ /^(\S+)\s+(\S+).+\:\s*(.+)$/);
		next if ($Action !~ /expires/i);
		$Days = undef;
		if ($Date !~ /never/i)
		{
			@Date = split (/[\s,]+/, $Date);
			@Time = (0, 0, 0, $Date[1], undef, $Date[2]-1900);
			for ($M = 0; $M < 12; $M++)
			{
				$Time[4] = $M if ($M[$M] eq lc($Date[0]));
			}
			$Time = mktime (@Time);
			$Days = int (($Time - time()) / 86400);
			$State = 1 if (($State < 1) && ($Warn > 0) && ($Days <= $Warn));
			$State = 2 if (($State < 2) && ($Crit > 0) && ($Days <= $Crit));
		}
		$Output .= ", " if ($Output ne "");
		$Output .= "$Item ";
		if (! defined $Days) { $Output .= "does not expire";       }
		elsif ($Days < 0)    { $Output .= "already expired";       }
		else                 { $Output .= "expires in $Days days"; }
		if (defined $Days)
		{
			$Perfdata .= " " if ($Perfdata ne "");
			$Perfdata .= lc($Item)."=$Days";
		}
		$Count++;
	}
	if ($Count < 2)
	{
		$State   = 3;
		$Output .= ", " if ($Output ne "");
		$Output .= "missing data";
	}
	print ucfirst "$Output|state=$State $Perfdata\n";
	#----------------------------------------------------------------------
	return $State;
}
#------------------------------------------------------------------------------
1;
