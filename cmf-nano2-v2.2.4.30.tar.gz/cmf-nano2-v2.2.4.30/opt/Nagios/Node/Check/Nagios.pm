package Nagios::Node::Check;
#------------------------------------------------------------------------------
# Nagios/Node/Check/Nagios.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Nagios
{
  my ($Check) = @_;
  my ($Config, $Instance, $Var, $Pid);
  my ($Verify, $Status, $Warnings, $Errors, $Message);
  #------------------------------------------------------------------------
  # Initialize
  #------------------------------------------------------------------------
  if (ref($Check) ne "Nagios::Node::Check")
  {
    print "Usage: Nagios::Node::Check->Nagios();\n"; 
    return 3;
  }
  $Config   = $Check->{"Config"};
  $Instance = $Check->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";
  #------------------------------------------------------------------------
  # Check if nagios is running
  #------------------------------------------------------------------------
  if (! $Check->{"State"}{"IsActive"})
  {
    print "This Nagios Node is not active\n";
    return 0; # OK
  }
  if (! -r "$Var/nagios.pid") 
  {
    print "'$Var/nagios.pid' not found|state=3;1;2;0;3\n";
    return 3; # UNKNOWN
  }
  $Pid = `cat $Var/nagios.pid`;
  chomp $Pid;
  if (! kill (0, $Pid)) 
  { 
    print "Nagios is not running|state=3;1;2;0;3\n"; 
    return 3; # UNKNOWN
  }
  #------------------------------------------------------------------------
  # Check the verification log
  #------------------------------------------------------------------------
  if (! -r "$Var/verify.log") 
  { 
    print "'$Var/verify.log' not found|state=3;1;2;0;3\n";
    return 3; 
  }
  $Verify = `cat $Var/verify.log`; 
  $Status = 0;
  ($Warnings) = ($Verify =~ /^Total Warnings:\s(\d+)/m );
  ($Errors)   = ($Verify =~ /^Total Errors:\s(\d+)/m );
  if (! $Warnings) { $Warnings = 0; }
  if (! $Errors)   { $Errors   = 0; }
  $Message = "Things look okay";
  if ($Warnings > 0) { $Status = 1; ($Message) = ($Verify =~ /^(Total Warnings:\s\d+)/m ); }
  if ($Errors   > 0) { $Status = 2; ($Message) = ($Verify =~ /^(Total Errors:\s\d+)/m );  }
  if (($Status == 0) && (! ($Verify =~ /Things look okay/))) 
  {
    print "Thinks do NOT look okay|state=3;1;2;0;3\n";
    return 3; 
  }
  print "$Message|state=$Status;1;2;0;3\n";
  #------------------------------------------------------------------------
  return $Status;
}
#------------------------------------------------------------------------------
1;
