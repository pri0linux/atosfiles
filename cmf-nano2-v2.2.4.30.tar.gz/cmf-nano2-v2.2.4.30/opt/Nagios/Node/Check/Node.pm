package Nagios::Node::Check;
#------------------------------------------------------------------------------
# Nagios/Node/Check/Node.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use Nagios::Node::Check::Node::Item;
#------------------------------------------------------------------------------
sub Node
{
  my ($Check) = @_;
  my (@Transmit, @Receive, $State);
  #------------------------------------------------------------------------
  if (ref($Check) ne "Nagios::Node::Check")
  {
    print "Usage: Nagios::Node::Check->Node();\n"; 
    return 3; # UNKNOWN
  }
  if (! $Check->{"State"}{"IsActive"})
  {
    print "This Nagios Node is not active\n";
    return 0; # OK
  }
  @Transmit = $Check->Node_Item ("Transmit");
  @Receive  = $Check->Node_Item ("Receive");
  if ($Transmit[0] > $Receive[0]) { $State = $Transmit[0]; } else { $State = $Receive[0]; }
  print "$Transmit[1], $Receive[1] (process/connect)|$Transmit[2] $Receive[2]\n";
  #--------------------------------------------------------------------
  return $State;
}
#------------------------------------------------------------------------------
1;
