package Nagios::Node::Check;
#------------------------------------------------------------------------------
# Nagios/Node/Check/Help.pm - Show usage instructions
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Help
{
	my ($Check) = @_;
	my $Version   = $main::VERSION;
	my $Copyright = $main::COPYRIGHT;
	#----------------------------------------------------------------------
	print STDERR <<EOF;
CheckNagiosNode.pl v$Version - Copyright (c) $Copyright

  Usage:  CheckNagiosNode.pl <instance> Account [<warn> [<crit>]]
          To check the nagios account and password expiration period.

          <instance>  is the configured Nagios Node instance to be used
          <warn>      is the warning threshold in days before expiring
          <crit>      is the critical threshold in days before expiring

  Usage:  CheckNagiosNode.pl <instance> Client <uuid>
          To check the status of the specified client. The warning, critical
          and unknown thresholds are read from the configuration file.

  Usage:  CheckNagiosNode.pl <instance> Nagios
          To check the nagios process and the nagios verification log.

  Usage:  CheckNagiosNode.pl <instance> Node
          To check the transmit and receive processes and connections. The
          warning and critical thresholds are hardcoded at 3 and 5 minutes 
          for the processes and 5 and 10 minutes for the connections.

  Usage:  CheckNagiosNode.pl <instance> Rsync
          To check the rsync heartbeat (only in failover environments). The 
          warning and critical thresholds are hardcoded at 3 and 5 minutes.

  Usage:  CheckNagiosNode.pl <instance> Tmdx
          To check the TMDX Client 'post' and 'get' heartbeats. The warning 
          and critical thresholds are hardcoded at 5 and 10 minutes.

  Notes:  Check the documentation to see if more detailed info is available


For INTERNAL use by Atos Common Monitoring Framework (CMF) Nodes ONLY.
EOF
	#----------------------------------------------------------------------
	return 3;
}
#------------------------------------------------------------------------------
1;
