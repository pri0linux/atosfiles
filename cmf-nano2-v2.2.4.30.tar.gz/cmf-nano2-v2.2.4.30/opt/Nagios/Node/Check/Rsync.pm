package Nagios::Node::Check;
#------------------------------------------------------------------------------
# Nagios/Node/Check/Rsync.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use POSIX;
#------------------------------------------------------------------------------
sub Rsync
{
  my ($Check) = @_;
  my ($Config, $Instance, $Var, @Stat, $Age, $State);
  #------------------------------------------------------------------------
  # Initialize
  #------------------------------------------------------------------------
  if (ref($Check) ne "Nagios::Node::Check")
  {
    print "Usage: Nagios::Node::Check->Nagios();\n"; 
    return 3;
  }
  $Config   = $Check->{"Config"};
  $Instance = $Check->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";
  #------------------------------------------------------------------------
  # Get the timestamp from the latest rsynced State.pds
  #------------------------------------------------------------------------
  @Stat = stat ("$Var.rsync/State.pds");
  if ($#Stat < 9)
  {
    print "$!|state=3;1;2;0;3 age=0s;180;300;0\n";
    return 3;
  }
  $Age   = time() - $Stat[9];
  $State = 0;
  $State = 1 if ($Age > 180);  
  $State = 2 if ($Age > 300);

  print strftime ("Rsync timestamp is from %Y-%m-%d @ %H:%M:%S UTC ($Age seconds ago)", gmtime($Stat[9]));
  print "|state=$State;1;2;0;3 age=".$Age."s;180;300;0\n";

  #------------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
