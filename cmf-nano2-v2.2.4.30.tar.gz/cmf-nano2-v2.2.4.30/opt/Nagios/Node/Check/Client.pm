package Nagios::Node::Check;
#------------------------------------------------------------------------------
# Nagios/Node/Check/Client.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use POSIX;
#------------------------------------------------------------------------------
sub Client
{
  my ($Check, @Arg) = @_;
  my ($Basename, $Config, $Instance, $Var, @Stat, $Age, $State, $Output);
  #------------------------------------------------------------------------
  if (ref($Check) ne "Nagios::Node::Check")
  {
    print "Usage: Nagios::Node::Check->Client();\n"; 
    return 3;
  }

  $Basename = $Check->{"Basename"};
  $Config   = $Check->{"Config"};
  $Instance = $Check->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";

  if ($#Arg != 2)
  {
    print "Usage: $Basename $Instance Client <uuid>\n";
    return 3; # UNKNOWN
  } 

  if (exists $Check->{"State"}{"IsActive"})
  {
    if (! $Check->{"State"}{"IsActive"})
    {
      print "This Nagios Node is not active\n";
      return 0; # OK
    }
  }

  @Stat = stat ("$Var/Clients/$Arg[2]/Client.dat");
  if ($#Stat < 9)
  {
    print "Client '$Arg[2]' not registered|state=3;1;2;0;3\n";
    return 3; # UNKNOWN
  }

  $Age    = time() - $Stat[9];
  $State  = 0;
  $State  = 1 if ($Age > $Config->{'client.warning'});
  $State  = 2 if ($Age > $Config->{'client.critical'});
  $State  = 3 if ($Age > $Config->{'client.unknown'});

  $Output  = "Client heartbeat: ";
  $Output .= strftime ("%Y-%m-%d @ %H:%M:%S", gmtime($Stat[9]));
  $Output .= " UTC|state=$State;1;2;0;3 age=$Age";
  $Output .= ";".$Config->{'client.warning'};
  $Output .= ";".$Config->{'client.critical'};
  $Output .= ";0";

  print "$Output\n";
  #------------------------------------------------------------------------
  return $State;
}
#------------------------------------------------------------------------------
1;
