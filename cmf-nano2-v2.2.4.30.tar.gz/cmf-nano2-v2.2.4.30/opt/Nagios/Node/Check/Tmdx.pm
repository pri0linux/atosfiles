package Nagios::Node::Check;
#------------------------------------------------------------------------------
# Nagios/Node/Check/Tmdx.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use Tmdx::Client::Check;
#------------------------------------------------------------------------------
sub Tmdx
{
  my ($Check) = @_;
  my ($Tmdx);
  if (ref($Check) ne "Nagios::Node::Check")
  {
    print "Usage: Nagios::Node::Check->Tmdx();\n"; 
    return 3;
  }
  if (! $Check->{"State"}{"IsActive"})
  {
    print "This Nagios Node is not active\n";
    return 0; # OK
  }
  $Tmdx = $Check->{"Tmdx"};
  return $Tmdx->Check();
}
#------------------------------------------------------------------------------
1;
