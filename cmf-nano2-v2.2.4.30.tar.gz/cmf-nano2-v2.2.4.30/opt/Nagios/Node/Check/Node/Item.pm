package Nagios::Node::Check;
#------------------------------------------------------------------------------
# Nagios/Node/Check/Node/Item.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Node_Item
{
  my ($Check, $Item) = @_;
  my ($Config, $Instance, $Var);
  my (@Seconds, @State, @Age, $State, $File, @Stat, $Time, $xp, $xc);
  #------------------------------------------------------------------------
  if (ref($Check) ne "Nagios::Node::Check")
  {
    print "Usage: Nagios::Node::Check->Node_Item();\n"; 
    exit 3;
  }
  $Config   = $Check->{"Config"};
  $Instance = $Check->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";
  @Seconds  = (0, 0);
  @State    = (3, 3);
  @Age      = ("?", "?");
  $State    = 0;
  $File     = "$Var/$Item";

  @Stat = stat ("$File.pid");
  if ($#Stat >= 9) 
  { 
    $Time = $Stat[9]; 
    $Seconds[0] = time() - $Time;
    if ($Seconds[0] < 1) { $Seconds[0] = 1; }
    if    ($Seconds[0] <=    180) { $State[0] = 0; }
    elsif ($Seconds[0] <=    300) { $State[0] = 1; }
    else                          { $State[0] = 2; }
    if    ($Seconds[0] <=    60) { $Age[0] = $Seconds[0]."s"; }
    elsif ($Seconds[0] <=  3600) { $Age[0] = int($Seconds[0]/60)."m"; }
    elsif ($Seconds[0] <= 86400) { $Age[0] = int($Seconds[0]/3600)."h"; }
    else                         { $Age[0] = int($Seconds[0]/86400)."d"; }
  }
  if ($State[0] > $State) { $State = $State[0]; }

  @Stat = stat ("$File.ack");
  if ($#Stat >= 9) 
  { 
    $Time = $Stat[9]; 
    $Seconds[1] = time() - $Time;
    if ($Seconds[1] < 1) { $Seconds[1] = 1; }
    if    ($Seconds[1] <=    300) { $State[1] = 0; }
    elsif ($Seconds[1] <=    600) { $State[1] = 1; }
    else                          { $State[1] = 2; }
    if    ($Seconds[1] <=    60) { $Age[1] = $Seconds[1]."s"; }
    elsif ($Seconds[1] <=  3600) { $Age[1] = int($Seconds[1]/60)."m"; }
    elsif ($Seconds[1] <= 86400) { $Age[1] = int($Seconds[1]/3600)."h"; }
    else                         { $Age[1] = int($Seconds[1]/86400)."d"; }
  }
  if ($State[1] > $State) { $State = $State[1]; }

  $xp = lc (substr ($Item, 0, 1))."p";
  $xc = lc (substr ($Item, 0, 1))."c";
  return ($State, "$Item heartbeat age $Age[0]/$Age[1]", "$xp=$Seconds[0]s;180;300;0; $xc=$Seconds[1]s;300;600;0;");
  #------------------------------------------------------------------------
}
#------------------------------------------------------------------------------
1;
