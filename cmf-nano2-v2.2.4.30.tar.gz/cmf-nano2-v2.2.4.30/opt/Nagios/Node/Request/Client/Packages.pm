package Nagios::Node;
#------------------------------------------------------------------------------
use strict;
use warnings;

use File::Copy;
#------------------------------------------------------------------------------
sub Request_Client_Packages
{
	my ($This, $Info, $Data) = @_;
	my ($Config, $Instance, $Var, $Log, $Client, $File, $Handle);
	#--------------------------------------------------------------------
	$Config   = $This->{Config};
	$Instance = $This->{Instance};
	$Var      = "/var/Nagios/Node/$Instance";
	$Log      = $This->{Log};
	#--------------------------------------------------------------------
	if (! exists $Info->{client})
	{
		$Log->Log ("  Ignoring 'Client/Packages' request without 'client' parameter");
		return undef;
	}
	$Client = $Info->{client};
	if (! -d "$Var/Client/$Client")
	{
		$Log->Log ("  Ignoring 'Client/Packages' for unknown client '$Client'");
		return undef;
	}
	$File = "$Var/Client/$Client/Packages.acl";
	if (open ($Handle, ">$File.tmp"))
	{
		print $Handle $Data;
		close ($Handle);
		move ("$File.tmp", $File);
		$Log->Log ("  Updated '$File'");
	}
	else { $Log->Log ("  WARNING: Unable to write '$File.tmp': $!"); }
	#--------------------------------------------------------------------
	return undef;
}
#------------------------------------------------------------------------------
1;
