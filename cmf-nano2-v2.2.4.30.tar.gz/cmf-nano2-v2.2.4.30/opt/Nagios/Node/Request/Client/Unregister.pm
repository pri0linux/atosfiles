package Nagios::Node;
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Request_Client_Unregister
{
	my ($This, $Info, $Data) = @_;
	my ($Config, $Instance, $Var, $Log);
	#--------------------------------------------------------------------
	$Config   = $This->{"Config"};
	$Instance = $This->{"Instance"};
	$Var      = "/var/Nagios/Node/$Instance";
	$Log      = $This->{"Log"};
	#--------------------------------------------------------------------
	$Log->Log ("Sorry, Client/Unregister not yet implemented ...");

#	use Data::Dumper;
#	print Data::Dumper->Dump ([$Info,$Data],["Info","Data"]);
	
	#--------------------------------------------------------------------
	return undef;
}
#------------------------------------------------------------------------------
1;
