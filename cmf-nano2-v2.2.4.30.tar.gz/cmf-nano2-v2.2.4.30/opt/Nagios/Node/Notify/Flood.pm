package Nagios::Node::Notify;
#------------------------------------------------------------------------------
# Nagios/Node/Notify/Flood.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

#------------------------------------------------------------------------------
sub Flood_Table_Initialize 
{
	my ($Notify) = @_;
	my ($var, $flood_tables);

	$Notify->{'Notify.flood_tables'} = {};

	$var = "/var/Nagios/Node/".$Notify->{'Instance'};
	open(my $lock, ">>", "$var/flood_lock") or die "Can't open lock $var/flood_lock: $!";
	close ($lock);
	#open to read/write and lock
	open($lock, "+<", "$var/flood_lock")
	    or die "Can't open lock $var/flood_lock: $!";
	flock($lock, 2);
	
	#retireve or initialize the data
	$flood_tables = eval { Storable::fd_retrieve ($lock) };
	if ( $@ ) {
		print "Serious error with fd_retrieve\n";
	}
	elsif ( not defined $flood_tables ) {
		print "Error with fd_retrieve\n";
	}
	elsif (  ref ($flood_tables) ne "HASH" ) {
		print "incorrect structure retrieved\n";
	}
	else {
		$Notify->{'Notify.flood_tables'} = $flood_tables;
	}

	$Notify->{'Notify.Flood.lock'} = $lock;
	return;
}

sub Flood_Table_Close {
	my ($Notify) = @_;

	my ($lock, $flood_tables);
	$lock        = $Notify->{'Notify.Flood.lock'};
	$flood_tables = $Notify->{'Notify.flood_tables'};

	seek ($lock, 0, 0);
	truncate ($lock, 0);
	eval { Storable::store_fd ($flood_tables, $lock) };
	close($lock) || warn "close failed: $!";
}

sub Flood_Load_Config {
	my ($Notify) = @_;
	my ($flood_table, $config);

	$flood_table = $Notify->{'Notify.flood_tables'};
	$config      = $Notify->{'Config'};

	my (@counter, @counters);
	my ($type, $value, $time, $threshold, $counter_type, $config_item);

	#e.g. 
	#notify.flood.nano = 200:3600;60:60
	for my $item (keys %$config) {
		next if $item !~ /notify\.flood/;
		($counter_type) = $item =~ /notify\.flood\.\s*(\S+)/; 
		@counters = split /;/, $config->{$item};
		for my $counter_item (@counters) {
			@counter = split /:/, $counter_item;
			$config_item->{lc ($counter_type)}{$counter[1]} = $counter[0]; #for later use
			for (@counter) {s/[^0-9\:\;]//g;}
			if ( scalar @counter != 2 ) {
				print "Warning, skipping this config entry as having incorrect number of parameters\n";
				next;
			}
	    	#special treatment for NaNo type counter
	    	if ( lc($counter_type) eq "nano" ) {
	    		my $found = 0;
	    		for my $nano_counter ( @{$flood_table->{'flood_counters'}{'NANO'}{'NANO'}} ) {
	    			if ( $nano_counter->{'time'} == $counter[1]) {
	    				if ( $nano_counter->{'threshold'} != $counter[0] ) {
	    					$nano_counter->{'threshold'} = $counter[0];
	    				}
	    				$found = 1; 
	    			}
	    		}
	    		if ( ! $found ) {
	    			push @{$flood_table->{'flood_counters'}{'NANO'}{'NANO'}}, {'time' => $counter[1], 'threshold' => $counter[0], 'index'=> 0};
	    		}
	    		
	    	}
			else {#non-nano counter defs
				my $found = 0;
				if ( defined $flood_table->{'flood_counter_defs'}{$counter_type} ) {
					for my $nonnano_counter ( @{$flood_table->{'flood_counter_defs'}{$counter_type}} ) {
	    				if ( $nonnano_counter->{'time'} == $counter[1]) {
	    					if ( $nonnano_counter->{'threshold'} != $counter[0] ) {
	    						$nonnano_counter->{'threshold'} = $counter[0];
	    					}
	    					$found = 1; 
	    				}
	    			}	
				}
				if ( ! $found ) {
	    			push @{$flood_table->{'flood_counter_defs'}{$counter_type}}, {'time' => $counter[1], 'threshold' => $counter[0]};
	    		}
	    		#non-nano counter may require update
	    		if ( defined $flood_table->{'flood_counters'}{$counter_type} ) {
					for my $nonnano_counter_value ( keys %{$flood_table->{'flood_counters'}{$counter_type}} ) {
					    for my $nonnano_counter ( @{$flood_table->{'flood_counters'}{$counter_type}{$nonnano_counter_value}} ) {	
	    					if ( $nonnano_counter->{'time'} == $counter[1] && $nonnano_counter->{'threshold'} != $counter[0]) {
	    						$nonnano_counter->{'threshold'} = $counter[0];
	    					} 
	    				}
	    			}	
				}
			}
		}
	    
	}
	####remove counters and defs that are not in config
	#defs first (and related counters)
	for my $counter_type_def ( keys %{$flood_table->{'flood_counter_defs'}} ) {
		my $def_count = (scalar @{$flood_table->{'flood_counter_defs'}{$counter_type_def}}) -1;
		for my $counter_def_index (0..$def_count) {
			my $time = $flood_table->{'flood_counter_defs'}{$counter_type_def}[$counter_def_index]{'time'};
			if ( ( ! defined $config_item->{$counter_type_def}) || ( ! defined $config_item->{$counter_type_def}{$time} ) ) {
				#remove def and all counters (as not in config)
				for my $counter_value (keys %{$flood_table->{'flood_counters'}{$counter_type_def}}) {
					my $counter_count = (scalar @{$flood_table->{'flood_counters'}{$counter_type_def}{$counter_value}}) - 1;
					for my $counter_index (0..$counter_count) {
						if ( $flood_table->{'flood_counters'}{$counter_type_def}{$counter_value}[$counter_index]{'time'} == $time ) {
							splice @{$flood_table->{'flood_counters'}{$counter_type_def}{$counter_value}}, $counter_index, 1;
							last;
						}
					}
					$counter_count = (scalar @{$flood_table->{'flood_counters'}{$counter_type_def}{$counter_value}}) - 1;
					if ( $counter_count == -1 ) { #empty table 
						delete $flood_table->{'flood_counters'}{$counter_type_def}{$counter_value};
					}
				}
				splice @{$flood_table->{'flood_counter_defs'}{$counter_type_def}}, $counter_def_index, 1;
				last;
			}
		}
		$def_count = (scalar @{$flood_table->{'flood_counter_defs'}{$counter_type_def}}) -1;
		if ( $def_count == -1 ) { #empty def table
			delete $flood_table->{'flood_counter_defs'}{$counter_type_def};
		}
	}
	#counters now (only NANO:NANO left)
	if ( defined $flood_table->{'flood_counters'}{'NANO'}) {
		my $counter_count = (scalar @{$flood_table->{'flood_counters'}{'NANO'}{'NANO'}}) -1;
		for my $counter_index (0..$counter_count) {
			my $time = $flood_table->{'flood_counters'}{'NANO'}{'NANO'}[$counter_index]{'time'};
			if ( ( ! defined $config_item->{'nano'} ) || ( ! defined $config_item->{'nano'}{$time} ) )  {
				splice @{$flood_table->{'flood_counters'}{'NANO'}{'NANO'}}, $counter_index, 1;
				last;
			}
		}
	}
}

sub Flood_Add_Notification {
	my ($Notify, $notification) = @_;
	my ($flood_table, $type, $rest);

	$flood_table = $Notify->{'Notify.flood_tables'};

	#enrich notification with servicecheckcommand_split and hostdown
	if ( ( defined $notification->{'nagios.servicecheckcommand'} ) && ( $notification->{'nagios.servicecheckcommand'} ne "" ))  {
		($type, $rest) = split /_/, $notification->{'nagios.servicecheckcommand'}, 2;	
		$notification->{'nagios.servicecheckcommand_split'} = $type;
	}
	if ( ( ! defined $notification->{'nagios.servicestate'} ) || ( $notification->{'nagios.servicestate'} eq "" ) ) { #host notification
		$notification->{'nagios.hostdown'} = $notification->{'nagios.hoststate'};
	}

	#check current counter definitions to see if new counter is needed
	for my $counter_type (keys %{$flood_table->{'flood_counter_defs'}}) {
		if ( defined $notification->{'nagios.'.$counter_type} ) {
			for my $counter_def (@{$flood_table->{'flood_counter_defs'}{$counter_type}}) {
				my $counter_found = 0;
				if ( defined $flood_table->{'flood_counters'}{$counter_type}{$notification->{'nagios.'.$counter_type}}) {
					for my $counter (@{$flood_table->{'flood_counters'}{$counter_type}{$notification->{'nagios.'.$counter_type}}}) {
						if ($counter->{'time'} == $counter_def->{'time'}) {
							$counter_found = 1;
							last;
						}
					}
				}
				if (! $counter_found ) {
					push @{$flood_table->{'flood_counters'}{$counter_type}{$notification->{'nagios.'.$counter_type}}}, {'time' => $counter_def->{'time'}, 'threshold' => $counter_def->{'threshold'},'index' => 0};
				} 
			}
		}
	}

	push @{$flood_table->{notifications}}, $notification;

	#make sure that notification array is sorted by time (sort it)
	$flood_table->{notifications} = [ sort {$a->{'nagios.timet'} <=> $b->{'nagios.timet'}} @{$flood_table->{notifications}} ];
}

sub Flood_Update {
	my ($Notify) = @_;
	my ($flood_table);

	$flood_table = $Notify->{'Notify.flood_tables'};

	my $notifications = $flood_table->{notifications};
	my $counters      = $flood_table->{flood_counters};

	my ($items_to_remove, $time_mark, $index, $min_index, $counter_updated);

	my @unwanted_types = ();
	for my $counter_type (keys %$counters) {
		my @unwanted_values = ();
		for my $counter_value ( keys %{$counters->{$counter_type}} ) {
			for my $counter_index (0.. (scalar @{$counters->{$counter_type}{$counter_value}} - 1)) {
				my $counter = ${$counters->{$counter_type}{$counter_value}}[$counter_index];
				$time_mark= time() - $counter->{time};
				$index = $counter->{index};
				##move indices right till those are in proper place (index can go outside table meaning no notifications meet threhsold)
				$counter_updated = 0;
				while ( $index < scalar @$notifications && ! $counter_updated )  { #to no go out of bounds  				  
					if ( $counter_type eq 'NANO' && $notifications->[$index]{'nagios.timet'} < $time_mark ) {
						$counter->{index}++;
						$index = $counter->{index};
					}
					elsif ( ( $counter_type ne 'NANO' ) && ( ( ( $notifications->[$index]{'nagios.'.$counter_type}//'Undef' ) ne $counter_value ) || ( $notifications->[$index]{'nagios.timet'} < $time_mark ) ) ) {
	   				    $counter->{index}++;
						$index = $counter->{index};
					}
					else {
						$counter_updated = 1; #move to next counter
					}
				}
				#zero counter marked with undef to be deleted after whole iteration
				if ( $counter->{index} == scalar @$notifications ) {
					undef ${$counters->{$counter_type}{$counter_value}}[$counter_index];
				}
			}
			#remove zero counters
			@{$counters->{$counter_type}{$counter_value}} = grep {defined} @{$counters->{$counter_type}{$counter_value}};
			if ( scalar @{$counters->{$counter_type}{$counter_value}} == 0 ) {
				push @unwanted_values, $counter_value;
			}
		}
		delete @{$counters->{$counter_type}}{@unwanted_values};
		if ( !keys %{$counters->{$counter_type}}) {
			push @unwanted_types, $counter_type;
		}
	}
	delete @{$counters}{@unwanted_types};

	#figure out index of smallest counter
	$min_index=scalar @$notifications;
	for my $counter_type (keys %$counters) {
		for my $counter_value ( keys %{$counters->{$counter_type}} ) {
			for my $counter (@{$counters->{$counter_type}{$counter_value}}) {
				if ($counter->{index} < $min_index ) {
					$min_index=$counter->{index};
				}
			}
		}
	}
			
	#notifications with smaller index than min_index are not needed, removing and adjusting counters indices
	if ( $min_index > 0 ) {
	splice (@$notifications, 0, $min_index);
	for my $counter_type (keys %$counters) {
		for my $counter_value ( keys %{$counters->{$counter_type}} ) {
			for my $counter (@{$counters->{$counter_type}{$counter_value}}) {
				$counter->{index} -= $min_index;
			}
		}
	}
	}	
}

sub Flood_Is_Flood {
	my ($Notify, $Data) = @_;
	my ($flood_table, $notifications, $counters, $flood_count, $flood_result, $flood_message, $flooding_type);

	$flood_table = $Notify->{'Notify.flood_tables'};
	$notifications      = $flood_table->{notifications};
	$counters           = $flood_table->{flood_counters};
	$flood_count        = 0;
	$flood_result       = 0;
	$flood_message      = "   ";
	$flooding_type      = {};

    for my $counter_type (keys %$counters) {
        for my $counter_value ( keys %{$counters->{$counter_type}} ) {
            for my $counter (@{$counters->{$counter_type}{$counter_value}}) {
				$flood_count = Flood_is_flood_for_counter($notifications, $counter, $counter_type, $counter_value);
				$flood_message .= " $counter_type:$counter_value:$flood_count (".$counter->{'threshold'}."/".$counter->{'time'}."),";
				if ( $flood_count > $counter->{'threshold'} ) {
					$flood_result++;
					$flooding_type->{$counter_type}=$counter_value;
				}
			}
		}
	}
    $Notify->{'Notify.flood_message'} = $flood_message;
    $Notify->{'Notify.flooding_type'} = $flooding_type;
    #flood start
    if ( ( $flood_table->{'is_flood'} == 0 ) && ( $flood_result > 0 ) ) {
    	$Notify->{"Log"}->Log("    Sending notification to UMF Operation team about flood start");
    	Flood_notify_ops_team($Notify->{Tmdx}, $Notify->{Config}, $Data, "start");
    } 
    if ( ( $flood_table->{'is_flood'} != 0 ) && ( $flood_result == 0 ) ) {
    	$Notify->{"Log"}->Log("    Sending notification to UMF Operation team about flood end");
    	Flood_notify_ops_team($Notify->{Tmdx}, $Notify->{Config}, $Data, "stop");
    }
    $flood_table->{'is_flood'} = $flood_result;
    $Notify->{'Notify.is_flood'} = $flood_result;
	return $flood_result;
}

sub Flood_is_flood_for_counter {
	my ($notifications, $counter, $counter_type, $counter_value) = @_;

	my $notifications_count = 0;
	my $index               = $counter->{'index'};

	###as notifications are time ordered we don't need to check timestamps, just how many notifications of that type are to the right
	#if type is NANO then we count all notifications
	if ( $counter_type eq 'NANO' ) {
		$notifications_count = scalar @$notifications - $index;
	}
	else {
		while ( $index < scalar @$notifications ) {
			if ( ( $notifications->[$index]{'nagios.'.$counter_type}//'Undef' ) eq $counter_value ) {
				$notifications_count++;
			}
			$index++;
		}		
	}
	return $notifications_count;	
}

sub Flood_notify_ops_team {
	my ($Tmdx, $Config, $Data, $status) = @_;
	my ($Message, %Info);

    %Info             = ();
    $Info{'source'}   = "notify_flood:".$Data->{'nagios.notify.id'};
    $Info{'to'}       = $Config->{'notify.tmdx'};
    $Info{'ttl'}      = 3600;
    $Info{'subject'}  = "Flood ".$status." from ".$ENV{'NAGIOS__HOSTNODE'}.", check details in logs of this NaNo";
    $Info{'mode'} = 2;
    $Info{'event'} = 'SMS:'.$Config->{'notify.standby_number'};
    $Message = "Flood ".$status." from ".$ENV{'NAGIOS__HOSTNODE'}.", check details in logs of this NaNo";
    $Message .= "\n";

    $Tmdx->Transmit (\%Info, $Message);
}

sub Flood_Supress {
	my ($Notify, $notification) = @_;
	my $supress = 0;

	for my $counter_type (keys %{$Notify->{'Notify.flooding_type'}} ) {
		if ( $counter_type eq "NANO" ) {
			$supress++;
		}
		elsif ( ($notification->{'nagios.'.$counter_type}//"") eq $Notify->{'Notify.flooding_type'}{$counter_type} ) {
			$supress++;
		}
	}
	return $supress;
}

#------------------------------------------------------------------------------
1;