package Nagios::Node;
#------------------------------------------------------------------------------
$main::VERSION   = "2.2.4.30";
$main::COPYRIGHT = "Atos SE 2009-2021";
$main::USER      = "nagios";
#------------------------------------------------------------------------------
#  Perl module dependencies (checked by 'Setup.pl')
#------------------------------------------------------------------------------
$main::MODULES = 
{
	'Compress::Zlib'	=> undef,
	'Cwd'				=> undef,
	'Data::Dumper'		=> undef,
	'Digest::SHA'		=> undef,
	'Fcntl'				=> undef,
	'File::Basename'	=> undef,
	'File::Copy'		=> undef,
	'File::Path'		=> undef,
	'POSIX'				=> "1.00",
	'Storable'			=> undef,
	'Sys::Hostname'		=> undef,
	'Time::HiRes'		=> undef
};
#------------------------------------------------------------------------------
#  System tools dependencies (checked by 'Setup.pl')
#------------------------------------------------------------------------------
$main::TOOLS = 
{
	'curl|wget'     => [undef, 1010000], 	# require 'curl' or 'wget>=1.10'
	'openssl'       => undef,
	'uuidgen'       => undef
};
#------------------------------------------------------------------------------
1;
