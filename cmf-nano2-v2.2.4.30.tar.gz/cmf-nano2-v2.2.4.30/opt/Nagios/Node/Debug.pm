package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Debug.pm
#------------------------------------------------------------------------------
@Nagios::Node::Debug::ISA       = ("Nagios::Node");

use strict;
use warnings;
use POSIX;

use Tmdx::Lock;
use Tmdx::Log;

#------------------------------------------------------------------------------
sub Debug
{
  my ($Debug, $Command, @Arg) = @_;
  my ($Instance, $Var, $Lock, $Log, $Error, $Info, $Data);
  #------------------------------------------------------------------------
  # Initialize, lock & logging
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->Debug();") if (ref($Debug) ne "Nagios::Node");
  $Debug->{"Lock"} = undef;
  $Debug->{"Log"}  = undef;
  bless ($Debug, "Nagios::Node::Debug");

  $Instance = $Debug->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";

  $Lock     = Tmdx::Lock->new ("$Var/Debug.pid");
  die ($Lock->Error()."\n") if (defined $Lock->Error());
  if (! $Lock->Lock()) 
  { 
    die ($Lock->Error()."\n") if (defined $Lock->Error());
    die "A Nagios::Node('$Instance')::Debug() process is already active ...\n";
  }
  $Debug->{"Lock"} = $Lock;

  $Log     = Tmdx::Log->new ("$Var/log", "Debug.log", undef, undef, 1);
  $Debug->{"Log"} = $Log;

  $0       = $Command."->Debug()";
  $Error   = 1;
  #------------------------------------------------------------------------
  # Check what function we want to debug
  #------------------------------------------------------------------------
  if ($#Arg > 1)
  {
    #----------------------------------------------------------
    # REQUEST
    #----------------------------------------------------------
    if ($Arg[2] =~ /^r/i)
    { 
      $Error = 0;
      require Nagios::Node::Request;  
      $Info  = {}; 
      $Data  = do { local $/; <STDIN> };
      $Debug->Request ($Info, $Data);
    }
    #----------------------------------------------------------
  }
  print STDERR "Usage: NagiosNode.pl <instance> debug <function>\n" if ($Error);
  $Lock->Unlock();
  #------------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
 