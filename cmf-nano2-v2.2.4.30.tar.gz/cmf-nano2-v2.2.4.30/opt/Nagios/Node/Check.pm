package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Check.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Check
{
  my ($Check, @Arg) = @_;
  my ($Basename, $Config, $Instance, $Tmdx, $Var);
  my ($Item, $Eval, $Result);
  #------------------------------------------------------------------------
  # Initialize
  #------------------------------------------------------------------------
  if (ref($Check) ne "Nagios::Node")
  {
    print "Usage: Nagios::Node->Check();\n";
    return 3;
  }
  if ($Check->{"Error"})
  {
    print $Check->{"Error"}."\n";
    return 3;
  }
  bless ($Check, "Nagios::Node::Check");

  $Basename = $Check->{"Basename"};
  $Config   = $Check->{"Config"};
  $Instance = $Check->{"Instance"};
  $Tmdx     = $Check->{"Tmdx"};
  $Var      = "/var/Nagios/Node/$Instance";
  if ($#Arg < 1)
  {
    print "Use 'CheckNagiosNode.pl <instance> help' for usage instructions\n";
    return 3; # UNKNOWN
  } 
  $Item = ucfirst(lc($Arg[1]));
  $Item = "Node" if ($Item eq "Nano"); # accept the old check name
  #--------------------------------------------------------------------
  # Perform the requested check
  #--------------------------------------------------------------------
  if (! -r "/opt/Nagios/Node/Nagios/Node/Check/$Item.pm")
  {
    print "Sorry, the '$Item' check is not available";
    return 3; # UNKNOWN
  }
  $Eval  = "require Nagios::Node::Check::$Item;\n";
  $Eval .= "\$Result = \$Check->$Item(\@Arg);\n";
  eval ($Eval);
  if ($@)
  {
    print "Unable to check '$Item': $@";
    return 3; # UNKNOWN
  } 
  #------------------------------------------------------------------------
  return $Result;
}
#------------------------------------------------------------------------------
1;
 