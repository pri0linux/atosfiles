package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Status.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use POSIX;
#------------------------------------------------------------------------------
sub Status
{
  my ($Node) = @_;
  my ($User, %Info, $Info, $Pid, $Path, $Files, %File, $File, $Count, $Message);
  #--------------------------------------------------------------------
  die ("Usage: Nagios::Node->Status();") if (ref($Node) !~ /^Nagios::Node/);
  #--------------------------------------------------------------------
  # Get the full list of processes and their info
  #--------------------------------------------------------------------
  $User = getpwuid ($<);
  %Info = ();
  for $Info (split (/\n/, `ps -u $User -o pid,stime,command`))
  {
    $Info =~ s/^\s+//;
    ($Pid, $Info) = split (/\s+/, $Info, 2);
    $Info{$Pid} = $Info;
  }
  #--------------------------------------------------------------------
  # Get the list of processes from the PID-files
  #--------------------------------------------------------------------
  $Path   = "/var/Nagios/Node/".$Node->{"Instance"};
  $Files  = `ls $Path/*.pid 2>/dev/null`;
  $Files .= `ls $Path/tmdx/*.pid 2>/dev/null`;
  %File = ();
  for $File (split (/[\s\n]/, $Files))
  {
    next if (! -r $File);
    $Pid = `cat $File 2>/dev/null`;
    $Pid = 0 if (! $Pid);
    chomp $Pid;
    if (($Pid > 0) && (exists $Info{$Pid})) { $File{$Pid} = $File; }
  }
  #--------------------------------------------------------------------
  # List the processes
  #--------------------------------------------------------------------
  $Count = 0;
  for $Pid (keys %File) 
  { 
    next if (! -r $File{$Pid});
    $Info = $Info{$Pid};
    if (kill (0, $Pid)) 
    {
      $Message = sprintf ("Active PID%6s", $Pid);
      print "$Message: $Info\n";
      $Count++; 
    }
  }
  if (! $Count) { print "This Nagios Node has NO active processes!\n"; }
  #--------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
