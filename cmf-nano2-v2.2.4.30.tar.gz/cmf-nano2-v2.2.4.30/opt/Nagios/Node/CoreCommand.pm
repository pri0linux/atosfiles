package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/CoreCommand.pm 
#------------------------------------------------------------------------------
use strict;
use warnings;

use File::Path;
use Storable;
use Time::HiRes;
#------------------------------------------------------------------------------
# Queue external (core) commands to be fed to Nagios by the Core process
#------------------------------------------------------------------------------
sub CoreCommand
{
	my ($Node, @Data) = @_;
	my ($Config, $Instance, $Var, $Log, $Command, $Data, @Line, $Line);
	my ($Path, $File);
	#----------------------------------------------------------------------
	die ("Usage: Nagios::Node->CoreCommand();") if (ref($Node) !~ /^Nagios::Node/);
	$Config   = $Node->{"Config"};
	$Instance = $Node->{"Instance"};
	$Var      = "/var/Nagios/Node/$Instance";
	$Log      = $Node->{"Log"};
	$Command  = [];
	foreach $Data (@Data)
	{
        $Data =~ s/^\s+//;
        $Data =~ s/\s+$//;
        @Line = split (/\s*\n\s*/, $Data);
        foreach $Line (@Line) 
        { 
          next if ($Line !~ /\S/);
          $Line = "[".time()."] $Line" if ($Line !~ /^\[\d+\]/);
          $Log->Log ($Line) if ($Node->{Debug});
          push (@$Command, $Line);
        }
	}
	$Path = "$Var/Core/Command";
	eval { mkpath ($Path); } if (! -d $Path); 
	chmod (02770, $Path);
	$File = sprintf ("%0.10f.%05d", Time::HiRes::time(), $$);
    Storable::lock_nstore ($Command, "$Path/$File.pds");
	#----------------------------------------------------------------------
	return 0;
}
#------------------------------------------------------------------------------
1;
 