package Nagios::Node::Nmon; 
#------------------------------------------------------------------------------
# Nagios/Node/Nmon/Upload.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use Compress::Zlib;
use File::Copy;
use File::Path;
use Time::HiRes;
#------------------------------------------------------------------------------
sub Upload
{
	my ($This) = @_;
	my ($Path, $Handle, @Minutes, $Gzip, $Time, $Last, $Limit, $Count);
	my ($Done, @Done, @Debug, $Minute, @Files, $File, $Data, $Debug, $Size);
	my ($Spool, $Ext);
	#------------------------------------------------------------------------
	# Gzip the data to be uploaded
	#------------------------------------------------------------------------
	$Path = "/var/Nagios/Node/$This->{Instance}/Nmon";
	return 0 if (! opendir ($Handle, $Path));
	@Minutes = grep { /^\d+$/ } readdir ($Handle);
	closedir ($Handle);
	if (! open ($Handle, ">$Path/Upload.info")) {
		$This->{Log}->Log ("Can't create '$Path/Upload.info': $!"); 
		$main::Stop++; # fatal
		return 0;
	}
	print $Handle "to: nmon\nttl: 86400\nevent: nmon.data\n";
	close $Handle;
	$Gzip = gzopen ("$Path/Upload.data", "wb");
	if (! $Gzip) { 
		$This->{Log}->Log ("Can't create '$Path/Upload.data': $!"); 
		$main::Stop++; # fatal
		return 0;
	}
	$Time  = Time::HiRes::time();
	$Last  = int ($Time/60) - 1; # last minute
	$Limit = $Last - 1440; # 24 hours ago
	$Count = 0;
	$Done  = 0; 
	@Done  = ();
	@Debug = () if ($This->{Debug});
	foreach $Minute (sort @Minutes) {
		if ($Minute < $Limit) {
			$This->{Log}->Log ("Expired: $Path/$Minute"); 
			rmtree ("$Path/$Minute");
			next;
		}
		next if (! opendir ($Handle, "$Path/$Minute"));
		@Files = grep { /^\d+/ } readdir ($Handle);
		closedir ($Handle);
		if (($Minute < $Last) && ($#Files < 0)) {
			rmtree ("$Path/$Minute");
			next;
		}
		foreach $File (sort @Files) {
			next if (! open ($Handle, "$Path/$Minute/$File"));
			$Data = do { local $/; <$Handle> };
			close ($Handle);
			if ($This->{Debug}) {
				($Debug) = split (/\n/, $Data, 2);
				push (@Debug, "    $Debug");
			}
		    if (! $Gzip->gzwrite("$Data\n")) {
				$This->{Log}->Log ("Can't write '$Path/Upload.data': $!"); 
				$Gzip->gzclose();
				$main::Stop++; # fatal
				return 0;
		    }
		    $Count++;
		    $Done += length ($Data);
			push (@Done, "$Minute/$File");
			last if ($Done >= 10240000); # limit to 10 MB uncompressed data
		}
		last if ($Done >= 10240000); # limit to 10 MB uncompressed data
	}
	$Gzip->gzclose();
	return 0 if (! $Done); # no data ...
	#------------------------------------------------------------------------
	# Upload the gzipped data
	#------------------------------------------------------------------------
	$Size = -s "$Path/Upload.data";
	$This->{Log}->Log ("Uploading $Count records (gzipped $Done into $Size bytes)"); 
	$Spool = $This->{Tmdx}{Tx}{Spool}."/tx";
	$Time  = Time::HiRes::time();
	$File  = sprintf ("%s/%10.3f%05d", $Spool, $Time, $$);
	foreach $Ext ("data", "info") {
		next if (move ("$Path/Upload.$Ext", "$File.$Ext"));
		$This->{Log}->Log ("Can't move '$Path/Upload.$Ext' to '$File.$Ext': $!"); 
		$main::Stop++; # fatal
		return 0;
	}
	$This->{Log}->Log (@Debug) if ($This->{Debug});
	#------------------------------------------------------------------------
	# Remove the uploaded files
	#------------------------------------------------------------------------
	foreach $File (@Done) { 
		unlink ("$Path/$File"); 
	}
	#------------------------------------------------------------------------
	return ($Done >= 10240000);
}
#------------------------------------------------------------------------------
1;
