package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/IsActive/ipaddr.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub IsActive_ipaddr
{
  my ($Node, $Active) = @_;
  my ($Path, @Output, $Line);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->IsActive_ipaddr(...);") if (ref($Node) !~ /^Nagios::Node/);

  for $Path ("/usr/bin", "/bin", "usr/sbin", "/sbin")
  {
    if (-x "$Path/ip")
    {
      @Output = `$Path/ip addr|grep inet`;
      for $Line (@Output)
      {
        return 1 if ($Line =~ /$Active/);
      }
      return 0;
    }
  }
  #------------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
