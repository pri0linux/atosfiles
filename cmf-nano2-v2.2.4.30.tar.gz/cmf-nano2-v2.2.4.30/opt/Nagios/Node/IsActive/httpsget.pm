package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/IsActive/httpsget.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use LWP::UserAgent;
#------------------------------------------------------------------------------
sub IsActive_httpsget {
    my ($Node, $Active) = @_;
    my ($Uuid, $File, $Handle, $Key, $Context, $Agent, $Url, $Response);
    #------------------------------------------------------------------------
    if (ref($Node) !~ /^Nagios::Node/) {
        die ("Usage: Nagios::Node->IsActive_httpsget(...);");
    }
    $Uuid = `uuidgen 2>/dev/null`;
    $Uuid =~ s/\s+//g;
    if (! $Uuid) {
        $Node->{"Error"} = "ERROR generating a uuid with 'uuidgen'";
        return 0;
    }
    $File = "/var/Nagios/Node/".$Node->{Instance}."/IsActive.uuid";
    if (! open ($Handle, ">$File")) {
        $Node->{"Error"} = "$!: $File";
        return 0;
    }
    print $Handle $Uuid;
    close ($Handle);
    
    foreach $Key ("http_proxy", "https_proxy", "no_proxy") {
        delete ($ENV{lc $Key}); delete ($ENV{uc $Key});
    }
    $ENV{'PERL_LWP_SSL_VERIFY_HOSTNAME'} = 0;
	$Key = { SSL_verify_mode => 0, verify_hostname => 0	};
	eval { 
        $Context = new IO::Socket::SSL::SSL_Context (%$Key);
        IO::Socket::SSL::set_default_context ($Context);
    };

    $Agent = LWP::UserAgent->new (timeout => 10);
    eval { $Agent->ssl_opts ( verify_hostname => 0); };
    eval { $Agent->ssl_opts ( SSL_verify_mode => 0); };
    $Agent->env_proxy;
    $Url = "https://$Active/Nagios/Node/IsActive.php/$Node->{Instance}";
    $Response = $Agent->get ($Url);
    if (! $Response->is_success) {
        $Node->{"Error"} = "$Url returned ".$Response->status_line;
        return 0;
    }
    $Key = $Response->decoded_content;
    $Key =~ s/\s+//g;
    return 0 if ($Key ne $Uuid);
    #------------------------------------------------------------------------
    return 1;
}
#------------------------------------------------------------------------------
1;
