package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/IsActive/httpget.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use LWP::UserAgent;
#------------------------------------------------------------------------------
sub IsActive_httpget {
    my ($Node, $Active) = @_;
    my ($Uuid, $File, $Handle, $Key, $Agent, $Url, $Response, $Test);
    #------------------------------------------------------------------------
    if (ref($Node) !~ /^Nagios::Node/) {
        die ("Usage: Nagios::Node->IsActive_httpget(...);");
    }
    $Uuid = `uuidgen 2>/dev/null`;
    $Uuid =~ s/\s+//g;
    if (! $Uuid) {
        $Node->{"Error"} = "ERROR generating a uuid with 'uuidgen'";
        return 0;
    }
    $File = "/var/Nagios/Node/".$Node->{Instance}."/IsActive.uuid";
    if (! open ($Handle, ">$File")) {
        $Node->{"Error"} = "$!: $File";
        return 0;
    }
    print $Handle $Uuid;
    close ($Handle);
    
    foreach $Key ("http_proxy", "https_proxy", "no_proxy") {
        delete ($ENV{lc $Key}); delete ($ENV{uc $Key});
    }
    $Agent = LWP::UserAgent->new (timeout => 10);
    $Agent->env_proxy;
    $Url = "http://$Active/Nagios/Node/IsActive.php/$Node->{Instance}";
    $Response = $Agent->get ($Url);
    if (! $Response->is_success) {
        $Node->{"Error"} = "$Url returned ".$Response->status_line;
        return 0;
    }
    $Test = $Response->decoded_content;
    $Test =~ s/\s+//g;
    return 0 if ($Test ne $Uuid);
    #------------------------------------------------------------------------
    return 1;
}
#------------------------------------------------------------------------------
1;
