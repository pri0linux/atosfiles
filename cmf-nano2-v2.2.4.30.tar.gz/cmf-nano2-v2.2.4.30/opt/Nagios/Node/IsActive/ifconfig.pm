package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/IsActive/ifconfig.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub IsActive_ifconfig
{
  my ($Node, $Active) = @_;
  my ($Path, @Output, $Line);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->IsActive_ifconfig(...);") if (ref($Node) !~ /^Nagios::Node/);

  for $Path ("/usr/bin", "/bin", "usr/sbin", "/sbin")
  {
    if (-x "$Path/ifconfig")
    {
      @Output = `$Path/ifconfig`;
      for $Line (@Output)
      {
        return 1 if ($Line =~ /$Active/);
      }
    }
  }
  #------------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
