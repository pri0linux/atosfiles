package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Core.pm
#------------------------------------------------------------------------------
@Nagios::Node::Core::ISA = ("Nagios::Node");

use strict;
use warnings;

use File::Path;
use Storable;

use Nagios::Node::Core::Command;

use Tmdx::Lock;
use Tmdx::Log;
#------------------------------------------------------------------------------
sub Core
{
	my ($This, $Command) = @_;
	my ($Config, $Instance, $Var, $Lock, $Log, $Minute);
	#----------------------------------------------------------------------
	# Initialize, lock & start logging
	#----------------------------------------------------------------------
	# die ("") if ($#ARGV < 1); # Interactive only !!!
	#----------------------------------------------------------------------
	die ("Usage: Nagios::Node->Core();") if (ref($This) ne "Nagios::Node");
	$This->{"Lock"} = undef;
	$This->{"Log"}  = undef;
	bless ($This, "Nagios::Node::Core");

	$Config   = $This->{"Config"};
	$Instance = $This->{"Instance"};
	$Var      = "/var/Nagios/Node/$Instance";

	$This->{Debug} = $Config->{"debug"} || $Config->{"debug.core"};

	$Lock     = Tmdx::Lock->new ("$Var/Core.pid");
	die ($Lock->Error()."\n") if (defined $Lock->Error());
	if (! $Lock->Lock()) 
	{ 
		die ($Lock->Error()."\n") if (defined $Lock->Error());
		die "The Nagios Node Core process is already active ...\n";
	}
	$This->{"Lock"} = $Lock;

	$0 = $Command."->Core()";
	$Log = Tmdx::Log->new ("$Var/log", "Core.log", undef, undef, 1);
	$Log->Log ("------------------------------------------------------------------------------",
	           "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
	$This->{"Log"} = $Log;
	#------------------------------------------------------------------------
	# Start processing until the end of time ...
	#------------------------------------------------------------------------
	$Minute = 0;
	while (! $main::Stop)
	{
		if ($Minute != int(time()/60))
		{
			# Do something once a minute ...
			$Minute = int(time()/60);
		}
		$Lock->Touch();
		last if (time() >= $Config->{'endtime'});
		$This->Command(); # Feed the commands to Nagios(tm)




		sleep (1);
	} 
	$Log->Log ("Done ...");
	$Log->Close();
	$Lock->Unlock();
	#------------------------------------------------------------------------
	return 0;
}
#------------------------------------------------------------------------------
1;
 