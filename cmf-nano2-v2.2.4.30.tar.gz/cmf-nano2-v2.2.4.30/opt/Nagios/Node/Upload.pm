package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Upload.pm
#------------------------------------------------------------------------------
@Nagios::Node::Core::ISA = ("Nagios::Node");

use strict;
use warnings;

use Tmdx::Lock;
use Tmdx::Log;

use Nagios::Node::Upload::TransmitFile;
#------------------------------------------------------------------------------
sub Upload {
	my ($This, $Command) = @_;
	my ($Config, $Instance, $Var, $Lock, $Log, $Path, $Handle, @Files);
	my ($File);
	#----------------------------------------------------------------------
	# Initialize, lock & start logging
	#----------------------------------------------------------------------
	# die ("") if ($#ARGV < 1); # Interactive only !!!
	#----------------------------------------------------------------------
	die ("Usage: Nagios::Node->Upload();") if (ref($This) ne "Nagios::Node");
	$This->{"Lock"} = undef;
	$This->{"Log"}  = undef;
	bless ($This, "Nagios::Node::Upload");

	$Config   = $This->{"Config"};
	$Instance = $This->{"Instance"};
	$Var      = "/var/Nagios/Node/$Instance";

	$This->{Debug} = $Config->{"debug"} || $Config->{"debug.upload"};

	$Lock     = Tmdx::Lock->new ("$Var/Upload.pid");
	die ($Lock->Error()."\n") if (defined $Lock->Error());
	if (! $Lock->Lock()) { 
		die ($Lock->Error()."\n") if (defined $Lock->Error());
		die "The Nagios Node Upload process is already active ...\n";
	}
	$This->{"Lock"} = $Lock;

	$0 = $Command."->Upload()";
	$Log = Tmdx::Log->new ("$Var/log", "Upload.log", undef, undef, 1);
	$Log->Log ("------------------------------------------------------------------------------",
	           "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
	$This->{"Log"} = $Log;
	#------------------------------------------------------------------------
	# Start uploading files until the end of time ...
	#------------------------------------------------------------------------
	$Path = "$Var/Upload";
	while (! $main::Stop) {
		$Lock->Touch();
		last if (time() >= $Config->{'endtime'});
		if (opendir ($Handle, $Path)) {
            @Files = grep { /^[^\.\_]/ } readdir ($Handle);
            closedir ($Handle);
            foreach $File (@Files) {
                last if ($main::Stop);
                $Log->Log ($File);
                $This->TransmitFile ($Path, $File);
                sleep (1);
            }
		}
		sleep (1);
	} 
	$Log->Log ("Done ...");
	$Log->Close();
	$Lock->Unlock();
	#------------------------------------------------------------------------
	return 0;
}
#------------------------------------------------------------------------------
1;
 