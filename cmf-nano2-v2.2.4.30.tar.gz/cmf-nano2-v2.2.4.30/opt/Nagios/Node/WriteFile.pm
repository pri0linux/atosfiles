package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/WriteFile.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Copy;
#------------------------------------------------------------------------------
sub WriteFile
{
  my ($Node, $Data, $File) = @_;
  my ($Log);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->WriteFile(...);") if (ref($Node) !~ /^Nagios::Node/);
  $Log = $Node->{"Log"};
  if (! $File) 
  { 
    $Log->Log ("ERROR: Unable to write '': File not specified"); 
    return 0;
  }
  if (! open (FILE, ">$File"))
  {
    $Log->Log ("ERROR: Unable to write '$File': $!");
    return 0;
  }
  print FILE $Data;
  close FILE;
  #------------------------------------------------------------------------
  return 1;
}
#------------------------------------------------------------------------------
1;
