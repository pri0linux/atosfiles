package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/StartNagios.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub StartNagios
{
  my ($Node) = @_;
  my ($Config, $Instance, $Var, $Log, $Pid, $Command, $Result);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->StartNagios(...);") if (ref($Node) !~ /^Nagios::Node/);
  $Config   = $Node->{"Config"};
  $Instance = $Node->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";
  $Log      = $Node->{"Log"};
  #--------------------------------------------------------------------
  if (open (PIDFILE, "$Var/nagios.pid"))
  {
    my $Pid = <PIDFILE>;
    chomp ($Pid);
    close (PIDFILE);
    if (kill (0, $Pid)) 
    {
      $Log->Log ("  Nagios is already running");
      return undef; 
    }
  }
  #--------------------------------------------------------------------
  unlink "$Var/rw/nagios.cmd";
  $Command = "/opt/Nagios/Node/nagios -d $Var/nagios.cfg";
  no warnings;
  $Result = system ($Command);
  use warnings;
  if ($Result == 0) 
  {
    $Log->Log ("  Started nagios successfully");
  }
  elsif ($Result == -1) 
  {
    $Log->Log ("ERROR: Nagios failed to start: $!");
  }
  elsif ($Result & 127) 
  {
    $Log->Log (sprintf("ERROR: Nagios died with signal %d (%s coredump)", ($Result & 127),  ($Result & 128) ? 'with' : 'without'));
  }
  else
  {
    $Log->Log (sprintf ("ERROR: Nagios exited with value %d", $Result >> 8));
  }
  #------------------------------------------------------------------------
  return undef;
}
#------------------------------------------------------------------------------
1;
 