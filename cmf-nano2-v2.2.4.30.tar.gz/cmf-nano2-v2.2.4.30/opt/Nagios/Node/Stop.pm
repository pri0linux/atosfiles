package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Stop.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use POSIX;
#------------------------------------------------------------------------------
sub Stop
{
  my ($Node, $Log) = @_;
  my ($User, %Info, $Info, $Pid, $Path, $Files, %File, $File);
  my ($Try, $Kill, $Count, $Message);
  #--------------------------------------------------------------------
  die ("Usage: Nagios::Node->Status();") if (ref($Node) !~ /^Nagios::Node/);
  #--------------------------------------------------------------------
  # Get the full list of processes and their info
  #--------------------------------------------------------------------
  $User = getpwuid ($<);
  %Info = ();
  for $Info (split (/\n/, `ps -u $User -o pid,stime,command`))
  {
    $Info =~ s/^\s+//;
    ($Pid, $Info) = split (/\s+/, $Info, 2);
    $Info{$Pid} = $Info;
  }
  #--------------------------------------------------------------------
  # Get the list of processes from the PID-files
  #--------------------------------------------------------------------
  $Path   = "/var/Nagios/Node/".$Node->{"Instance"};
  $Files  = `ls $Path/*.pid 2>/dev/null`;
  $Files .= `ls $Path/tmdx/*.pid 2>/dev/null`;
  %File = ();
  for $File (split (/[\s\n]/, $Files))
  {
    next if (! -r $File);
    $Pid = `cat $File 2>/dev/null`;
    $Pid = 0 if (! $Pid);
    chomp $Pid;
    if (($Pid > 0) && (exists $Info{$Pid})) { $File{$Pid} = $File; }
  }
  #--------------------------------------------------------------------
  # Stop the processes
  #--------------------------------------------------------------------
  for ($Try = 0, $Kill = 2; $Try < 60; $Try++)
  {
    $Kill  = 9 if ($Try >= 30); # Force kill after 30 seconds
    $Count = 0;

    for $Pid (keys %File) 
    { 
      next if ((! -r $File{$Pid}) || (! kill (0, $Pid)));
      $Info = $Info{$Pid};
      if ($Try == 0)
      {
        $Message = sprintf ("Stopping PID%6s: %s", $Pid, $Info);
        if (defined $Log)
        {
          $Log->Log ($Message);
          print STDERR "$Message\n";
        }
        else { print "$Message\n"; }
      }
      if (kill ($Kill, $Pid)) 
      { 
        $Count++;
        if ($Kill == 9)
        {
          $Message = sprintf ("KILL(-9) PID%6s: %s", $Pid, $Info);
          if (defined $Log)
          {
            $Log->Log ($Message);
            print STDERR "$Message\n";
          }
          else { print "$Message\n"; }
        }
      }
    }

    last if ($Count == 0);
    $Kill = ($Kill == 2)?15:2;
    sleep (1);
  }
  #--------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
