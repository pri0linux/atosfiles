package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Usage.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Basename;
#------------------------------------------------------------------------------
sub Usage {
my ($Return)  = @_;
my $Basename  = basename($0);
my $Version   = $main::VERSION;
my $Copyright = $main::COPYRIGHT;
#------------------------------------------------------------------------------
# CheckNagiosNode.pl usage
#------------------------------------------------------------------------------
if ($Basename =~ /Check/i) {
print "Use 'CheckNagiosNode.pl <instance> help' for usage instructions\n";
return 3; }
#------------------------------------------------------------------------------
# Notify.pl usage
#------------------------------------------------------------------------------
if ($Basename =~ /Notify/i) {
print STDERR <<EOF;
Notify.pl v$Version - Copyright (c) $Copyright

  Usage:    Notify.pl <instance> [<options>]

  Where:    <instance>    is the configured instance to be used
            <options>     one or more of the options listed below

  Options:  log           log the notification
            mode=<1|2>    run in old or new mode
            tmdx=<tmdx>   select an alternate gateway

  Note:     Invalid options are silently ignored.
            See the documentation for more detailed information.

For INTERNAL use by Atos Common Monitoring Framework (CMF) Nodes ONLY.
EOF
return 1; }
#------------------------------------------------------------------------------
# NagiosNode.pl usage
#------------------------------------------------------------------------------
print <<EOF;
NagiosNode.pl v$Version - Copyright (c) $Copyright

  Usage:    NagiosNode.pl <instance> [<command>]

  Where:    <instance>  is a configured instance
            <command>   is an optional command

  Command:  Batch [<periods>]    run the 'Batch' process interactively
            Checks               run the 'Checks' process interactively
            Client               run the 'Client' process interactively
            Core                 run the 'Client' process interactively
            Debug                to be documented (do not use for now)
            Get <server>         run the 'Get' process interactively
            Post                 run the 'Post' process interactively
            Receive              run the 'Receive' process interactively
            Rsync                run the 'Rsync' process interactively
            Status               show all running Nagios Node processes
            Stop                 stop all running Nagios Node processes
            Transmit             run the 'Transmit' process interactively

  Note:     Run '/opt/Nagios/Node/NagiosNode.pl' without arguments
            every minute from the crontab of the user 'nagios' to 
            keep all Nagios Node background processes active.
            See the documentation for more detailed information.

For INTERNAL use by Atos Common Monitoring Framework (CMF) Nodes ONLY.
EOF
return $Return; }
#------------------------------------------------------------------------------
1;
