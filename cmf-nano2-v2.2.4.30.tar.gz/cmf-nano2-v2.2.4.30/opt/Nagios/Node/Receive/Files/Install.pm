package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Files/Install.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use Digest::SHA;
use File::Copy;
use File::Path;
use Storable;
#------------------------------------------------------------------------------
sub Files_Install
{
	my ($Receive, $Src, $Dst) = @_;
	my ($Log, @Files, $File, @Stat, $Target);
	my ($Info, $Data, $Handle, $Sha1, @Data, $Line);
	#----------------------------------------------------------------------
	# Save the new files and remove the deleted files
	#----------------------------------------------------------------------
	return if (! -d $Dst); # the destination MUST exist ...
	$Log = $Receive->{"Log"};
	if (opendir (FILES, "$Src/Files"))
	{ 
		@Files = sort (grep { /^[^\.]/ } readdir(FILES));
		closedir FILES;
		for $File (@Files) 
		{
			next if (-d "$Src/Files/$File"); # subdirectories not allowed ...
			@Stat = stat ("$Src/Files/$File");
			next if ($#Stat < 7);
			mkpath ("$Dst/Files") if (! -d "$Dst/Files");
			`rm -rf $Dst/Files/$File` if (-d "$Dst/Files/$File");
			$Target = "$Dst/Files/$File";
			$Target =~ s#^/var/Nagios/Node/##;
			if ($Stat[7])
			{ 
				$Log->Log ("    Updating '$Target'");
				copy ("$Src/Files/$File", "$Dst/Files/$File"); 
			}
			elsif (-r "$Dst/Files/$File") 
			{
				$Log->Log ("    Removing '$Target'");
				unlink ("$Dst/Files/$File"); 
			}
		}
	}
	#----------------------------------------------------------------------
	# Update Files.pds and Files.dat
	#----------------------------------------------------------------------
	$Info = {};
	$Data = "";
	if (opendir($Handle, "$Dst/Files"))
	{
		@Files = grep { !/^[\.\_]/ } readdir ($Handle);
		closedir ($Handle);
		foreach $File (@Files)
		{
			next if (-d "$Dst/Files/$File");
			@Stat = stat ("$Dst/Files/$File");
			if (open ($Handle, "$Dst/Files/$File"))
			{
				$Sha1 = Digest::SHA::sha1_hex ( do { local $/ = <$Handle> } );
				close ($Handle);
				$Info->{$File} = [$Stat[7], $Stat[9], uc($Sha1)];
				$Data .= "$File;$Stat[7];$Stat[9]\n";
			}
		}
	}
	Storable::lock_nstore ($Info, "$Dst/Files.pds.tmp");
	move ("$Dst/Files.pds.tmp","$Dst/Files.pds");
	if (open ($Handle, ">$Dst/Files.dat.tmp"))
	{
		print $Handle $Data;
		close ($Handle);
		move ("$Dst/Files.dat.tmp","$Dst/Files.dat");
	}
	#----------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
 