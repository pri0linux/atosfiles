package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Config.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Copy;
use Nagios::Node::CopyFile;
use Nagios::Node::WriteFile;
use Tmdx::Client::Transmit;
#------------------------------------------------------------------------------
sub Config
{
  my ($Receive, $Info, $Data) = @_;
  my ($Config, $Instance, $Log, $Var, $Msg);
  my ($Set, $Null, @Data, $Event, $From, $Nagios, $Objects, $Verify);
  my ($Command, $Result, $Status, $Tmdx, $Pid);
  #------------------------------------------------------------------------
  # Initialize ...
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Receive->Config(...);") if (ref($Receive) ne "Nagios::Node::Receive");
  $Config   = $Receive->{"Config"};
  $Instance = $Receive->{"Instance"};
  $Log      = $Receive->{"Log"};
  $Var      = "/var/Nagios/Node/$Instance";
  $Msg      = "'".$Info->{'event'}."' event from '".$Info->{'from'}."'";
  if (lc($Info->{'from'}) ne lc($Config->{'nahq'}))
  {
    $Log->Log ("Ignoring $Msg."); return undef;
  }
  $Log->Log ("Processing $Msg ...");
  #--------------------------------------------------------------------
  # Parse any macro's in the new configuration data
  #--------------------------------------------------------------------
  $Set = $Config->File();    $Data =~ s/\{NANO_CFG\}/$Set/g;
  $Set = "/etc/Nagios/Node"; $Data =~ s/\{NANO_ETC\}/$Set/g;
  $Set = getgrgid($));       $Data =~ s/\{NANO_GRP\}/$Set/g;
  $Set = "/opt/Nagios/Node"; $Data =~ s/\{NANO_OPT\}/$Set/g;
  $Set = getpwuid($<);       $Data =~ s/\{NANO_USR\}/$Set/g;
  $Set = $Var;               $Data =~ s/\{NANO_VAR\}/$Set/g;
  #--------------------------------------------------------------------
  # Validate the new configuration data
  #--------------------------------------------------------------------
  $Null = chr(0);
  @Data = split (/$Null/, $Data);
  chomp ($Data[0]);
  $Event = $Info->{'event'};
  $From  = $Info->{'from'};
  if (($Data[0] ne $Event) || (! $Data[2]))
  {
    $Log->Log ("  Ignoring invalid 'nano.config' data");
    return undef;
  }
  #--------------------------------------------------------------------
  # Extract the new configuration in 'nagios.new' and 'objects.new'
  #--------------------------------------------------------------------
  $Nagios  = "/var/Nagios/Node/$Instance/nagios";
  $Objects = "/var/Nagios/Node/$Instance/objects";
  $Verify  = "/var/Nagios/Node/$Instance/verify";
  return undef if (! $Receive->WriteFile ($Data[1], "$Nagios.new"));
  return undef if (! $Receive->WriteFile ($Data[2], "$Objects.new"));
  if (!(-e "$Nagios.cfg")) { copy ("$Nagios.new", "$Nagios.cfg"); }
  if (!(-e "$Objects.cfg")) { copy ("$Objects.new", "$Objects.cfg"); }
  #--------------------------------------------------------------------
  # Verify the new configuration in 'nagios.new' and 'objects.new'
  #--------------------------------------------------------------------
  $Log->Log ("  Verifying new nagios configuration files");
  return undef if (! $Receive->CopyFile ("$Nagios.cfg",  "$Nagios.old"));
  return undef if (! $Receive->CopyFile ("$Objects.cfg", "$Objects.old"));
  return undef if (! $Receive->CopyFile ("$Nagios.new",  "$Nagios.cfg"));
  return undef if (! $Receive->CopyFile ("$Objects.new", "$Objects.cfg"));
  $Command = "/opt/Nagios/Node/nagios -vp $Nagios.cfg";
  $Result = `$Command`; $Result =~ s/^\s//; $Result =~ s/\s$//; 
  $Receive->WriteFile ($Result, "$Verify.log");
  if ($Result =~ /Things look okay/ ) { $Status = 0; } else { $Status = 2; }
  if ($Status != 0) { $Log->Log ("WARNING: Verification of the '$Event' data failed!"); }
  #--------------------------------------------------------------------
  # Report the result of the verification to Nagios Headquarters
  #--------------------------------------------------------------------
  $Log->Log ("  Uploading verification results to '$From'");
  $Null = chr(0);
  $Data = "nano.verify\n".$Null.$Result.$Null;
  if (open (CACHE, "$Objects.precache"))
  {
    $Data .= join ("", <CACHE>);
    close CACHE;
  }
  else { $Log->Log ("WARNING: Unable to read '$Objects.precache': $!"); }
  $Info = { "to"=>$Config->{'nahq'}, "event"=>"nano.verify", "ttl"=>86400 };
  $Tmdx = $Receive->{"Tmdx"};
  $Tmdx->Transmit($Info, $Data);
  $Log->Log ("WARNING: Unable to post '$Verify.log': ".$Tmdx->Error()) if (defined $Tmdx->Error());
  #--------------------------------------------------------------------
  # Restore the old configuration if the verification failed
  #--------------------------------------------------------------------
  if ($Status != 0) 
  { 
    $Log->Log ("WARNING: Restoring original configuration files!");
    return undef if (! $Receive->CopyFile ("$Nagios.old",  "$Nagios.cfg"));
    return undef if (! $Receive->CopyFile ("$Objects.old", "$Objects.cfg"));
  }
  else { $Log->Log ("  Activating the new nagios configuration"); }
  #--------------------------------------------------------------------
  # Restart nagios with the last known good configuration
  #--------------------------------------------------------------------
  if (open (PIDFILE, "$Nagios.pid"))
  {
    my $Pid = <PIDFILE>;
    chomp ($Pid);
    close (PIDFILE);
    if (kill (1, $Pid)) 
    {
      $Log->Log ("  Restarted nagios successfully");
      return undef; 
    }
  }
  $Receive->StartNagios(); # Try to start nagios if it wasn't running yet
  #------------------------------------------------------------------------
  return undef;
}
#------------------------------------------------------------------------------
1;
 