package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Command.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use Fcntl qw(:DEFAULT :flock);
#------------------------------------------------------------------------------
sub Command
{
  my ($Receive, $Info, $Data) = @_;
  my ($Config, $Instance, $Log, $Var, $Msg);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Receive->Command(...);") if (ref($Receive) ne "Nagios::Node::Receive");
  $Config   = $Receive->{"Config"};
  $Instance = $Receive->{"Instance"};
  $Log      = $Receive->{"Log"};
  $Var      = "/var/Nagios/Node/$Instance";
  $Msg      = "'".$Info->{'event'}."' event from '".$Info->{'from'}."'";
  if (lc($Info->{'from'}) ne lc($Config->{'nahq'}))
  {
    $Log->Log ("Ignoring $Msg."); return undef;
  }
  $Log->Log ("Processing $Msg ...");
  $Receive->CoreCommand ($Data);
  #------------------------------------------------------------------------
  return undef;
}
#------------------------------------------------------------------------------
1;
 