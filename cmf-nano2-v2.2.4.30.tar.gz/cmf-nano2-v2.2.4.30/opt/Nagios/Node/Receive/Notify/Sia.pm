package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Notify/Sia.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use Nagios::Node::CoreCommand;
#------------------------------------------------------------------------------
sub Notify_Sia
{
  my ($Receive, $Notify) = @_;
  my ($Config, $Instance, $Var, $Log);
  my ($Object, $Host, $Service, $Source, $Subject);
  my ($Record, $Volatile, $Command);
  #--------------------------------------------------------------------
  # Initialize ...
  #--------------------------------------------------------------------
  die ("Usage: Nagios::Node::Receive->Notify_Sia();") if (ref($Receive) ne "Nagios::Node::Receive");
  $Config   = $Receive->{"Config"};
  $Instance = $Receive->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";
  $Log      = $Receive->{"Log"};
  #--------------------------------------------------------------------
  # $Notify = { Title      => $Title      ,
  #             Source     => $Source     ,
  #             Object     => $Object     ,
  #             Host       => $Host       ,
  #             Service    => $Service    ,
  #             Info       => $Info       ,
  #             Message    => $Data       ,
  #             Parameters => $Parameters ,
  #             Record     => $Record     };
  #--------------------------------------------------------------------
  $Object   = $Notify->{Object};
  $Host     = $Notify->{Host};
  $Service  = $Notify->{Service};
  $Source   = $Notify->{Source};
  $Subject  = $Notify->{Info}{'subject'};
  #--------------------------------------------------------------------

  $Record   = $Notify->{Record};
  $Volatile = 0;
  if (exists $Record->{"nagios.serviceisvolatile"})
  {
    $Volatile = $Record->{"nagios.serviceisvolatile"};
  }

  $Command = "ADD_".$Object."_COMMENT;$Host";            
  if ($Object eq "SVC") { $Command .= ";$Service"; }
  $Command .= ";1;$Source;$Subject\n";

  if (($Object eq "SVC") && ($Subject =~ /^RESOLVE/i) && (! $Volatile))
  {
    $Command .= "PROCESS_SERVICE_CHECK_RESULT;$Host;$Service;0;$Source $Subject\n";
  }

  $Receive->CoreCommand ($Command);
  #--------------------------------------------------------------------
  return undef;
}
#------------------------------------------------------------------------------
1;
  