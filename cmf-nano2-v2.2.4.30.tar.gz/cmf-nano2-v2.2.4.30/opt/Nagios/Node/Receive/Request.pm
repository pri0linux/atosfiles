package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Request.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use Nagios::Node::Request;
#------------------------------------------------------------------------------
sub Request
{
	my ($This, $Info, $Data) = @_;
	my ($Config, $Instance, $Log, $Var, $Msg, @Data, @Lines, $Line, @Line);
	#----------------------------------------------------------------------
	$Config   = $This->{"Config"};
	$Instance = $This->{"Instance"};
	$Log      = $This->{"Log"};
	$Var      = "/var/Nagios/Node/$Instance";
	$Msg      = "'".$Info->{'event'}."' event from '".$Info->{'from'}."'";
	if (lc($Info->{'from'}) ne lc($Config->{'nahq'}))
	{
		$Log->Log ("Ignoring $Msg."); 
		return undef;
	}
	$Log->Log ("Processing $Msg ...");
	#----------------------------------------------------------------------
	@Data  = split (/\s*\n\s*\n\s*/, $Data);
	$Info  = {};
	@Lines = split (/\s*\n\s*/, $Data[0]);
	foreach $Line (@Lines)
	{
		@Line = split (/\s*=\s*/, $Line, 2);
		$Info->{lc($Line[0])} = $Line[1] if ($#Line == 1);
	}
	$Data = $Data[1];
	#----------------------------------------------------------------------
	return Nagios::Node::Request ($This, $Info, $Data);
}
#------------------------------------------------------------------------------
1;
 