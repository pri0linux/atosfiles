package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Files.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Copy;
use File::Path;
use Nagios::Node::Receive::Files::Install;
use Nagios::Node::WriteFile;
#------------------------------------------------------------------------------
sub Files
{
  my ($Receive, $Info, $Data) = @_;
  my ($Config, $Instance, $Log, $Var, $Msg);
  my ($Path, $File, $Command, @Clients, $Client, $Src, $Dst);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Receive->Files(...);") if (ref($Receive) ne "Nagios::Node::Receive");
  $Config   = $Receive->{"Config"};
  $Instance = $Receive->{"Instance"};
  $Log      = $Receive->{"Log"};
  $Var      = "/var/Nagios/Node/$Instance";
  $Msg      = "'".$Info->{'event'}."' event from '".$Info->{'from'}."'";
  if (lc($Info->{'from'}) ne lc($Config->{'nahq'}))
  {
    $Log->Log ("Ignoring $Msg."); return undef;
  }
  $Log->Log ("Processing $Msg ...");
  #--------------------------------------------------------------------
  if ($Data !~ /^nano.files\n\n/)
  {
    $Log->Log ("  Ignoring invalid 'nano.files' data !!!");
    return;
  }
  $Data =~ s/^nano.files\n\n//;
  $Path = "$Var/tmp/nano.files";
  if (! -d $Path) { mkpath ($Path); }
  `rm -rf $Path/*`;
  return if (! $Receive->WriteFile ($Data, "$Path.tar"));
  $Command = "cd $Path;" . `which tar`;
  chomp $Command;
  $Command .= " xf $Path.tar";
  `$Command`;
  $Src = "$Var/tmp/nano.files";
  $Dst = "$Var";
  $Receive->Files_Install ($Src, $Dst);
  if (opendir (CLIENTS, "$Path/Clients"))
  { 
    @Clients = sort (grep { /^[^\.]/ } readdir(CLIENTS));
    closedir CLIENTS;
    for $Client (@Clients) 
    { 
		$Src = "$Var/tmp/nano.files/Clients/$Client";
		$Dst = "$Var/Client/$Client";
		next if (! -d $Dst); # the destination MUST exist ...
		$Receive->Files_Install ($Src, $Dst); 
    }
  }
  #--------------------------------------------------------------------
  return;
}
#------------------------------------------------------------------------------
1;
 