package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Notify.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use Compress::Zlib;
use Storable;

use Nagios::Node::CoreCommand;
use Nagios::Node::Receive::Notify::Angate;
use Nagios::Node::Receive::Notify::Sia;
#------------------------------------------------------------------------------
sub Notify
{
  my ($Receive, $Info, $Data) = @_;
  my ($Config, $Instance, $Log, $Var, $Title);
  my ($Mode, @Event, @Source, $Source);
  my ($Parameters, $Parameter, $Name, $Value);
  my ($File, $Pdx, $Unzip, $Record);
  my ($Object, $Host, $Service, $Notify, $Subject, $Command);
  #------------------------------------------------------------------------
  # Initialize 
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Receive->Notify(...);") if (ref($Receive) ne "Nagios::Node::Receive");
  $Config   = $Receive->{"Config"};
  $Instance = $Receive->{"Instance"};
  $Log      = $Receive->{"Log"};
  $Var      = "/var/Nagios/Node/$Instance";
  $Title    = "'".$Info->{'event'}."' event from '".$Info->{'from'}."'";
  #------------------------------------------------------------------------
  # Validate & analyze the received message 
  #------------------------------------------------------------------------
  if (lc($Info->{'from'}) ne lc($Config->{'notify.tmdx'}))
  {
    $Log->Log ("Ignoring $Title."); 
    return undef;
  }
  $Mode = 1; if (exists $Info->{'mode'}) { $Mode = $Info->{'mode'}; }
  if ($Mode < 2)
  {
    $Log->Log ("Ignoring $Title with incompatible mode ($Mode)");
    return undef;
  }
  $Info->{'subject'} = "" if (! exists $Info->{'subject'});
  @Event = split (/[\|\:\!]/, $Info->{'event'});
  if (! defined $Event[1]) { $Event[1] = ""; }
  @Source = split (/[\|\:\!]/, $Info->{'source'});
  $Source = "notify";
  if (defined $Source[0])
  { 
    $Source = $Source[0]."@".$Info->{'from'};
    $Title  = "'".$Info->{'event'}."' event from '$Source'";
  }
  $Source = "($Source)";
  #--------------------------------------------------------------------
  # Split the parameters from the message
  #--------------------------------------------------------------------
  $Parameters = {};
  do
  {
    ($Parameter, $Data) = split (/\n/, $Data, 2);
    ($Name, $Value) = split (/\s*=\s*/, $Parameter, 2);
    if (defined $Value)
    {
      $Name  =~ s/^\s*//;
      $Value =~ s/\s*$//;
      $Parameters->{$Name} = $Value;
    }
  }
  while ($Parameter !~ /^\s*$/);
  #--------------------------------------------------------------------
  # Load our own notification record
  #--------------------------------------------------------------------
  $Record = {};
  if ($Event[1] =~ /^\d+$/) 
  {
    $File = sprintf ("%s/Notify/%08d.pdx", $Var, $Event[1]);
    if (! -r $File)
    {
      $Log->Log ("Ignoring $Title with unknown ID");
      return undef;
    }
    eval 
    { 
      $Pdx    = Storable::lock_retrieve ($File); 
      $Unzip  = Compress::Zlib::memGunzip ($Pdx);
      $Record = Storable::thaw ($Unzip);
    };
    $Record = {} if (ref($Record) ne "HASH");
    $Object = "";
    if (exists $Record->{"nagios.hostname"})
    {
      $Object  = "HOST";
      $Host    = $Record->{"nagios.hostname"};
      $Service = "";
      if (exists $Record->{"nagios.servicedesc"})
      {
        $Object  = "SVC";
        $Service = $Record->{"nagios.servicedesc"};
      }
    }
    if ($Object eq "")
    {
      $Log->Log ("Ignoring $Title with invalid state");
      return undef;
    }
  }
  #--------------------------------------------------------------------
  # Backward compatibility for host notifications 
  #--------------------------------------------------------------------
  elsif ($Event[1] =~ /^Host$/i)
  {
    if (! defined $Parameters->{"nagios.hostname"})
    {
      $Log->Log ("Ignoring $Title without 'nagios.hostname' parameter");
      return undef;
    }
    $Object  = "HOST";
    $Host    = $Parameters->{"nagios.hostname"};
    $Service = "";
    $Record  = $Parameters;
  }
  #--------------------------------------------------------------------
  # Backward compatibility for host notifications 
  #--------------------------------------------------------------------
  elsif ($Event[1] =~ /^Service$/i)
  {
    if (! defined $Parameters->{"nagios.hostname"})
    {
      $Log->Log ("Ignoring $Title without 'nagios.hostname' parameter");
      return undef;
    }
    if (! defined $Parameters->{"nagios.servicedesc"})
    {
      $Log->Log ("Ignoring $Title without 'nagios.servicedesc' parameter");
      return undef;
    }
    $Object  = "SVC";
    $Host    = $Parameters->{"nagios.hostname"};
    $Service = $Parameters->{"nagios.servicedesc"};
    $Record  = $Parameters;
  }
  #--------------------------------------------------------------------
  # Ignore unknown notification types
  #--------------------------------------------------------------------
  else
  {
    $Log->Log ("Ignoring $Title with unknown type '".$Event[1]."'");
    return undef;
  }
  #--------------------------------------------------------------------
  # Process the message
  #--------------------------------------------------------------------
  $Log->Log ("Processing $Title ...");
  $Notify = 
  {
    Title      => $Title,
    Source     => $Source,
    Object     => $Object,
    Host       => $Host,
    Service    => $Service,
    Info       => $Info,
    Message    => $Data,
    Parameters => $Parameters,
    Record     => $Record
  };
  if ($#Source >= 0)
  { 
    if (defined $Source[0]) 
    { 
      if ($Source[0] =~ /^angate/i)
      {
        $Receive->Notify_Angate ($Notify);
        return undef;
      }
      if ($Source[0] =~ /^sia/i)
      {
        $Receive->Notify_Sia ($Notify);
        return undef;
      }
    }
  }
  $Subject = $Info->{'subject'};
  $Command = "ADD_".$Object."_COMMENT;$Host";            
  if ($Object eq "SVC") { $Command .= ";$Service"; }
  $Command .= ";1;$Source;$Subject\n";
  $Receive->CoreCommand ($Command);
  #--------------------------------------------------------------------
  return undef;
}
#------------------------------------------------------------------------------
1;
 