package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Config/Client.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use Compress::Zlib;
use File::Copy;
#------------------------------------------------------------------------------
sub Config_Client
{
	my ($Receive, $Uuid, $Client) = @_;
	my ($Config, $Instance, $Var, $Log, $File, $Old, $New, $NaCl, $Host);
	my ($Key, $Service, @Line, $Line, $Timeperiod, $v, $Info, $Handle, $Data);
	#----------------------------------------------------------------------
	# Initialize ...
	#----------------------------------------------------------------------
	die ("Usage: Nagios::Node::Receive->Config_Client(...);") if (ref($Receive) ne "Nagios::Node::Receive");
	$Config   = $Receive->{"Config"};
	$Instance = $Receive->{"Instance"};
	$Var      = "/var/Nagios/Node/$Instance";
	$Log      = $Receive->{"Log"};
	#----------------------------------------------------------------------
	# Check if the configuration has changed
	#----------------------------------------------------------------------
	$Storable::canonical = 1; # allows us to compare frozen hashes
	$File = "$Var/Client/$Uuid/Config.pds";
	$Old = undef;
	eval { $Old = Storable::lock_retrieve ($File); };
	if (ref($Old) eq "HASH")
	{
		$Old = Storable::freeze ($Old);
		$New = Storable::freeze ($Client);
		return if ($Old eq $New);
	}
	eval { Storable::lock_nstore ($Client, $File); };
	#----------------------------------------------------------------------
	# Generate configuration files for each NaCl version
	#----------------------------------------------------------------------
	$NaCl = { v1 => "", v2 => "", v3 => ""};
	foreach $Host (keys %{$Client->{host}}) # Only v2 has a host definition
	{
		$NaCl->{v2} .= "define host {\n";
		foreach $Key (sort keys %{$Client->{host}{$Host}}) 
		{ 
			$NaCl->{v2} .= "\t$Key\t".$Client->{host}{$Host}{$Key}."\n"; 
		}
		$NaCl->{v2} .= "\t}\n\n";
	}
	foreach $Service (keys %{$Client->{service}})
	{
		foreach $Key ("check_interval","retry_interval") # convert to integer
		{
			$Line = $Client->{service}{$Service}{$Key};
			next if (! defined $Line);
			$Client->{service}{$Service}{$Key} = int($Line);
		}

		# v3 = check|<uuid>|0|<check-interval>|<retry-interval>|<check-command>

		@Line = ("check"); 
		foreach $Key ("service_description","check_interval","retry_interval","check_command")
		{
			$Line = $Client->{service}{$Service}{$Key};
			$Line = "" if (! defined $Line);
			push (@Line, $Line);
			push (@Line, "0") if ($#Line == 1);
		}
		$NaCl->{v3} .= join("|",@Line)."\n";

		# v2 and v1 require only the nacl checks

		next if (! defined $Client->{service}{$Service}{check_command});
		next if ($Client->{service}{$Service}{check_command} !~ /nacl\!/i) ;

		# v2 uses the nagios object definition format (= too much data)

		$NaCl->{v2} .= "define service {\n";
		foreach $Key (sort keys %{$Client->{service}{$Service}}) 
		{ 
			$NaCl->{v2} .= "\t$Key\t".$Client->{service}{$Service}{$Key}."\n"; 
		}
		$NaCl->{v2} .= "\t}\n\n";

		# v1 = <uuid>;0;<MaxTries>;<Interval>;<RetryInterval>;<CheckCommand>

		@Line = (); 
		foreach $Key ("service_description","max_check_attempts","check_interval","retry_interval","check_command")
		{
			$Line = $Client->{service}{$Service}{$Key};
			$Line = "" if (! defined $Line);
			push (@Line, $Line);
			push (@Line, "0") if ($#Line == 0);
		}
		$NaCl->{v1} .= join(";",@Line)."\n";
	}
	foreach $Timeperiod (keys %{$Client->{timeperiod}}) # Only v2 has timeperiod definitions
	{
		$NaCl->{v2} .= "define timeperiod {\n";
		foreach $Key (sort keys %{$Client->{timeperiod}{$Timeperiod}}) 
		{ 
			$NaCl->{v2} .= "\t$Key\t".$Client->{timeperiod}{$Timeperiod}{$Key}."\n"; 
		}
		$NaCl->{v2} .= "\t}\n\n";
	}
	#----------------------------------------------------------------------
	# Save the new configuration files
	#----------------------------------------------------------------------
	$Log->Log ("  Generating 'Client/$Uuid/Config.*'");	
	$File = "$Var/Client/$Uuid/Config.info";
	if (open ($Handle, ">$File.tmp"))
	{
		print $Handle $NaCl->{"v2"};
		close ($Handle);
		move ("$File.tmp", $File);
	}
	else { $Log->Log ("WARNING: Unable to write '$File.tmp': $!"); }
	foreach $v (1, 2, 3)
	{
		if ($v < 3)
		{
			$File = "$Var/Client/$Uuid/Config.v$v.gz";
			$Data = Compress::Zlib::memGzip ($NaCl->{"v$v"}."[eof]\n")
		}
		else
		{
			$File = "$Var/Client/$Uuid/Checks.v$v";
			$Data = $NaCl->{"v$v"};
		}
		if (open ($Handle, ">$File.tmp"))
		{
			print $Handle $Data;
			close ($Handle);
			move ("$File.tmp", $File);
		}
		else { $Log->Log ("WARNING: Unable to write '$File.tmp': $!"); }
	}
	#----------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
  
