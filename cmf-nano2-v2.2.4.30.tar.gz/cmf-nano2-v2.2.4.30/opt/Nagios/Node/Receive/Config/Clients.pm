package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Config/Clients.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Copy;
use Storable;

use Nagios::Node::Receive::Config::Client;
use Nagios::Node::Receive::Config::Index;
#------------------------------------------------------------------------------
sub Config_Clients
{
	my ($Receive) = @_;
	my ($Config, $Instance, $Var, $Log, $Handle, $Section, %Section, $Object);
	my ($Checks, $Index, $Line, @Line, $Id, $Client, $Host, $Service);
	#----------------------------------------------------------------------
	# Initialize ...
	#----------------------------------------------------------------------
	die ("Usage: Nagios::Node::Receive->Config_Clients();") if (ref($Receive) ne "Nagios::Node::Receive");
	$Config   = $Receive->{"Config"};
	$Instance = $Receive->{"Instance"};
	$Var      = "/var/Nagios/Node/$Instance";
	$Log      = $Receive->{"Log"};
	#----------------------------------------------------------------------
	# Read the needed object configuration records from 'objects.cache'
	#----------------------------------------------------------------------
	$Log->Log ("Checking 'objects.cache' for client config updates !!!");
	if (! open ($Handle, "$Var/objects.cache"))
	{
		$Log->Log ("WARNING: Unable to read '$Var/objects.cache': $!");
		return;
	}
	$Section = undef;
	%Section = ();
	$Object  = {};
	$Checks  = {};
	$Index   = {};
	while ($Line = <$Handle>)
	{
		$Line =~ s/^\s+//; 
		$Line =~ s/\s+$//; 
		next if (($Line =~ /^#/) || ($Line =~ /^$/));
		if (! $Section)
		{
			($Section) = ($Line =~ /^define\s+(\S+)\s*\{$/);
			next;
		}
		if ($Line ne "}")
		{
			(@Line) = split (/\s+/, $Line, 2);
			$Section{$Line[0]} = $Line[1] if ($#Line == 1);
			next;
		}
		$Id = undef;
		if (($Section eq "host") && (exists $Section{'host_name'}))
		{
			$Id = $Section{'host_name'};
		}
		elsif (($Section eq "service") && (exists $Section{'service_description'}))
		{
			$Id = $Section{'service_description'};
		}
		elsif (($Section eq "timeperiod") && (exists $Section{'timeperiod_name'}))
		{
			$Id = $Section{'timeperiod_name'};
		}
		if (defined $Id)
		{
			my %Object = %Section;
			$Object->{$Section}{$Id} = \%Object;
			if (exists $Section{'check_command'})
			{
				if ($Section{'check_command'} =~ /^nano\s*\!/i)
				{
					$Checks->{$Section}{$Id} = \%Object;
				}
			}
			$Receive->Config_Index ($Section, \%Object, $Index);
		}
		$Section = undef;
		%Section = ();
	}
	close ($Handle);
	#----------------------------------------------------------------------
	# Complete & save the configuration information for the node
	#----------------------------------------------------------------------
	foreach $Host (keys %{$Checks->{host}})
	{
		next if (! exists $Checks->{host}{$Host}{check_period});
		$Id = $Checks->{host}{$Host}{check_period};
		next if (! exists $Object->{timeperiod}{$Id});
		$Checks->{timeperiod}{$Id} = $Object->{timeperiod}{$Id};
	}
	foreach $Service (keys %{$Checks->{service}})
	{
		next if (! exists $Checks->{service}{$Service}{check_period});
		$Id = $Checks->{service}{$Service}{check_period};
		next if (! exists $Object->{timeperiod}{$Id});
		$Checks->{timeperiod}{$Id} = $Object->{timeperiod}{$Id};
	}
	eval { Storable::lock_nstore ($Checks, "$Var/Checks.pds"); };
	eval { Storable::lock_nstore ($Index, "$Var/Index.pds"); };
	#----------------------------------------------------------------------
	# Group and save the configuration information for the clients
	#----------------------------------------------------------------------
	$Client = {};
	foreach $Host (keys %{$Object->{host}})
	{
		next if (! -d "$Var/Client/$Host");
		$Client->{$Host} = 
		{ 
			host       => { $Host => $Object->{host}{$Host} },
			service    => {},
			timeperiod => {}
		};
		next if (! exists $Object->{host}{$Host}{check_period});
		$Id = $Object->{host}{$Host}{check_period};
		next if (! exists $Object->{timeperiod}{$Id});
		$Client->{$Host}{timeperiod}{$Id} = $Object->{timeperiod}{$Id};
	}
	foreach $Service (keys %{$Object->{service}})
	{
		next if (! exists $Object->{service}{$Service}{host_name});
		$Host = $Object->{service}{$Service}{host_name};
		next if (! exists $Client->{$Host});
		$Client->{$Host}{service}{$Service} = $Object->{service}{$Service};
		next if (! exists $Object->{service}{$Service}{check_period});
		$Id = $Object->{service}{$Service}{check_period};
		next if (! exists $Object->{timeperiod}{$Id});
		$Client->{$Host}{timeperiod}{$Id} = $Object->{timeperiod}{$Id};
	}
	for $Id (keys %$Client) 
	{ 
		$Receive->Config_Client ($Id, $Client->{$Id}); 
	}
	#----------------------------------------------------------------------
	return undef;
}
#------------------------------------------------------------------------------
1;
  