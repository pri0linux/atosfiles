package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Config/Index.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Copy;
use Storable;

#------------------------------------------------------------------------------
sub Config_Index
{
	my ($Receive, $Section, $Object, $Index) = @_;
	my ($Config, $Instance, $Var, $Log, $Id, $Tag, $Name, $Value);
	#----------------------------------------------------------------------
	die ("Usage: Nagios::Node::Receive->Config_Index();") if (ref($Receive) ne "Nagios::Node::Receive");
	return if (! defined $Section);
	return if ($Section !~ /^host|service$/); # only include hosts & services for now
	$Config   = $Receive->{"Config"};
	$Instance = $Receive->{"Instance"};
	$Var      = "/var/Nagios/Node/$Instance";
	$Log      = $Receive->{"Log"};
	#----------------------------------------------------------------------
	# Check if this is a host or service that needs to be included
	#----------------------------------------------------------------------
	$Id = undef;
	$Id = $Object->{host_name} if ($Section eq "host");
	$Id = $Object->{service_description} if ($Section eq "service");
	return if (! defined $Id);
	$Tag = {}; # hosts are always included as services might need them ...
	$Index->{$Id} = { type => "host" } if ($Section eq "host");
	foreach $Name (keys %$Object) # check if we need to include this object
	{
		next if ($Name !~ /^_TAG_/);
		$Value = $Object->{$Name};
		$Name =~ s/^_TAG_//;
		$Tag->{lc $Name} = $Value;
		next if ($Name !~ /\.BOT$/);
		$Name =~ s/\.BOT$//;
		$Index->{$Id}{bot}{lc $Name} = $Value;
	}
	return if (! exists $Index->{$Id}); # return if not included ...
	#----------------------------------------------------------------------
	# For all hosts and all included services add some extra information
	#----------------------------------------------------------------------
	$Index->{$Id}{type} = $Section;
	$Index->{$Id}{name} = $Object->{display_name};
	if ($Section eq "service")
	{
		$Index->{$Id}{team} = $Object->{_TEAM};
		$Index->{$Id}{host}{id}   = $Object->{host_name};
		$Index->{$Id}{host}{name} = $Object->{_HOST_DISPLAY_NAME};
		if (exists $Index->{$Object->{host_name}})
		{
			$Index->{$Id}{host}{tag} = $Index->{$Object->{host_name}}{tag};
		}
	}
	$Index->{$Id}{tag}   = $Tag;
	$Index->{$Id}{check} = $Object->{check_command};
	#----------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
  