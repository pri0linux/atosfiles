package Nagios::Node::Receive;
#------------------------------------------------------------------------------
# Nagios/Node/Receive/Ack.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Ack
{
  my ($Receive, $Info, $Data) = @_;
  my ($Config, $Instance, $Var, $Log, $Msg);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Receive->Ack(...);") if (ref($Receive) ne "Nagios::Node::Receive");
  $Config   = $Receive->{"Config"};
  $Instance = $Receive->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";
  $Log      = $Receive->{"Log"};
  $Msg      = "'".$Info->{'event'}."' event from '".$Info->{'from'}."'";
  if (lc($Info->{'from'}) ne lc($Config->{'nahq'}))
  {
    $Log->Log ("Ignoring $Msg."); return undef;
  }
  $Log->Log ("Processing $Msg ...");
  #------------------------------------------------------------------------
  if (open (ACK, ">$Var/Receive.ack")) { close (ACK); }
  utime (time(),time(),"$Var/Receive.ack"); 
  #------------------------------------------------------------------------
  return undef;
}
#------------------------------------------------------------------------------
1;
 