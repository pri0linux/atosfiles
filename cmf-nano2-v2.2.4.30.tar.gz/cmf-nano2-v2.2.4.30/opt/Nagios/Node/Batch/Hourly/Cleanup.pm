package Nagios::Node::Batch;
#------------------------------------------------------------------------------
# Nagios/Node/Batch/Hourly/Cleanup.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use File::Path;
#------------------------------------------------------------------------------
sub Hourly_Cleanup
{
  my ($Batch, $ID) = @_;
  my ($Config, $Instance, $Log, $Var);
  my ($Path, $Limit, $Count, @Files, $File, $Time, @Stat);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Batch->Hourly_Cleanup();") if (ref($Batch) ne "Nagios::Node::Batch");
  $Config   = $Batch->{"Config"};
  $Instance = $Batch->{"Instance"};
  $Log      = $Batch->{"Log"};
  $Var      = "/var/Nagios/Node/$Instance";
  #--------------------------------------------------------------------
  # Cleanup Notify.log files
  #--------------------------------------------------------------------
  $Path  = "$Var/Notify.log";
  $Limit = time() - 3 * 24 * 3600; # 3 days
  $Count = 0;
  if (opendir (NOTIFY, $Path))
  { 
    @Files = grep { /\.log$/ } readdir(NOTIFY);
    closedir NOTIFY;
    foreach $File (@Files)
    {
      ($Time) = split (/\-/, $File);
      next if ($Time > $Limit);
      unlink ("$Path/$File");
      $Count++;
    }
  }
  $Log->Log ("    Removed $Count files from '$Path'");
  #--------------------------------------------------------------------
  # Cleanup Notify files 
  #--------------------------------------------------------------------
  $Path  = "$Var/Notify";
  $Limit = time() - 33 * 24 * 3600; # 33 days
  $Count = 0;
  if (opendir (NOTIFY, $Path))
  { 
    @Files = grep { /\.pdx$/ } readdir(NOTIFY);
    closedir NOTIFY;
    foreach $File (@Files)
    {
      @Stat = stat ("$Path/$File");
      $Time = 0;
      $Time = $Stat[9] if ($#Stat >= 9);
      next if ($Time > $Limit);
      unlink ("$Path/$File");
      $Count++;
    }
  }
  $Log->Log ("    Removed $Count files from '$Path'");
  #--------------------------------------------------------------------
  # Cleanup Upload files
  #--------------------------------------------------------------------
  $Path  = "$Var/Upload";
  $Limit = time() - 24 * 3600; # 24 hours
  $Count = 0;
  if (opendir (UPLOAD, $Path))
  { 
    @Files = grep { /^[^\.\_]/ } readdir(UPLOAD);
    closedir UPLOAD;
    foreach $File (@Files)
    {
      if (-d "$Path/$File") 
      {
        rmtree ("$Path/$File");
        next;
      }
      @Stat = stat ("$Path/$File");
      $Time = ($#Stat >= 9) ? $Stat[9] : 0;
      next if ($Time > $Limit);
      unlink ("$Path/$File");
      $Count++;
    }
  }
  $Log->Log ("    Removed $Count files from '$Path'");
  #--------------------------------------------------------------------
  return;
}
#------------------------------------------------------------------------------
1;
