package Nagios::Node::Batch;
#------------------------------------------------------------------------------
# Nagios/Node/Batch/Hourly/Packages.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use Digest::SHA;
use File::Basename;
use File::Path;

use Tmdx::Client::Curl;
use Tmdx::Client::Wget;
#------------------------------------------------------------------------------
sub Hourly_Packages
{
	my ($This, $ID) = @_;
	my ($Config, $Instance, $Log, $Var, $Tmdx, $Tool, @Servers);
	my ($Packages, $Count, $Server, $Response, @Lines, $Line, $Package, $Size);
	my ($Time, $Sha1, $File, $Index, @Stat, $Local, $Remote, $Path, $Handle);
	#--------------------------------------------------------------------
	# return $This->{Log}->Log ("    Disabled in batch mode") if ($#ARGV < 3);
	#--------------------------------------------------------------------
	$Config   = $This->{Config};
	$Instance = $This->{Instance};
	$Log      = $This->{Log};
	$Var      = "/var/Nagios/Node/$Instance";
	$Tmdx     = $This->{Tmdx};
	$Tool     = ucfirst lc $Tmdx->{Rx}{Tool};
    @Servers  = split (/[\s\,\;]+/, $Tmdx->{Rx}{Servers});
	#--------------------------------------------------------------------
	# Merge the package lists from the TMDX Servers 
	#--------------------------------------------------------------------
	$Tmdx->{Rx}{File} = $Tmdx->{Rx}{Spool}."/get-Batch";
	$Tmdx->{Log} = $Log;
	$Packages = {};
	$Count = 0;
    foreach $Server (@Servers)
    {
		sleep (1);
		$Tmdx->{Rx}{Server} = $Server;
	    $Log->Log ("    ".uc($Tool)." GET https://$Server/Tmdx/Server/Packages.php/Update ...");
		$Response = $Tmdx->$Tool("GET", "https://$Server/Tmdx/Server/Packages.php/Update");
		if ($Response->{status} !~/^200/)
		{
			$Log->Log ("      ".$Response->{status});
			next;
		}
		next if ( ! defined $Response->{data});
		$Response->{data} =~ s/^\s+//;
		$Response->{data} =~ s/\s+$//;
		@Lines = split (/\s*\n\s*/, $Response->{data});
		foreach $Line (@Lines)
		{
			($Package,$Size,$Time,$Sha1) = split (/\|/, $Line);
			next if (! defined $Time);
			if (exists ($Packages->{$Package}))
			{
				next if ($Packages->{$Package}[2] > $Time);
			}
			$Packages->{$Package} = [$Server, $Size, $Time, $Sha1];
		}
		$Count++;
	}
	return if (! $Count); # No package lists, so we do nothing ...
	#--------------------------------------------------------------------
	# Load the current package index
	#--------------------------------------------------------------------
	$File = "$Var/Packages.pds";
	$Index = undef;
	eval { $Index = Storable::lock_retrieve ($File); };
	$Index = {} if (ref($Index) ne "HASH");
	foreach $Package (keys %$Index)
	{
		@Stat = stat ("$Var/Packages/$Package");
		if ($#Stat >= 9)
		{
			$Local = $Index->{$Package};
			if ($Local->[0] == $Stat[7])
			{
				next if ($Local->[1] == $Stat[9]);
			}
		}
		delete ($Index->{$Package});
	}
	#--------------------------------------------------------------------
	# Download new/updated packages
	#--------------------------------------------------------------------
	foreach $Package (keys %$Packages)
	{
		$Remote = $Packages->{$Package};
		$Server = $Remote->[0];
		if (exists $Index->{$Package})
		{
			$Local = $Index->{$Package};
			if ($Local->[0] == $Remote->[1])
			{
				if ($Local->[1] == $Remote->[2])
				{
					next if (! defined $Remote->[3]);
					next if ($Local->[2] eq $Remote->[3])
				}
			}
		}
		sleep (1);
		$Tmdx->{Rx}{Server} = $Server;
	    $Log->Log ("    ".uc($Tool)." GET https://$Server/Tmdx/Server/Packages.php/Update/$Package ...");
		$Response = $Tmdx->$Tool("GET", "https://$Server/Tmdx/Server/Packages.php/Update/$Package");
		if ($Response->{status} !~/^200/)
		{
			$Log->Log ("      ".$Response->{status});
			next;
		}
		$Size = length ($Response->{data});
		$Sha1 = uc (Digest::SHA::sha1_hex ($Response->{data}));
		$Time = $Remote->[2];
		$Time = 0 if ($Size != $Remote->[1]); # Mark as invalid
		{
			if (defined $Remote->[3])
			{
				$Time = 0 if ($Sha1 ne $Remote->[3]); # Mark as invalid
			}
		}
		if (! $Time)
		{
			$Log->Log ("      Discarding downloaded package (invalid data)");
			next;
		}
		$File = "$Var/Packages/$Package";
		$Path = dirname ($File);
		mkpath ($Path) if (! -d $Path);
		$Log->Log ("      UPDATE 'Packages/$Package'");
		if (! open ($Handle, ">$File"))
		{
			$Log->Log ("      $!");
			next;
		}
		print $Handle $Response->{data};
		close ($Handle);
		utime ($Time, $Time, $File);
		$Index->{$Package} = [ $Size, $Time, $Sha1 ];
	}
	#--------------------------------------------------------------------
	# Remove deleted/orphaned packages
	#--------------------------------------------------------------------
	$Log->Log ("    CLEANING '$Var/Packages' ...");
	foreach $Package (keys %$Index)
	{
		next if (exists $Packages->{$Package});
		$Log->Log ("      DELETE 'Packages/$Package'");
		unlink ("$Var/Packages/$Package");
		delete ($Index->{$Package});
	}
	$This->Hourly_Packages_Cleanup ($Packages, "$Var/Packages", "");
	Storable::lock_nstore ($Index, "$Var/Packages.pds");
	#--------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
sub Hourly_Packages_Cleanup
{
	my ($This, $Packages, $Root, $Path) = @_;
	my ($Handle, @Files, $Count, $Log, $File, $Package, $C);
	#--------------------------------------------------------------------
	return 0 if (! opendir ($Handle, "$Root/$Path"));
	@Files = grep { /^[^\.]/ } readdir ($Handle);
	closedir ($Handle);
	$Count = 0;
	$Log   = $This->{Log};
	foreach $File (@Files)
	{
		$Package = "$Path/$File"; 
		$Package =~ s/^\/+//;
		if (-l "$Root/$Package")
		{
			$Log->Log ("      DELETE 'Packages/$Package'");
			unlink ("$Root/$Package");		
		}
		elsif (-d "$Root/$Package")
		{
			$C = $This->Hourly_Packages_Cleanup ($Packages, $Root, $Package);
			if (! $C)
			{
				$Log->Log ("      DELETE 'Packages/$Package'");
				rmtree ("$Root/$Package");
			}
			$Count += $C;
		}
		elsif (! exists $Packages->{$Package})
		{
			$Log->Log ("      DELETE 'Packages/$Package'");
			unlink ("$Root/$Package");		
		}
		else { $Count++; }
	}
	#--------------------------------------------------------------------
	return $Count;
}
#------------------------------------------------------------------------------
1;
