package Nagios::Node::Batch;
#------------------------------------------------------------------------------
# Nagios/Node/Batch/Daily/Cleanup.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Daily_Cleanup
{
  my ($Batch, $ID) = @_;
  my ($Config, $Instance, $Log, $Var, $Gzip, $Limit1, $Limit2);
  my (@OldLogs, $OldLog, @OldZips, $OldZip, $File, @Stat);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Batch->Daily_Cleanup();") if (ref($Batch) ne "Nagios::Node::Batch");
  $Config   = $Batch->{"Config"};
  $Instance = $Batch->{"Instance"};
  $Log      = $Batch->{"Log"};
  $Var      = "/var/Nagios/Node/$Instance";
  #--------------------------------------------------------------------
  $Gzip   = `which gzip 2>/dev/null`; chomp $Gzip;
  $Limit1 = time() -  3*24*60*60;
  $Limit2 = time() - 33*24*60*60;
  if (opendir (LOGS, "$Var/log"))
  { 
    @OldLogs = sort (grep { /^nagios-.+\.log$/ } readdir(LOGS));
    rewinddir LOGS;
    @OldZips = sort (grep { /^nagios-.+\.gz$/  } readdir(LOGS));
    closedir LOGS;
    for $OldLog (@OldLogs)
    {
      $File = "$Var/log/$OldLog";
      @Stat = stat ($File);
      if ($#Stat >= 9)
      {
        next if ($Stat[9] >= $Limit1);
        if ($Stat[9] >= $Limit2)
        {
          if ($Gzip)
          {
            $Log->Log ("    Gzipping logfile '$OldLog'"); 
            `$Gzip $File`;
          }
        }
        else 
        { 
          $Log->Log ("    Removing logfile '$OldLog'"); 
          unlink ($File);
        }
      }
    }
    for $OldZip (@OldZips) 
    {
      $File = "$Var/log/$OldZip";
      @Stat = stat ($File);
      if ($#Stat >= 9)
      {
        next if ($Stat[9] >= $Limit2);
        $Log->Log ("    Removing zipfile '$OldZip'"); 
        unlink ($File);
      }
    }
  }
  #--------------------------------------------------------------------
  return;
}
#------------------------------------------------------------------------------
1;
