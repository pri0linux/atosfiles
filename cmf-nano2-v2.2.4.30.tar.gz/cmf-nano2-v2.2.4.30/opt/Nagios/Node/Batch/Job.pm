package Nagios::Node::Batch;
#------------------------------------------------------------------------------
# Nagios/Node/Batch/Job.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Job
{
	my ($Batch, $Job, $ID) = @_;
	my ($Log, $Path, @Tasks, $Task, $Eval);
	#----------------------------------------------------------------------
	die ("Usage: Nagios::Node::Batch->Job();") if (ref($Batch) ne "Nagios::Node::Batch");
	$Log = $Batch->{"Log"};
	$Log->Log ("Executing ".lc($Job)." batch '".$ID."'");
	$Path  = "/opt/Nagios/Node/Nagios/Node/Batch/$Job";
	opendir (TASKS, $Path) || return;
	@Tasks = grep { /\.pm$/ } readdir (TASKS);
	closedir (TASKS);
	foreach $Task (sort @Tasks)
	{
		$Task =~ s/\.pm$//;
		if ($#ARGV > 2) { next if (lc($ARGV[3]) ne lc($Task)); }
		$Log->Log ("  Performing ".(lc($Job))." '$Task' task");
		$Eval  = "require \"$Path/$Task.pm\";\n";
		$Eval .= "\$Batch->".$Job."_".$Task."(\$ID);\n";
		eval ($Eval);
		next if (! $@);
		chomp $@;
		$Log->Log ($@);
	}
	#----------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
