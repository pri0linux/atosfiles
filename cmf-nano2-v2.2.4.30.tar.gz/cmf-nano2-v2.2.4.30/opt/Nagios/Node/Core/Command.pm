package Nagios::Node::Core;
#------------------------------------------------------------------------------
# Nagios/Node/Core/Command.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use Fcntl qw(:DEFAULT :flock);

#------------------------------------------------------------------------------
sub Command
{
	my ($This) = @_;
	my ($Limit, $Var, $Path, $Pipe, $Handle, @Files, $File, @File);
	my ($Select, $Data, $Line, $Cmd);
	#----------------------------------------------------------------------
	$Limit = time() - 600; # discard commands after 10 minutes
	$Var   = "/var/Nagios/Node/$This->{Instance}";
	$Path  = "$Var/Core/Command";
	$Pipe  = "$Var/rw/nagios.cmd";
	eval { mkpath ($Path); } if (! -d $Path); 
	chmod (02770, $Path);
	if (! opendir ($Handle, $Path))
	{
		$This->{Log}->Log ("ERROR reading '$Path': $!");
		$main::Stop++;
		return;
	}
	@Files = sort grep { /^\d{10}\./ } readdir ($Handle);
	closedir ($Handle);
	foreach $File (@Files)
	{
		@File = split (/\./, $File);
		if ($File[0] >= $Limit) 
		{ 
			if (! -p $Pipe)
			{
				$This->{Log}->Log ("Nagios Command Pipe '$Pipe' does not exist");
				return;
			}
			$Handle = undef;
			if (! sysopen($Handle, $Pipe, O_WRONLY | O_NONBLOCK))
			{
				$This->{Log}->Log ("Unable to write '$Pipe': $!");
				return;
			}
			if (! flock ($Handle, LOCK_EX))
			{
				$This->{Log}->Log ("Unable to lock '$Pipe': $!");
				close $Handle;
				return;
			}
			$Select = select ($Handle); 
			$| = 1; 
			select ($Select);
			$Data = undef;
			if ($File =~ /\.pds$/)
			{
				eval { $Data = Storable::lock_retrieve ("$Path/$File"); };
			}
			elsif ($File =~ /\.cmd$/)
			{
				if (open ($Cmd, "$Path/$File"))
				{
					@$Line = <$Cmd>;
					close ($Cmd);
					$Data = [];
					foreach $Cmd (@$Line)
					{
						$Cmd =~ s/^\s+//; 
						$Cmd =~ s/\s+$//; 
						push (@$Data, $Cmd);
					}
				}
			}
			if (ref($Data) eq "ARRAY")
			{
				foreach $Line (@$Data)
				{
					$This->{Log}->Log ("$Line") if ($This->{Debug});
					print $Handle "$Line\n";
				}
			}
			flock ($Handle, LOCK_UN);
			close $Handle;
			$Handle = undef;
		}
		unlink ("$Path/$File"); 
	}
	#----------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
 