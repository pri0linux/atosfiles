package Nagios::Node::Upload;
#------------------------------------------------------------------------------
# Nagios/Node/Upload/TransmitFile.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use Compress::Zlib;
use Time::HiRes;
use File::Copy;
#------------------------------------------------------------------------------
sub TransmitFile
{
	my ($This, $Path, $File) = @_;
	my ($Handle, $Gzip, $Data, $Spool, $Time, $Entry, $Ext);
	#------------------------------------------------------------------------
	# Create the info and data files for the TMDX Client
	#------------------------------------------------------------------------
	if (! open ($Handle, ">$Path/.info")) {
		$This->{Log}->Log ("Can't create '$Path/.info': $!"); 
		$main::Stop++; # fatal
		return;
	}
	print $Handle "to: upload\nttl: 86400\nevent: $File\n";
	close $Handle;

	if (! open ($Handle, "$Path/$File")) {
		$This->{Log}->Log ("  Can't read '$Path/$File': $!"); 
		$main::Stop++; # fatal
		return;
	}
    $Data = do { local $/; <$Handle> };
    close ($Handle);

	$Gzip = gzopen ("$Path/.data", "wb");
	if (! $Gzip) { 
		$This->{Log}->Log ("  Can't create '$Path/.data': $!"); 
		$main::Stop++; # fatal
		return;
	}
    $Gzip->gzwrite($Data);
    $Gzip->gzclose();
	#------------------------------------------------------------------------
	# Upload the gzipped data
	#------------------------------------------------------------------------
	$Spool = $This->{Tmdx}{Tx}{Spool}."/tx";
	$Time  = Time::HiRes::time();
	$Entry = sprintf ("%s/%10.3f%05d", $Spool, $Time, $$);
	$This->{Log}->Log ("  => $Entry.*");
	move ("$Path/.data", "$Entry.data");
	move ("$Path/.info", "$Entry.info");
	unlink ("$Path/$File"); 
	#------------------------------------------------------------------------
	return 0;
}
#------------------------------------------------------------------------------
1;
 