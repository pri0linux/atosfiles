package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/LoadConfig.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use Sys::Hostname;

use Tmdx::Config;

#------------------------------------------------------------------------------
sub LoadConfig
{
  my ($Node, $Instance) = @_;
  my ($Config, $IP, $Method, $Module);
  #--------------------------------------------------------------------
  die ("Usage: Nagios::Node->LoadConfig(\$Instance);") if (ref($Node) ne "Nagios::Node");
  $Config = Tmdx::Config->new ("/etc/Nagios/Node/$Instance.cfg");
  return $Config if ($Config->{"Error"});
  #--------------------------------------------------------------------
  # client
  #--------------------------------------------------------------------
  $Config->{'client.warning'}    =      620 if (! exists $Config->{'client.warning'});    #  10 minutes
  $Config->{'client.critical'}   =      620 if (! exists $Config->{'client.critical'});   #  10 minutes
  $Config->{'client.unknown'}    =  2678400 if (! exists $Config->{'client.unknown'});    #  31 days
  $Config->{'client.unregister'} = 31622400 if (! exists $Config->{'client.unregister'}); # 366 days
  #--------------------------------------------------------------------
  # curl (see also wget)
  #--------------------------------------------------------------------
  if (! exists $Config->{'curl'})
  { 
  	$Config->{'curl'} = `which curl 2>/dev/null`;
  	if ($Config->{'curl'})
  	{
		chomp $Config->{'curl'};
		$Config->{'curl'} = "" if (! -x $Config->{'curl'});
	}
	else { $Config->{'curl'} = ""; }
  }  
  #--------------------------------------------------------------------
  # failover
  #--------------------------------------------------------------------
  if (exists $Config->{'failover'}) { 
    $IP = $Config->{'failover'};
    if ($IP !~ /^((25[0-5]|(2[0-4]|1\d|[1-9]|)\d)(\.(?!$)|$)){4}$/) {
      $Config->{"Error"} = "Aborted: invalid 'failover' IP address configured";
    }
  }
  else { $Config->{'failover'} = ""; }
  #--------------------------------------------------------------------
  # hostname
  #--------------------------------------------------------------------
  $Config->{'hostname'} = hostname;
  #--------------------------------------------------------------------
  # instance
  #--------------------------------------------------------------------
  $Config->{'instance'} = $Instance;
  #--------------------------------------------------------------------
  # isactive
  #--------------------------------------------------------------------
  if (exists $Config->{'isactive'}) { 
    ($Method, $IP) = split (/\:/, $Config->{'isactive'}, 2);
    $IP = "" if (! defined $IP);
    $Module = "/opt/Nagios/Node/Nagios/Node/IsActive/".lc($Method).".pm";
    if (! -r $Module) {
      $Config->{"Error"} = "Aborted: invalid 'isactive' handler '$Method' configured";
    }
    elsif ($IP !~ /^((25[0-5]|(2[0-4]|1\d|[1-9]|)\d)(\.(?!$)|$)){4}$/) {
      $Config->{"Error"} = "Aborted: invalid 'isactive' IP address '$IP' configured";
    }
    elsif ($Method !~ /^(httpget|httpsget)$/i) {
      print STDERR "===============================================================================\n";
      print STDERR " WARNING: deprecated 'isactive' handler '$Method' configured !!! \n";
      print STDERR "===============================================================================\n";
    }
  }
  else { $Config->{'isactive'} = ""; }
  #--------------------------------------------------------------------
  # load_average
  #--------------------------------------------------------------------
  $Config->{'load_avarage'} = "";
  #--------------------------------------------------------------------
  # nagios
  #--------------------------------------------------------------------
  $Config->{'nagios'}       = "";
  #--------------------------------------------------------------------
  # nahq
  #--------------------------------------------------------------------
  if (! exists $Config->{'nahq'}) { $Config->{'nahq'} = "nahq"; }
  #--------------------------------------------------------------------
  # notify
  #--------------------------------------------------------------------
  $Config->{'notify.log'}  = 0 if (! exists $Config->{'notify.log'});
  $Config->{"notify.log"}  = int ($Config->{"notify.log"});
  $Config->{'notify.mode'} = 1 if (! exists $Config->{'notify.mode'});
  $Config->{"notify.mode"} = int ($Config->{"notify.mode"});
  $Config->{'notify.tmdx'} = "tmdx" if (! exists $Config->{'notify.tmdx'});
  $Config->{'notify.tmdx'} = "tmdx" if ($Config->{'notify.tmdx'} eq "");
  $Config->{'notify.tmdx'} = lc  ($Config->{'notify.tmdx'});
  #--------------------------------------------------------------------
  # runtime & endtime
  #--------------------------------------------------------------------
  $Config->{'runtime'} = 333 if (! exists $Config->{'runtime'}); #   5:33:00
  $Config->{'runtime'} =   0 if ($Config->{'runtime'} < 0);      #   1 time
  $Config->{'runtime'} = 999 if ($Config->{'runtime'} > 999);    #  16:33:00
  $Config->{'endtime'} = time() + $Config->{'runtime'} * 60 + 45;
  #--------------------------------------------------------------------
  # secodb
  #--------------------------------------------------------------------
  $Config->{'secodb'} = "secodb" if (! exists $Config->{'secodb'});
  #--------------------------------------------------------------------
  # transmit
  #--------------------------------------------------------------------
  $Config->{'transmit.mode'} = 0 if (! exists $Config->{'transmit.mode'});
  $Config->{"transmit.mode"} = int ($Config->{"transmit.mode"});
  #--------------------------------------------------------------------
  # transport
  #--------------------------------------------------------------------
  $Config->{'transport'} = "tmdx" if (! exists $Config->{'transport'});
  #--------------------------------------------------------------------
  # trigger
  #--------------------------------------------------------------------
  if (! exists $Config->{'trigger.target'})
  { 
    $Config->{'trigger.target'} = undef;
    $Config->{'trigger.target'} = $Config->{'trigger'} if (exists $Config->{'trigger'});
    $Config->{'trigger.target'} = "" if (! defined $Config->{'trigger.target'});
  }
  $Config->{'trigger.interval'} = 3600 if (! exists $Config->{'trigger.interval'}); # 1 hour default
  $Config->{'trigger.interval'} =  300 if ($Config->{'trigger.interval'} < 300);    # 5 minutes minimum
  #--------------------------------------------------------------------
  # wget (see also curl)
  #--------------------------------------------------------------------
  if (! exists $Config->{'wget'})
  { 
  	$Config->{'wget'} = `which wget 2>/dev/null`;
  	if ($Config->{'wget'})
  	{
		chomp $Config->{'wget'};
		$Config->{'wget'} = "" if (! -x $Config->{'wget'});
	}
	else { $Config->{'wget'} = ""; }
  }  
  if (! ($Config->{'curl'} || $Config->{'wget'}))
  {
	$Config->{"Error"} = "Aborted: unable to locate 'curl' or 'wget'";
  }
  #--------------------------------------------------------------------
  return $Config;
}
#------------------------------------------------------------------------------
1;
