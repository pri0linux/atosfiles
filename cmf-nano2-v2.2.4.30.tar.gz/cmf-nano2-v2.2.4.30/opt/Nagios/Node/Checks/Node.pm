package Nagios::Node::Checks;
#------------------------------------------------------------------------------
# Nagios/Node/Checks/Node.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use POSIX;
#------------------------------------------------------------------------------
sub Node
{
  my ($Checks, $Check, @Command) = @_;
  my ($Config, $Instance, $Var, $Uuid, @Stat, $Age, $State, $Output);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Checks->Node(...);") if (ref($Checks) ne "Nagios::Node::Checks");

  $Config   = $Checks->{"Config"};
  $Instance = $Checks->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";

  if (exists $Check->{"State"}{"IsActive"})
  {
    if (! $Check->{"State"}{"IsActive"})
    {
      return (3, "This Nagios Node is not active !!!");
    }
  }
  #------------------------------------------------------------------------
  return (3, "Sorry, check not yet implemented ...");
}
#------------------------------------------------------------------------------
1;
