package Nagios::Node::Checks;
#------------------------------------------------------------------------------
# Nagios/Node/Checks/Client.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use POSIX;
#------------------------------------------------------------------------------
sub Client
{
  my ($Checks, $Check, @Command) = @_;
  my ($Config, $Instance, $Var, $Uuid, @Stat, $Age, $State, $Output);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Checks->Client(...);") if (ref($Checks) ne "Nagios::Node::Checks");

  $Config   = $Checks->{"Config"};
  $Instance = $Checks->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";

  if (exists $Check->{"State"}{"IsActive"})
  {
    if (! $Check->{"State"}{"IsActive"})
    {
      return (3, "This Nagios Node is not active !!!");
    }
  }

  $Uuid = $Check->{"host_name"};
  @Stat = stat ("$Var/Client/$Uuid/Record.info");
  return (3, "Client not registered|state=3;1;2;0;3") if ($#Stat < 9);

  $Age    = time() - $Stat[9];
  $State  = 0;
  $State  = 1 if ($Age > $Config->{'client.warning'});
  $State  = 2 if ($Age > $Config->{'client.critical'});
  $State  = 3 if ($Age > $Config->{'client.unknown'});

  $Output  = "Client heartbeat: ";
  $Output .= strftime ("%Y-%m-%d @ %H:%M:%S", gmtime($Stat[9]));
  $Output .= " UTC|state=$State;1;2;0;3 age=$Age";
  $Output .= ";".$Config->{'client.warning'};
  $Output .= ";".$Config->{'client.critical'};
  $Output .= ";0";

  #------------------------------------------------------------------------
  return ($State, $Output);
}
#------------------------------------------------------------------------------
1;
