package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Initialize.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use Fcntl qw(:DEFAULT :flock);
use File::Basename;
use Storable;

use Nagios::Node::IsActive;
use Nagios::Node::LoadConfig;

use Tmdx::Log;

#------------------------------------------------------------------------------
sub Initialize
{
  my ($Node, @Arg) = @_;
  my ($Basename, $Instance, $Config, $Tmdx, $Lock, $State, $Log, $Active);
  my ($Other, @Pid, @Files, $File);
  #------------------------------------------------------------------------
  # Load the configuration and initialize the TMDX Client
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->Initialize();") if (ref($Node) !~ /^Nagios::Node/);

  $Basename = basename ($0);
  $Node->{"Basename"} = $Basename;

  $Instance = basename ($Arg[0]);
  $Instance =~ s/\.cfg$//;
  $Node->{"Instance"} = $Instance;

  $Config = $Node->LoadConfig ($Instance);
  $Node->{"Config"} = $Config;
  $Node->{"Error"}  = $Config->Error();
  return if ($Node->{"Error"});

  $Tmdx = Tmdx::Client->new($Config);
  $Node->{"Tmdx"} = $Tmdx;
  $Node->{"Error"} = $Tmdx->Error();
  return if ($Node->{"Error"});

  #------------------------------------------------------------------------
  # Get the 'init' lock, load the state file and open the log
  #------------------------------------------------------------------------

  if (! open ($Lock, ">>/var/Nagios/Node/$Instance/Initialize.pid"))
  {
    $Node->{"Error"} = "Unable to open '/var/Nagios/Node/$Instance/Initialize.pid': $!";
    return;
  }
  if (! flock ($Lock, LOCK_EX)) # wait for lock !!!
  {
    close ($Lock);
    $Node->{"Error"} = "Unable to lock '/var/Nagios/Node/$Instance/Initialize.pid': $!";
    return;
  }

  $State = undef;
  eval { $State = Storable::lock_retrieve ("/var/Nagios/Node/$Instance/State.pds"); };  
  $State = {} if (ref($State) ne "HASH");
  $Node->{"State"} = $State;

  $Log = Tmdx::Log->new ("/var/Nagios/Node/$Instance/log", "Initialize.log");
  $Node->{"Log"} = $Log;

  #------------------------------------------------------------------------
  # Check if we are the active or passive
  #------------------------------------------------------------------------

  $Active = $Node->IsActive();
  if (! exists $State->{"IsActive"})    { $State->{"IsActive"} = $Active; }
  if (! exists $State->{"LastActive"})  { $State->{"LastActive"}  = 0; }
  if (! exists $State->{"LastPassive"}) { $State->{"LastPassive"} = 0; }

  $Other = undef;
  eval { $Other = Storable::lock_retrieve("/var/Nagios/Node/$Instance.rsync/State.pds"); };  
  if (ref($Other) ne "HASH")
  {
      $Other = {"IsActive" => 0, "LastActive" => 0, "LastPassive" => 0};
  }
  if ($Active) # Try to set active
  { 
    require Nagios::Node::SetActive;
    $Node->SetActive ($Other);
  }
  else # Try to set passive
  {
    require Nagios::Node::SetPassive;
    $Node->SetPassive ($Other);
  }

  #------------------------------------------------------------------------
  # Update the marker & state files, close the log and release the lock
  #------------------------------------------------------------------------

  if ($State->{"IsActive"})
  {
    $State->{"LastActive"}  = time();
    `touch /var/Nagios/Node/$Instance/Active.pid`;
    unlink ("/var/Nagios/Node/$Instance/Passive.pid");
  }
  else
  {
    $State->{"LastPassive"} = time();
    `touch /var/Nagios/Node/$Instance/Passive.pid`;
    unlink ("/var/Nagios/Node/$Instance/Active.pid");
  }

  $Node->{"Log"} = undef;
  $Log->Close();
  $Log = undef;

  eval { Storable::lock_nstore ($State, "/var/Nagios/Node/$Instance/State.pds"); };  
  if ($@) { $Node->{"Error"} = $@; }
  close ($Lock);
  $Lock = undef;

  #------------------------------------------------------------------------
  return;
}
#------------------------------------------------------------------------------
1;












