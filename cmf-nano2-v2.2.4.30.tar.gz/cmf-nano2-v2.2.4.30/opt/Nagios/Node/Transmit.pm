package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Transmit.pm
#------------------------------------------------------------------------------
@Nagios::Node::Transmit::ISA       = ("Nagios::Node");

use strict;
use warnings;
use File::Copy;
use Storable;

use Nagios::Node::Transmit::Clients;
use Nagios::Node::Transmit::Status;

use Tmdx::Client::Transmit;
use Tmdx::Lock;
use Tmdx::Log;
#------------------------------------------------------------------------------
sub Transmit
{
  my ($Transmit, $Command) = @_;
  my ($Config, $Instance, $Tmdx, $Var, $Lock, $Log, $Status, $Bots, $Key);
  my ($Record, $Data, $Section, $Array, $Entry, $Event, $Info, $Error);
  #------------------------------------------------------------------------
  # Initialize, lock & start logging
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->Transmit();") if (ref($Transmit) ne "Nagios::Node");
  $Transmit->{"Lock"} = undef;
  $Transmit->{"Log"}  = undef;
  bless ($Transmit, "Nagios::Node::Transmit");

  $Config   = $Transmit->{"Config"};
  $Instance = $Transmit->{"Instance"};
  $Tmdx     = $Transmit->{"Tmdx"};
  $Var      = "/var/Nagios/Node/$Instance";

  $Lock     = Tmdx::Lock->new ("$Var/Transmit.pid");
  die ($Lock->Error()."\n") if (defined $Lock->Error());
  if (! $Lock->Lock()) 
  { 
    die ($Lock->Error()."\n") if (defined $Lock->Error());
    die "The Nagios Node Transmit process is already active ...\n";
  }
  $Transmit->{"Lock"} = $Lock;

  $0 = $Command."->Transmit()";
  $Log = Tmdx::Log->new ("$Var/log", "Transmit.log", undef, undef, 1);
  $Log->Log ("------------------------------------------------------------------------------",
             "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
  $Transmit->{"Log"} = $Log;
  #------------------------------------------------------------------------
  # Collect the data
  #------------------------------------------------------------------------
  $Log->Log ("Collecting 'status.log' data");
  ($Status, $Bots) = $Transmit->Status();
  $Status->{"node"}[0] = ();
  foreach $Key (keys %$Config)
  {
    next if ($Key !~ /^[a-z0-9\._]+$/);
    $Status->{"node"}[0]{$Key} = $Config->{$Key};
  }
  $Status->{"node"}[0]{version} = $main::VERSION;
  ($Status->{"client"}, $Record) = $Transmit->Clients();
  #------------------------------------------------------------------------
  # Save the collected data
  #------------------------------------------------------------------------
  $Data  = "";
  foreach $Section (keys %$Status)
  {
    $Array = $Status->{$Section};
    if (ref($Array) ne "ARRAY") { $Array = [$Status->{$Section}]; }
    foreach $Entry (@$Array)
    {
      next if (ref($Entry) ne "HASH");
      $Data .= "$Section {\n";
      foreach $Key (sort keys %$Entry)
      {
        $Data .= "\t$Key=$Entry->{$Key}\n"; 
      }
      $Data .= "\t}\n\n";
    }
  }
  $Log->Log ("Saving '$Var/status.log'");
  if (open (LOG, ">$Var/status.log")) { print LOG $Data; close (LOG); }
  else { $Log->Log ("WARNING: Unable to write 'status.log': $!"); }
  #------------------------------------------------------------------------
  # Process the data according to the configured transmit mode
  #------------------------------------------------------------------------
  if ($Config->{"transmit.mode"} < 3)
  {
    $Event = "nano.status";  $Data .= "\n[eof]\n";
  }
  elsif ($Config->{"transmit.mode"} == 3)
  {
    $Event = "nano.status2"; $Data  = Storable::nfreeze ($Status);
  }
  elsif ($Config->{"transmit.mode"} == 4)
  {
    $Event = "gnf.node";     $Data  = Storable::nfreeze ($Status);
  }
  else
  {
    $Log->Log ("ERROR: transmit mode ".$Config->{"transmit.mode"}." is invalid");
    return 0;
  }
  #------------------------------------------------------------------------
  # Transmit the collected data to headquarters
  #------------------------------------------------------------------------
  $Info = { "to"=>$Config->{'nahq'}, "event"=>$Event, "ttl"=>300 };
  $Error = $Tmdx->Transmit($Info, "$Event\n\n$Data");
  if (! $Error) 
  {
    $Log->Log ("  Posted 'status.log' as '$Event' for '$Config->{'nahq'}'");
    if (open (ACK, ">$Var/Transmit.ack")) { close (ACK); }
    utime (time(),time(),"$Var/Transmit.ack");
  }
  else { $Log->Log ("WARNING: Unable to post 'status.log': $Error"); }
  #------------------------------------------------------------------------
  # Transmit the collected report to the bots handler
  #------------------------------------------------------------------------
  if (scalar (keys %$Bots))
  {
	$Info = { "to" => "bots" };
	$Data = Storable::nfreeze ($Bots);
	$Error = $Tmdx->Transmit ($Info, $Data);
	if (! $Error) { $Bots = {}; }
	else { $Log->Log ("WARNING: Unable to post report: $Error"); }
    Storable::lock_nstore ($Bots, "$Var/Bots.pds");
  }
  #------------------------------------------------------------------------
  # Transmit the collected record to SeCoDB
  #------------------------------------------------------------------------
  $Info = { "to"=>$Config->{'secodb'}, "event"=>"nano.clients", "ttl"=>300 };
  $Data = Storable::nfreeze ($Record);
  $Error = $Tmdx->Transmit($Info, $Data);
  if (! $Error) 
  {
    $Log->Log ("  Posted client info as 'nano.clients' for '$Config->{'secodb'}'");
  }
  else { $Log->Log ("WARNING: Unable to post client info: $Error"); }
  $Lock->Unlock();
  #------------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
