package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/SetPassive.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use POSIX;
#------------------------------------------------------------------------------
sub SetPassive
{
  my ($Node, $Other) = @_;
  my ($Instance, $State, $Log, $Delay, $Message, $Time);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->SetPassive();") if (ref($Node) !~ /^Nagios::Node/);

  $Instance = $Node->{"Instance"};
  $State    = $Node->{"State"};
  $Log      = $Node->{"Log"};
  return if (! $State->{"IsActive"}); # state not changed
  #------------------------------------------------------------------------
  # Check if it is save to become active
  #------------------------------------------------------------------------
  $Delay = time() - $State->{"LastPassive"};
  if ($Delay < 300) # Must stay active for at least 5 minutes ...
  {
    $Message = strftime ("Stuck at ACTIVE until %H:%M:%S UTC !!!\n", gmtime($State->{"LastActive"}+300));
    $Log->Log ($Message);
    print STDERR $Message;
    return;
  }
  $Time = time();
  $Log->Log ("------------------------------------------------------------------------------",
             "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
  $Message = strftime ("Switching to PASSIVE at %H:%M:%S UTC\n", gmtime($Time));
  $Log->Log ($Message);
  print STDERR $Message;

  require Nagios::Node::Stop;
  $Node->Stop ($Log);

  $State->{"IsActive"} = 0;
  #------------------------------------------------------------------------
  return;
}
#------------------------------------------------------------------------------
1;
