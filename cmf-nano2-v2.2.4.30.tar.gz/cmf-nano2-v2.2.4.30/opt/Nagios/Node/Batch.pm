package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Batch.pm
#------------------------------------------------------------------------------
@Nagios::Node::Batch::ISA       = ("Nagios::Node");

use strict;
use warnings;
use POSIX;
use Storable;

use Nagios::Node::Batch::Job;

use Tmdx::Lock;
use Tmdx::Log;
#------------------------------------------------------------------------------
sub Batch
{
  my ($Batch, $Command, @Arg) = @_;
  my ($Instance, $Var, $Lock, $Log, $Last, $Arg, $Time, $Gmtime, $Now);
  my ($Job, $Path, @Tasks, $Task, $Eval);
  #------------------------------------------------------------------------
  # Initialize, lock & delay logging
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->Batch();") if (ref($Batch) ne "Nagios::Node");
  $Batch->{"Lock"} = undef;
  $Batch->{"Log"}  = undef;
  bless ($Batch, "Nagios::Node::Batch");

  $Instance = $Batch->{"Instance"};
  $Var      = "/var/Nagios/Node/$Instance";

  $Lock     = Tmdx::Lock->new ("$Var/Batch.pid");
  die ($Lock->Error()."\n") if (defined $Lock->Error());
  if (! $Lock->Lock()) 
  { 
    die ($Lock->Error()."\n") if (defined $Lock->Error());
    die "The Nagios::Node('$Instance')::Batch() process is already active ...\n";
  }
  $Batch->{"Lock"} = $Lock;

  $0       = $Command."->Batch()";
  $Log     = undef; # Delay logging until we need it
  POSIX::nice (5);
  #------------------------------------------------------------------------
  # Check which batches are needed ...
  #------------------------------------------------------------------------
  eval { $Last = Storable::retrieve ("$Var/Batch.pds"); };
  if (ref($Last) ne "HASH")
  {
    $Last = { "Hourly" => "", "Daily" => "", "Weekly" => "", "Monthly" => "" };
  }
  shift @Arg; shift @Arg;
  foreach $Arg (@Arg)
  {
    $Last->{"Hourly"}  = "" if (($Arg =~ /^[h]/i)||($Arg =~ /^[a]/i));
    $Last->{"Daily"}   = "" if (($Arg =~ /^[d]/i)||($Arg =~ /^[a]/i));
    $Last->{"Weekly"}  = "" if (($Arg =~ /^[w]/i)||($Arg =~ /^[a]/i));
    $Last->{"Monthly"} = "" if (($Arg =~ /^[m]/i)||($Arg =~ /^[a]/i));
  }
  $Time   = time();
  $Now = { "Hourly"  => strftime("H%m%d%H",gmtime($Time-300)), # 00:05 past
           "Daily"   => strftime("D%y0%j",gmtime($Time-7800)), # 02:15 past
           "Weekly"  => strftime("W%Y%W",gmtime($Time-11400)), # 03:15 past
           "Monthly" => strftime("M%Y%m",gmtime($Time-15000))};# 04:15 past
  #------------------------------------------------------------------------
  # Start batch processing ...
  #------------------------------------------------------------------------
  foreach $Job ("Hourly", "Daily", "Weekly", "Monthly")
  {
    next if ($Now->{$Job} eq $Last->{$Job});
    if (! defined $Log)
    {
      $Log = Tmdx::Log->new ("$Var/log", "Batch.log", undef, undef, 1);
      $Log->Log ("------------------------------------------------------------------------------",
                 "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
      $Batch->{"Log"} = $Log;
    }
    $Batch->Job ($Job, $Now->{$Job});
  }
  Storable::nstore ($Now, "$Var/Batch.pds");
  $Lock->Unlock();
  #------------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
 