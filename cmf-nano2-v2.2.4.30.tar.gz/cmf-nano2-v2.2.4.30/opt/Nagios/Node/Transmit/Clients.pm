package Nagios::Node::Transmit;
#------------------------------------------------------------------------------
# Nagios/Node/Transmit/Clients.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use Nagios::Node::CoreCommand;
use Nagios::Node::Transmit::Client::Record;
use Nagios::Node::Transmit::Triggers;
#------------------------------------------------------------------------------
sub Clients
{
  my ($Transmit) = @_;
  my ($Config, $Instance, $Log, $Var);
  my (@Client, $Info, $Count, @Clients, $Commands, $Triggers, $Uuid);
  my ($Client, $Record, $Age, $State, $Id, $Message, @Stat, $Key, $File);
  #--------------------------------------------------------------------
  $Config   = $Transmit->{"Config"};
  $Instance = $Transmit->{"Instance"};
  $Log      = $Transmit->{"Log"};
  $Var      = "/var/Nagios/Node/$Instance";
  #--------------------------------------------------------------------
  @Client   = ();
  $Info     = {};
  $Count    = 0;
  if (! opendir (CLIENTS, "$Var/Client"))
  {
    $Log->Log ("  Skipping Nagios Client records: $!"); 
    return \@Client;
  }
  $Log->Log ("  Processing Nagios Client records");
  @Clients  = grep { !/\./ } readdir (CLIENTS);
  closedir (CLIENTS);
  $Commands = "";
  $Triggers = "";
  for $Uuid (@Clients)
  {
    $Client = $Transmit->Client_Record ($Uuid); # deletes expired registrations ...
    next if (! defined $Client);
    $Record = $Client->{Record};
    $Age    = $Client->{Age};
    $Client[$Count] = $Record;
    $Info->{$Uuid} = $Client->{Info};
    $Count++;
    #----------------------------------------------------------
    # Check for 'late' clients
    #----------------------------------------------------------
    if (defined $Age)
    {
      $State = 0;
      $State = 1 if ($Age > $Config->{'client.warning'});
      $State = 2 if ($Age > $Config->{'client.critical'});
      $State = 3 if ($Age > $Config->{'client.unknown'});
      $Info->{$Uuid}{state} = $State;
      if ($Age > 75)
      {
        $Commands .= "PROCESS_HOST_CHECK_RESULT;$Uuid;$State;";
        $Commands .= $Record->{"plugin_output"} if (exists $Record->{"plugin_output"});
        $Commands .= "|age=".$Age."s";
        if ($Config->{"debug"})
        {
          $Id = $Uuid;
          $Id = $Record->{"plugin_output"} if (exists $Record->{"plugin_output"});
          $Message = "    Marking $Id as";
          if    ($State == 1) { $Log->Log ("$Message WARNING (UNREACHABLE)"); }
          elsif ($State == 2) { $Log->Log ("$Message CRITICAL (DOWN)");       }
          else                { $Log->Log ("$Message UNKNOWN (EXPIRED)");     }
        }
        $Commands .= "\n";
      }
    }
    #----------------------------------------------------------
    # Check for 'triggers'
    #----------------------------------------------------------
    $File = "$Var/Client/$Uuid/trigger";
    if ((exists $Record->{'tag.nano.trigger'}) && ($Config->{'trigger.target'} ne ""))
    {
      if (-d "$Var/Client/$Uuid") 
      {
        $Age  = time();
        @Stat = stat ($File);
        if ($#Stat >= 9) { $Age -= $Stat[9]; }
        if ($Age >= $Config->{'trigger.interval'})
        {
          $Triggers .= "Client {\n";
          foreach $Key (sort keys %$Record)
          {
            $Triggers .= "\t$Key=$Record->{$Key}\n";
          }
          $Triggers .= "\t}\n";
          close (TRIGGER) if (open (TRIGGER, ">>$File")); 
          utime (time(), time(), $File);
        }
      }
    }
    else { unlink ($File); }
  }
  sleep (1);
  $Transmit->CoreCommand ($Commands) if ($Commands ne "");
  $Transmit->Triggers ($Triggers) if ($Triggers ne "");
  #--------------------------------------------------------------------
  return (\@Client, $Info);
}
#------------------------------------------------------------------------------
1;
  