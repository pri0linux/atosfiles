package Nagios::Node::Transmit;
#------------------------------------------------------------------------------
# Nagios/Node/Transmit/Triggers.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use Tmdx::Client::Transmit;
#------------------------------------------------------------------------------
sub Triggers
{
  my ($Transmit, $Triggers) = @_;
  my ($Config, $Instance, $Tmdx, $Var, $Log, $Info, $Error);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Transmit->Triggers(...);") if (ref($Transmit) ne "Nagios::Node::Transmit");
  return if (! defined $Triggers);
  return if ($Triggers eq "");
  $Config   = $Transmit->{"Config"};
  $Instance = $Transmit->{"Instance"};
  $Tmdx     = $Transmit->{"Tmdx"};
  $Var      = "/var/Nagios/Node/$Instance";
  $Log      = $Transmit->{"Log"};
  $Info     = { "to"    => $Config->{'trigger.target'}, 
                "event" => "nano.trigger", 
                "ttl"   => $Config->{'trigger.interval'} };
  $Error    = $Tmdx->Transmit ($Info, "nano.trigger\n\n$Triggers");
  if ($Error) { $Log->Log ("WARNING: Unable to post triggers: $Error"); }
  else { $Log->Log ("  Posted triggers to '$Config->{'trigger.target'}'"); }
  #------------------------------------------------------------------------
  return undef;
}
#------------------------------------------------------------------------------
1;
 