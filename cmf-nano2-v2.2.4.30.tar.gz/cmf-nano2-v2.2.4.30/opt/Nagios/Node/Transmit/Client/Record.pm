package Nagios::Node::Transmit;
#------------------------------------------------------------------------------
# Nagios/Node/Transmit/Client/Record.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Client_Record {
	my ($Transmit, $Uuid) = @_;
	my ($Config, $Instance, $Log, $Var);
	my ($Record, $System, $Client, $Tags, @Tags, $Tag, $Name, $Value);
	#----------------------------------------------------------------------
	# Initialize
	#----------------------------------------------------------------------
	die ("Usage: Nagios::Node::Transmit->Client_Record(\$Uuid);") if (ref($Transmit) ne "Nagios::Node::Transmit");
	return undef if (! defined $Uuid);
	$Config   = $Transmit->{"Config"};
	$Instance = $Transmit->{"Instance"};
	$Log      = $Transmit->{"Log"};
	$Var      = "/var/Nagios/Node/$Instance";
	#----------------------------------------------------------------------
	# Load the client record and system info
	#----------------------------------------------------------------------
	$Record = undef;
	eval { $Record = Storable::lock_retrieve ("$Var/Client/$Uuid/Record.pds"); };
	return undef if (ref($Record) ne "HASH");
	$System = undef;
	eval { $System = Storable::lock_retrieve ("$Var/Client/$Uuid/System.pds"); };
	$System = undef if (ref($System) ne "HASH");

	$Client = { 
		Record => {
			address			=> $Record->{address},
			host			=> $Record->{name},
			_host			=> $Record->{uuid},
			_last_check		=> $Record->{time},
			plugin_output	=> $Record->{agent},
			version			=> join (".", @{$Record->{version}}[0..3]),
			architecture	=> $System->{'client.architecture'},
			boottime		=> $System->{'system.boottime'},
			compiler		=> $System->{'client.compiler'},
			type			=> $System->{'client.type'},
			uname			=> $System->{'system.uname'},
			protocol 		=> $Record->{protocol},
			cipher  		=> $Record->{cipher}
		},
		Info => {
			id				=> $Record->{uuid},
			name			=> $Record->{name},
			node			=> "",
			output			=> $Record->{agent},
			state			=> -1,
			time			=> $Record->{time},
			version			=> join (".", @{$Record->{version}}[0..3]),
			architecture	=> $System->{'client.architecture'},
			compiler		=> $System->{'client.compiler'},
			type			=> $System->{'client.type'},
			system          => {
				boottime	=> $System->{'system.boottime'},
				uname		=> $System->{'system.uname'}
			},
			ssl => {
				protocol	=> $Record->{protocol},
				cipher		=> $Record->{cipher}
			}
		},
		Age => time() - int($Record->{time})
		
	};
	foreach $Name (keys %{$Client->{Record}}) {
		$Client->{Record}{$Name} = "" if (! defined $Client->{Record}{$Name});
	}
	foreach $Name (keys %{$Client->{Info}}) {
		$Client->{Info}{$Name} = "" if (! defined $Client->{Info}{$Name});
	}
	foreach $Name (keys %{$Client->{Info}{system}}) {
		$Client->{Info}{system}{$Name} = "" if (! defined $Client->{Info}{system}{$Name});
	}
	foreach $Name (keys %{$Client->{Info}{ssl}}) {
        $Client->{Info}{ssl}{$Name} = "" if (! defined $Client->{Info}{ssl}{$Name});
    }
	if ($Record->{version}[4]) {
		$Client->{Record}{version} .= "-".$Record->{version}[4];
		$Client->{Info}{version}   .= "-".$Record->{version}[4];
	}
	#----------------------------------------------------------------------
	$Tags = undef;
	eval { $Tags = Storable::lock_retrieve ("$Var/Client/$Uuid/Tags.pds"); };
	@Tags = ();
	if (ref($Tags) eq "HASH") {
		foreach $Tag (keys %$Tags) {
			$Name  = $Tag;               
			$Name  =~ s/\s+//g; # no whitespaces in tag names
			$Name  =~ s/[\x00-\x1F\x7F]+//g;
			$Value = $Tags->{$Tag}; 
			$Value =~ s/\s/ /g; # only spaces in tag values
			$Value =~ s/[\x00-\x1F\x7F]+//g;
			$Client->{Record}{"tag.$Name"} = $Value;
			$Client->{Info}{tag}{$Name} = $Value;
			$Name  =~ s/\\/\\\\/g; # JSON escape backslashes
			$Name  =~ s/"/\\"/g;   # JSON escape double quotes
			$Value =~ s/\\/\\\\/g; # JSON escape backslashes
			$Value =~ s/"/\\"/g;   # JSON escape double quotes
			push (@Tags, "\"$Name\":\"$Value\"");
		}
	}
	$Client->{Record}{_tags} = "{".join(",",@Tags)."}";
	#----------------------------------------------------------------------
	# Check the age
	#----------------------------------------------------------------------
	if ($Client->{"Age"} > $Config->{'client.unregister'}) {
		$Log->Log("    Unregistering ".$Client->{"Record"}{"plugin_output"});
		`rm -rf $Var/Client/$Uuid`;
		return undef;
    }
	#----------------------------------------------------------------------
	return $Client;
}
#------------------------------------------------------------------------------
1;
  