package Nagios::Node::Transmit;
#------------------------------------------------------------------------------
# Nagios/Node/Transmit/Status/Bots.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Status_Bots
{
	my ($Transmit, $Section, $Status, $Bots) = @_;
	my ($Config, $Instance, $Log, $Mode, $Var, $Id, $Index, $Record);
	#----------------------------------------------------------------------
	die ("Usage: Nagios::Node::Transmit->Status_Bots(...);") if (ref($Transmit) ne "Nagios::Node::Transmit");
	return if (! defined $Section);
	return if ($Section !~ /^hoststatus|servicestatus$/);
	$Config   = $Transmit->{"Config"};
	$Instance = $Transmit->{"Instance"};
	$Log      = $Transmit->{"Log"};
	$Mode     = $Config->{"transmit.mode"};
	$Var      = "/var/Nagios/Node/$Instance";
	#----------------------------------------------------------------------
	$Id = undef;
	$Id = $Status->{host_name} if ($Section eq "hoststatus");
	$Id = $Status->{service_description} if ($Section eq "servicestatus");
	return if (! defined $Id);
	if (! exists $Transmit->{"Status.index"})
	{
		eval { $Index = Storable::lock_retrieve ("$Var/Index.pds"); };
		return if (ref($Index) ne "HASH");
		$Transmit->{"Status.index"} = $Index;
	}
	else { $Index = $Transmit->{"Status.index"}; }
	return if (! exists $Index->{$Id});
	return if (! exists $Index->{$Id}{bot});
	$Index->{$Id}{bot}{TIME} = time();
	#----------------------------------------------------------------------
	if ($Section eq "hoststatus")
	{
		$Record = 
		{ 
			type         => "host",
			id           => $Id,
			name         => $Index->{$Id}{name},
			time         => $Status->{last_check},
			state        => $Status->{current_state},
			output       => $Status->{plugin_output},
			perfdata     => $Status->{performance_data},
			longoutput   => $Status->{long_plugin_output},
			notification => 0,
			bot          => $Index->{$Id}{bot},
			tag          => $Index->{$Id}{tag},
			check        => $Index->{$Id}{check}
		};
		$Bots->{$Id} = $Record;
		return;
	}
	#----------------------------------------------------------------------
	if ($Section eq "servicestatus")
	{
		$Record = 
		{ 
			type         => "service",
			id           => $Id,
			name         => $Index->{$Id}{name},
			team         => $Index->{$Id}{team},
			time         => $Status->{last_check},
			state        => $Status->{current_state},
			output       => $Status->{plugin_output},
			perfdata     => $Status->{performance_data},
			longoutput   => $Status->{long_plugin_output},
			notification => 0,
			bot          => $Index->{$Id}{bot},
			tag          => $Index->{$Id}{tag},
			check        => $Index->{$Id}{check},
			host         => $Index->{$Id}{host}
		};
		$Bots->{$Id} = $Record;
		return;
	}
	#----------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
 