package Nagios::Node::Transmit;
#------------------------------------------------------------------------------
# Nagios/Node/Transmit/Status/Map.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Status_Map
{
  my ($Transmit, $Section, %Section) = @_;
  my ($Config, $Instance, $Log, $Mode, $Var);
  my ($Map, $Name, $Value, $Mapped, $In, $Out);
  #------------------------------------------------------------------------
  # Initialize
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node::Transmit->Status_Map(...);") if (ref($Transmit) ne "Nagios::Node::Transmit");
  return undef if (! defined $Section);
  $Config   = $Transmit->{"Config"};
  $Instance = $Transmit->{"Instance"};
  $Log      = $Transmit->{"Log"};
  $Mode     = $Config->{"transmit.mode"};
  $Var      = "/var/Nagios/Node/$Instance";
  #------------------------------------------------------------------------
  # Load the status map (create default if it doesn't exist)
  #------------------------------------------------------------------------
  if (! exists $Transmit->{"Status.map"})
  {
    eval { $Map = Storable::lock_retrieve ("$Var/Status.map"); };
    if (ref($Map) ne "HASH") 
    { 
      $Map = { "info"            => undef,
               "programstatus"   => undef,
               "hoststatus"      => { "host_name"                     => undef,
                                      "plugin_output"                 => undef,
                                      "performance_data"              => undef,
                                      "long_plugin_output"            => undef,
                                      "last_check"                    => undef,
                                      "is_flapping"                   => undef,
                                      "current_state"                 => undef,
                                      "problem_has_been_acknowledged" => undef,
                                      "acknowledgement_type"          => undef,
                                      "notifications_enabled"         => undef,
                                      "active_checks_enabled"         => undef,
                                      "passive_checks_enabled"        => undef,
                                      "scheduled_downtime_depth"      => undef,
                                      "last_time_up"                  => undef,
                                      "current_attempt"               => undef,
                                      "max_attempts"                  => undef,
                                      "state_type"                    => undef,
                                      "last_hard_state"               => undef, },
               "hostcomment"     => { "host_name"                     => undef,
                                      "comment_id"                    => undef,
                                      "entry_time"                    => undef,
                                      "entry_type"                    => undef,
                                      "author"                        => undef,
                                      "comment_data"                  => undef, },
               "hostdowntime"    => { "host_name"                     => undef,
	                               "downtime_id"                   => undef,
	                               "entry_time"                    => undef,
	                               "start_time"                    => undef,
	                               "end_time"                      => undef,
	                               "duration"                      => undef,
	                               "author"                        => undef,
	                               "comment"                       => undef, },
               "servicestatus"   => { "host_name"                     => undef,
                                      "service_description"           => undef,
                                      "plugin_output"                 => undef,
                                      "performance_data"              => undef,
                                      "long_plugin_output"            => undef,
                                      "last_check"                    => undef,
                                      "is_flapping"                   => undef,
                                      "current_state"                 => undef,
                                      "problem_has_been_acknowledged" => undef,
                                      "acknowledgement_type"          => undef,
                                      "notifications_enabled"         => undef,
                                      "active_checks_enabled"         => undef,
                                      "passive_checks_enabled"        => undef,
                                      "scheduled_downtime_depth"      => undef,
                                      "current_attempt"               => undef,
                                      "max_attempts"                  => undef,
                                      "state_type"                    => undef,
                                      "last_hard_state"               => undef, },
               "servicecomment"  => { "host_name"                     => undef,
                                      "service_description"           => undef,
                                      "comment_id"                    => undef,
                                      "entry_time"                    => undef,
                                      "entry_type"                    => undef,
                                      "author"                        => undef,
                                      "comment_data"                  => undef, },
               "servicedowntime" => { "host_name"                     => undef,
                                      "service_description"           => undef,
	                               "downtime_id"                   => undef,
	                               "entry_time"                    => undef,
	                               "start_time"                    => undef,
	                               "end_time"                      => undef,
	                               "duration"                      => undef,
	                               "author"                        => undef,
	                               "comment"                       => undef, },
               "contactstatus"   => { "contact_name"                  => undef,
                                      "host_notifications_enabled"    => undef,
                                      "service_notifications_enabled" => undef, },
      }; 
      Storable::lock_nstore ($Map, "$Var/Status.map");
    } 
    $Transmit->{"Status.Map"} = $Map;
  }
  else { $Map = $Transmit->{"Status.map"}; }
  #------------------------------------------------------------------------
  # Map the specified section according to the mode
  #------------------------------------------------------------------------
  return undef if (! exists $Map->{$Section});
  $Mapped = {};
  foreach $In (keys %Section)
  {
    $Out = lc ($In);
    if ($Mode > 0)
    {
      if (defined $Map->{$Section})
      {
        next if (! exists $Map->{$Section}{lc($In)});
        if ($Mode > 3)
        {
          if (defined $Map->{$Section}{lc($In)})
          {
            $Out = $Map->{$Section}{lc($In)};
          }
        }
      }
    }
    $Mapped->{lc($Out)} = $Section{$In};
  }    
  #------------------------------------------------------------------------
  return $Mapped;
}
#------------------------------------------------------------------------------
1;
 