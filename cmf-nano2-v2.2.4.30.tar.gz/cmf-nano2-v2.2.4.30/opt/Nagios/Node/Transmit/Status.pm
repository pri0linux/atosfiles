package Nagios::Node::Transmit;
#------------------------------------------------------------------------------
# Nagios/Node/Transmit/Status.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Copy;
use Storable;

use Nagios::Node::CoreCommand;
use Nagios::Node::Transmit::Status::Bots;
use Nagios::Node::Transmit::Status::Map;
use Nagios::Node::Transmit::Triggers;
#------------------------------------------------------------------------------
sub Status
{
  my ($Transmit) = @_;
  my ($Config, $Instance, $Log, $Mode, $Var, $Status, $Keys, $Count);
  my ($Old, $New, $Bots, $Data, @Data, $Section, %Section, $Key);
  my ($Name, $Map);
  #--------------------------------------------------------------------
  # Initialize
  #--------------------------------------------------------------------
  die ("Usage: Nagios::Node::Transmit->Status();") if (ref($Transmit) ne "Nagios::Node::Transmit");
  $Config   = $Transmit->{"Config"};
  $Instance = $Transmit->{"Instance"};
  $Log      = $Transmit->{"Log"};
  $Mode     = $Config->{"transmit.mode"};
  $Var      = "/var/Nagios/Node/$Instance";
  $Status   = {};
  $Keys     = { "hoststatus"      => "host_name",
                "hostcomment"     => "comment_id",
                "hostdowntime"    => "downtime_id",
                "servicestatus"   => "service_description",
                "servicecomment"  => "comment_id",
                "servicedowntime" => "downtime_id",
                "contactstatus"   => "contact_name" };
  $Count    = {};
  $Storable::canonical = 1;
  eval { $Old = Storable::lock_retrieve ("$Var/Status.ref"); };
  $Old     = { "_refresh" => 0 } if (ref($Old) ne "HASH");
  $New     = { "_refresh" => ($Old->{"_refresh"} + 1) % 15 };
  eval { $Bots = Storable::lock_retrieve ("$Var/Bots.pds"); };
  $Bots = {} if (ref($Bots) ne "HASH"); # Info to be reported to the 'bots'
  #--------------------------------------------------------------------
  # Load the information from $Var/status.dat
  #--------------------------------------------------------------------
  if (copy ("$Var/status.dat", "$Var/status.tmp"))
  {
    if (open (TEMP, "<$Var/status.tmp")) 
    {
      $Log->Log ("  Processing 'status.dat'");
      $Data   = join ("", <TEMP>);
      close (TEMP);
      @Data   = split (/\n\s*\}\s*\n\s*/, $Data);
      foreach $Data (@Data)
      {
        ($Section, $Data) = split (/\s*\{\s*\n\s*/, $Data, 2);
        next if (! defined $Data);
        $Section = lc($Section);
        %Section = ();
        foreach (split(/\s*\n\s*/, $Data)) { if (/(.*?)=(.*)/) { $Section{lc($1)}=$2 ; } }
        $Key = "_";
        if (exists $Keys->{$Section})
        {          
          $Key = undef;
          $Name = $Keys->{$Section};
          $Key = $Section{$Name} if (exists $Section{$Name});
        }
        if (defined $Key)
        {
          $Map = $Transmit->Status_Map ($Section, %Section);
          if (defined $Map)
          {
            if ($Mode > 1) # Only report changed records + refreshes
            {
              $New->{$Section}{$Key} = Storable::nfreeze ($Map);
              if (exists $Old->{$Section}{$Key})
              {
                if ($New->{$Section}{$Key} eq $Old->{$Section}{$Key})
                {
#                  if ($New->{"_refresh"} ne (unpack("%32C*",$Key) % 15))
#                  {
                     $Map = undef;
#                  }
                }
              }
            }
            if (defined $Map)
            {
              $Count->{$Section} = 0 if (! exists $Count->{$Section});
              $Status->{$Section}[$Count->{$Section}] = $Map;
              $Count->{$Section}++;
			  $Transmit->Status_Bots ($Section, \%Section, $Bots);
            }
          }
        }
      }
    }
    else { $Log->Log ("  Skipping 'status.dat': $!"); }
  }
  else { $Log->Log ("  Skipping 'status.dat': $!"); }
  unlink "$Var/status.tmp";
  Storable::lock_nstore ($New, "$Var/Status.ref");
  #--------------------------------------------------------------------
  return ($Status, $Bots);
}
#------------------------------------------------------------------------------
1;
  