package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/Handler2.pm 
#------------------------------------------------------------------------------
use strict;
use warnings;

#------------------------------------------------------------------------------
sub Handler2
{
	my ($This, $Info, $Entry) = @_;
	my ($Path, $Gzip, $Data, $Read, @Data, $Tags, $Time, $Host);
	my ($Line, @Line, $File);
	#------------------------------------------------------------------------
	$Path = "/var/Nagios/Node/$This->{Instance}/Client";
	if (! ($Gzip = gzopen("$Path/.Input/$Entry.data", "rb")))
	{
		$This->{Log}->Log ("ERROR reading 'Client/.Input/$Entry.data': $!");
		return;
	}
	$Data = "";
	while ($Gzip->gzread($Read)) { $Data .= $Read; }
	$Gzip->gzclose();
	@Data = split (/\n/, $Data);
    $Data = [];
    $Tags = {};
	#------------------------------------------------------------------------
	$Time = int ($Info->{time});
	$Host = $Info->{uuid};
    $Line = "[$Time] PROCESS_HOST_CHECK_RESULT;$Host;0;$Info->{agent}|age=0s";
    push (@$Data, $Line);
    foreach $Line (@Data)
    {
		$Line =~ s/^\s+//; $Line =~ s/\s+$//;
		if ($Line =~ /^tag./i)
		{
			$Line =~ s/^tag.//i;
			@Line = split (/=/, $Line, 2);
			next if ($#Line != 1);
			$Tags->{lc $Line[0]} = $Line[1];
			next;
		}
		next if ($Line !~ /^\[\d{10}\]\s/);
		@Line = ($Line =~ /^\[(\d{10})\]\s+(\S.*)$/);
		$Line[0] = $Time if ($Line[0] > $Time); # Future timestamps not allowed
		$Line = "\[$Line[0]\] $Line[1]";
		push (@$Data, $Line);
    }
	#------------------------------------------------------------------------
    Storable::lock_nstore ($Tags, "$Path/$Host/Tags.pds");
    $This->CoreCommand (@$Data);
	#------------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
 