package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/UuidIsValid.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub UuidIsValid # simplified to allow old clients with randomized fake UUIDs
{
	my ($This, $Uuid) = @_;
	my ($Pattern, $Digit);
	#----------------------------------------------------------------------
	# Validate the UUID pattern # new code due to simplification
	#----------------------------------------------------------------------
	return 0 if ((! defined $Uuid) || (ref($Uuid) ne "")); 
	$Pattern = '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f][0-9a-f]{3}-[0-9a-f]{12}$';
	return 0 if  ($Uuid !~ /$Pattern/i);
	#----------------------------------------------------------------------
	# Determine the UUID variant # commented out due to simplification
	#----------------------------------------------------------------------
	#$Pattern = '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-([0-9a-f])[0-9a-f]{3}-[0-9a-f]{12}$';
	#($Digit) = ($Uuid =~ /$Pattern/i);
	#return 0 if (! defined $Digit);
	#$Digit = hex ($Digit);
	#return 1 if ($Digit <  8);	# binary 0xxx = variant 0 (hex 0-7)
	#return 0 if ($Digit > 13);	# binary 111x = reserved  (hex E-F)
	#----------------------------------------------------------------------
	# Validate the UUID version # commented out due to simplification
	#----------------------------------------------------------------------
	#$Pattern = '^[0-9a-f]{8}-[0-9a-f]{4}-([0-9a-f])[0-9a-f]{3}-[0-9a-f]{4}-[0-9a-f]{12}$';
	#($Digit) = ($Uuid =~ /$Pattern/i);
	#return 0 if (! defined $Digit);
	#$Digit = hex ($Digit);			
	#return 0 if (($Digit < 1) || ($Digit > 5)); # Versions 1-5 are valid
	#----------------------------------------------------------------------
	return 1;
}
#------------------------------------------------------------------------------
1;
