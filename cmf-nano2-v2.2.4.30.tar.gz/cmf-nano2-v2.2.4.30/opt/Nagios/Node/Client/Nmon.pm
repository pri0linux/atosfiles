package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/Nmon.pm                           # shared with Njmon !!!
#------------------------------------------------------------------------------
use strict;
use warnings;

use Data::Dumper;
use File::Copy;
use File::Path;
use Time::HiRes;
#------------------------------------------------------------------------------
sub Nmon
{
	my ($This, $Info, $Header, $Record) = @_;
	my ($Path, $Time, $Minute, $File, $Handle);
	#------------------------------------------------------------------------
	$Path = "/var/Nagios/Node/$This->{Instance}/Nmon"; # Shared with njmon
	eval { mkpath ($Path); chmod (0750, $Path); } if (! -d $Path);
	return if (! -d $Path);
	$Time   = Time::HiRes::time();
	$Minute = int ($Time/60);
	mkdir ("$Path/$Minute") if (! -d "$Path/$Minute");
	$File   = sprintf ("%.10f.%05d.%s", $Time, $$, $Info->{uuid});
	return if (! open ($Handle, ">$Path/$Minute/_$File"));
	print $Handle "$Header|$Info->{uuid}\n$Record";
	close ($Handle);
	rename ("$Path/$Minute/_$File", "$Path/$Minute/$File");
	#------------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
 