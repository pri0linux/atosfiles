package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/Handler1.pm 
#------------------------------------------------------------------------------
use strict;
use warnings;

#------------------------------------------------------------------------------
sub Handler1
{
	my ($This, $Info, $Entry) = @_;
	my ($Path, $Gzip, $Data, $Read, @Data, $Tags, $Time, $Host);
	my ($Line, @Line, $File);
	#------------------------------------------------------------------------
	$Path = "/var/Nagios/Node/$This->{Instance}/Client";
	if (! ($Gzip = gzopen("$Path/.Input/$Entry.data", "rb")))
	{
		$This->{Log}->Log ("ERROR reading 'Client/.Input/$Entry.data': $!");
		return;
	}
	$Data = "";
	while ($Gzip->gzread($Read)) { $Data .= $Read; }
	$Gzip->gzclose();
	@Data = split (/\0/, $Data);
    $Data = [];
    $Tags = {};
	#------------------------------------------------------------------------
	$Time = int ($Info->{time});
	$Host = $Info->{uuid};
    $Line = "[$Time] PROCESS_HOST_CHECK_RESULT;$Host;0;$Info->{agent}|age=0s";
    push (@$Data, $Line);
    foreach $Line (@Data)
    {
		next if ($Line =~ /^\s*$/);
		$Line =~ s/^\s+//; $Line =~ s/\s+$//;
		if ($Line =~ /^tag./i)
		{
			$Line =~ s/^tag.//i;
			@Line = split (/=/, $Line, 2);
			next if ($#Line != 1);
			$Tags->{lc $Line[0]} = $Line[1];
			next;
		}
		if ($Line =~ /^file./i)
		{
			next;
		}
		# <uuid>;0;<timestamp>;<result_code>;<result_output>
		@Line = split (/;/, $Line, 5);
		next if ($#Line < 4);
		next if ($Line[1] ne "0");
		next if (! $This->UuidIsValid ($Line[0]));
		$Line[2] = $Time if ($Line[2] > $Time); # Future timestamps not allowed
		($Line[4]) = split (/\n/, $Line[4], 2); # Discard unencoded long output
		$Line = "\[$Line[2]\] PROCESS_SERVICE_CHECK_RESULT;$Host;$Line[0];$Line[3];$Line[4]";
		push (@$Data, $Line);
    }
	#------------------------------------------------------------------------
    Storable::lock_nstore ($Tags, "$Path/$Host/Tags.pds");
    $This->CoreCommand (@$Data);
	#------------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
 