package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/Handler.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use File::Copy;
use File::Path;
use Storable;

use Nagios::Node::Client::Handler1;
use Nagios::Node::Client::Handler2;
use Nagios::Node::Client::Handler3;
use Nagios::Node::Client::Heartbeat;
use Nagios::Node::Client::Nmon;
use Nagios::Node::Client::Register;
use Nagios::Node::Client::Upload;
use Nagios::Node::Client::UuidIsValid;
use Nagios::Node::Client::Validate;
use Nagios::Node::CoreCommand;
#------------------------------------------------------------------------------
sub Handler
{
	my ($This, $Entry) = @_;
	my ($Input, $Output, $Handle, $Info, $Line, @Line, $Path, $Key);
	#------------------------------------------------------------------------
	# Load the information
	#------------------------------------------------------------------------
	$Input  = "/var/Nagios/Node/$This->{Instance}/Client/.Input";
	$Output = "/var/Nagios/Node/$This->{Instance}/Client/.Output";
	$Entry  =~ s/\.info//;
	if (! open ($Handle, "$Input/$Entry.info"))
	{
		$This->{Log}->Log ("ERROR reading 'Client/.Input/$Entry.info': $!");
		unlink ("$Input/$Entry.info");
		return 0;
	}
	$Info = {};
	while ($Line = <$Handle>)
	{
		chomp ($Line);
		@Line = split (/=/, $Line, 2);
		$Info->{lc $Line[0]} = $Line[1] if ($#Line > 0);
	}
	close ($Handle);
	#------------------------------------------------------------------------
	# Validate the client
	#------------------------------------------------------------------------
	if (! $This->Validate ($Info))
	{
		if ($Info->{version}[0] < 3) # NaCl 1.x and 2.x
		{ 
			$Info->{"http.status"} = [400, "Bad Request"]; 
		}
		else # NaCl 3.x and later
		{ 
			$This->Register ($Info); 
		}
	}
	#------------------------------------------------------------------------
	# Handle valid clients
	#------------------------------------------------------------------------
	else
	{
		$Info->{skew} = 0;
		if    ($Info->{version}[0] == 1) { $This->Handler1 ($Info, $Entry); }
		elsif ($Info->{version}[0] == 2) { $This->Handler2 ($Info, $Entry);	}
		elsif ($Info->{version}[0] == 3) { $This->Handler3 ($Info, $Entry);	}
		else                             
		{
			$Line = "Unsupported Client Version ".$Info->{version}[0].".x";
			$This->{Log}->Log ("    $Line");
			$Info->{"http.status"} = [403, $Line]; 
		}
	}
	#------------------------------------------------------------------------
	# Generate the output record
	#------------------------------------------------------------------------
	if (! open ($Handle, ">$Output/$Entry.temp"))
	{
		$This->{Log}->Log ("ERROR writing 'Client/.Output/$Entry.temp': $!");
		$main::Stop++;
		return 0;
	}
	foreach $Key (sort keys %$Info)
	{
		$Line = $Info->{$Key};
		if (ref($Line) eq "ARRAY")
		{
			$Line = join ("|", @{$Info->{$Key}});
		}
		if (ref($Line) eq "")
		{
			print $Handle "$Key=$Line\n";
		}
	}
	close ($Handle);
	move ("$Output/$Entry.temp", "$Output/$Entry.info");
	if ($Info->{valid})
	{
		$Path = "/var/Nagios/Node/$This->{Instance}/Client/$Info->{uuid}";
		eval { mkpath ($Path); } if (! -d $Path); 
		chmod (02770, $Path);
		if (! copy ("$Output/$Entry.info", "$Path/Record.temp"))
		{
			$This->{Log}->Log ("ERROR writing 'Client/$Info->{uuid}/Record.temp': $!");
			$main::Stop++;
			return 0;
		}
		move ("$Path/Record.temp", "$Path/Record.info");
		Storable::lock_nstore ($Info, "$Path/Record.pds");
	}
	unlink ("$Input/$Entry.info");
	unlink ("$Input/$Entry.data");
	#------------------------------------------------------------------------
	return 1;
}
#------------------------------------------------------------------------------
1;
 