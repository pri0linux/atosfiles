package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/Configure.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use File::Copy;
use Storable;

#------------------------------------------------------------------------------
sub Configure
{
	my ($This) = @_;
	my ($Config, $Instance, $Log, $Var, @Clients, $Handle, @Files, $Count); 
	my ($Uuid, $Path, $Updated, $Time, $F, $File, @Stat, $Data, $Info);
	my ($Packages, @Acl, $Package);
	#----------------------------------------------------------------------
	$Config   = $This->{"Config"};
	$Instance = $This->{"Instance"};
	$Log      = $This->{"Log"};
	$Var      = "/var/Nagios/Node/$Instance";
	#----------------------------------------------------------------------
	@Clients   = ();
	return if (! opendir ($Handle, "$Var/Client"));
	@Clients  = grep { !/\./ } readdir ($Handle);
	closedir ($Handle);
	@Files = ("Config.v3.gz","Checks.v3","Files.pds","Packages.acl","Packages.pds");
	for $Uuid (@Clients)                                            
	{
		next if (! -d "$Var/Client/$Uuid");
		$Path = "$Var/Client/$Uuid";
		#--------------------------------------------------------------
		# Check if the input files are newer than the output file
		#--------------------------------------------------------------
		$Updated = 0;
		$Time    = 0;
		for ($F = 0; $F < 5; $F++)
		{
			$File = "$Path/$Files[$F]"; # 4 files per client
			$File = "$Var/$Files[$F]" if ($F > 3); # 1 main package index
			@Stat = stat ($File);
			$Stat[9] = 1234567890 if ($#Stat < 9);
			$Time = $Stat[9] if (! $F); # first file is reference time
			next if ($Stat[9] <= $Time);
			$Time = $Stat[9];
			$Updated++;
		}
		next if (! $Updated); # first file is up to date
		#--------------------------------------------------------------
		# Config.v3.tgz = Checks.v3 + Files.pds + Packages.pds
		#--------------------------------------------------------------
		$Log->Log ("Updating $Path/Config.v3");
		$Data = "";
		if (open ($Handle, "$Path/Checks.v3"))
		{
			$Data = do { local $/ = <$Handle> };
			close ($Handle);
		}
		$Info = undef;
		eval {$Info = Storable::lock_retrieve("$Path/Files.pds");};
		if (ref($Info) eq "HASH")
		{
			foreach $File (sort keys %$Info)
			{
				# file|<name>|<size>|<time>|<sha1>
				$Data .= join("|","file",$File,@{$Info->{$File}})."\n";
			}
		}
		$Packages = undef;
		eval {$Packages = Storable::lock_retrieve("$Var/Packages.pds");};
		if (ref($Packages) eq "HASH")
		{
			if (open ($Handle, "$Path/Packages.acl"))
			{
				@Acl = <$Handle>;
				close ($Handle);
				foreach $Package (@Acl)
				{
					$Package =~ s/^\s+//;
					$Package =~ s/\s+$//;
					next if (! exists $Packages->{$Package});
					$Data .= join("|","package",$Package,@{$Packages->{$Package}})."\n";
				}
			}
		}
		$Data .= "[eof]\n";
		if (open ($Handle, ">$Path/Config.v3.tmp"))
		{
			print $Handle $Data;
			close ($Handle);
			utime ($Time, $Time, "$Path/Config.v3.tmp");
			move ("$Path/Config.v3.tmp", "$Path/Config.v3");
		}
		$Data = Compress::Zlib::memGzip ($Data);
		if (open ($Handle, ">$Path/Config.v3.gz.tmp"))
		{
			print $Handle $Data;
			close ($Handle);
			utime ($Time, $Time, "$Path/Config.v3.gz.tmp");
			move ("$Path/Config.v3.gz.tmp", "$Path/Config.v3.gz");
		}
	}
	#----------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
 