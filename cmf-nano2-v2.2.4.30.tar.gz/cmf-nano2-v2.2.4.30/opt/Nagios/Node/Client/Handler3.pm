package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/Handler3.pm 
#------------------------------------------------------------------------------
use strict;
use warnings;

use Compress::Zlib;

#------------------------------------------------------------------------------
sub Handler3
{
	my ($This, $Info, $Entry) = @_;
	my ($Path, $Gzip, $Data, $Read, @Data, $Tags, $Time, $Host);
	my ($Line, @Line, $Module, $Record);
	#------------------------------------------------------------------------
	$Path = "/var/Nagios/Node/$This->{Instance}/Client";
	if (! ($Gzip = gzopen("$Path/.Input/$Entry.data", "rb")))
	{
		$This->{Log}->Log ("ERROR reading 'Client/.Input/$Entry.data': $!");
		return;
	}
	$Data = "";
	while ($Gzip->gzread($Read)) { $Data .= $Read; }
	$Gzip->gzclose();
	@Data = split (/\n/, $Data);
    $Data = { head => {}, body => undef };
    $Tags = {};
	#------------------------------------------------------------------------
	$Time = int ($Info->{time});
	$Host = $Info->{uuid};
	while (defined ($Line = shift @Data))
	{
		$Line =~ s/^\s+//; $Line =~ s/\s+$//;
		if (! defined $Data->{body})
		{
			@Line = split (/=/, $Line, 2);
			if ($#Line != 1) { $Data->{body} = []; }
			else { $Data->{head}{$Line[0]} = $Line[1]; }
		}
		else 
		{ 
			if ($Line =~ /^tag./i)
			{
				$Line =~ s/^tag.//i;
				@Line = split (/=/, $Line, 2);
				next if ($#Line != 1);
				$Tags->{lc $Line[0]} = $Line[1];
				next;
			}
			if ($Line !~ /^\d{10}\|/) {
				next if ($Line !~ /^[a-z]+\|/i);
				@Line = split (/\|/, $Line, 2);
				$Module = lc ($Line[0]);
				$Record = "";
				while ($#Data >= 0) {
					last if ($Data[0] =~ /^\s*$/);
					$Record .= shift(@Data)."\n";
				}
				if (($Module eq "nmon") || ($Module eq "njmon"))  { 
					$This->Nmon ($Info, $Line, $Record); 
				}
				if ($Module eq "upload") { 
					$This->Upload ($Info, $Line, $Record); 
				}
				next;
			}
			@Line = split (/\|/, $Line, 4);
			next if ($#Line < 3);
			$Line[0] = $Time if ($Line[0] > $Time); # Future timestamps not allowed
			$Line = "\[$Line[0]\] PROCESS_SERVICE_CHECK_RESULT;$Host;$Line[1];$Line[2];$Line[3]";
			push (@{$Data->{body}}, $Line);
		}
	}
	if (exists $Data->{head}{"system.time"})
	{
		$Info->{skew} = sprintf ("%.3f", $Data->{head}{"system.time"} - $Info->{time});
	}
	$Data->{body} = [] if (! defined $Data->{body});
    $Line = "[$Time] PROCESS_HOST_CHECK_RESULT;$Host;0;$Info->{agent}|age=0s";
    unshift (@{$Data->{body}}, $Line);
	#------------------------------------------------------------------------
    Storable::lock_nstore ($Data->{head}, "$Path/$Host/System.pds");
    Storable::lock_nstore ($Tags, "$Path/$Host/Tags.pds");
    $This->CoreCommand (@{$Data->{body}});
	#------------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
 