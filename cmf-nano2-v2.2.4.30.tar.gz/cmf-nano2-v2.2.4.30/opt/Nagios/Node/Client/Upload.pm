package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/Upload.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use File::Path;
use MIME::Base64;
#------------------------------------------------------------------------------
sub Upload
{
	my ($This, $Info, $Header, $Record) = @_;
	my (@Header, $Path, $File, $Handle, $Size);
	#------------------------------------------------------------------------
    @Header = split (/\|/, $Header);
    return if ($#Header != 2);
    return if ($Header[2] !~ /^\d+$/);
	$Path = "/var/Nagios/Node/$This->{Instance}/Upload";
	eval { mkpath ($Path); chmod (0750, $Path); } if (! -d $Path);
	return if (! -d $Path);
	$File = sprintf ("%s_%s", $Info->{uuid}, $Header[1]);
	return if (! open ($Handle, ">$Path/_$File"));
	binmode ($Handle, ":bytes");
	print $Handle decode_base64($Record);
	close ($Handle);
	$Size = -s "$Path/_$File";
	if ($Size != $Header[2]) {
        if ($Size > $Header[2]) {
            truncate ("$Path/_$File", $Header[2]);
        }
        elsif ($Size < $Header[2]) {
            $This->{Log}->Log ("  Discarding incomplete file: upload/$File");
            unlink ("$Path/_$File");
            return;
        }
	}
	rename ("$Path/_$File", "$Path/$File");
    $This->{Log}->Log ("  Forwarding transfered file: upload/$File");
	#------------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
 