package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/Register.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Register
{
	my ($This, $Info) = @_;
	my ($Time, $Names, @Stat, $Handle);
	#----------------------------------------------------------------------
	$Time  = time();
	$Names = "/var/Nagios/Node/$This->{Instance}/Client/.Names";
	@Stat  = stat ("$Names/$Info->{name}");
	if ($#Stat > 9)
	{
		if (($Time - $Stat[9]) < 600)
		{
			$This->{Log}->Log ("    $Info->{name} recently registered");
			$Info->{error} = "$Info->{name} recently registered: wait at least 10 minutes before trying again";
			utime ($Time, $Time, "$Names/$Info->{name}");
			return 0;
		}
	}
	chomp ($Info->{uuid} = `uuidgen 2>/dev/null`);
	if (length ($Info->{uuid}) != 36)
	{
		$This->{Log}->Log ("ERROR generating a uuid with 'uuidgen'");
		$main::Stop++;
		return 0;
	}
	if (! open ($Handle, ">$Names/$Info->{name}"))
	{
		$This->{Log}->Log ("ERROR writing 'Client/.Names/$Info->{name}': $!");
		$main::Stop++;
		return 0;
	}
	print $Handle $Info->{uuid};
	close ($Handle);
	$This->{Log}->Log ("    Registered $Info->{uuid}");
	#----------------------------------------------------------------------
	return 1;
}
#------------------------------------------------------------------------------
1;
 