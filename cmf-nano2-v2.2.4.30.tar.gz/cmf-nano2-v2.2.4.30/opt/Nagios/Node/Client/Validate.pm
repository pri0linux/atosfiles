package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/Validate.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use File::Path;
#------------------------------------------------------------------------------
sub Validate
{
	my ($This, $Info) = @_;
	my ($Agent, @Agent, @Version, $Path);
	#----------------------------------------------------------------------
	$This->{Log}->Log ($Info->{agent});
	$Agent = $Info->{agent}; $Agent =~ s/[\)\s]+$//;
	@Agent = split (/[\/\s\(\)]+/, $Agent);
	push (@Agent, "") while ($#Agent < 3);
	$Info->{name}    = "";
	$Info->{uuid}    = "";
	$Info->{version} = (0, 0, 0, 0);
	$Info->{valid}   = 0;
	return 0 if ($Agent[0] ne "NaCl");
	
	@Version = split (/\./, $Agent[1], 4);
	push (@Version, 0) while ($#Version < 3);
	$Version[4] = $Version[3];
	$Version[4] =~ s/^\d*\-*//;
	$Version[3] =~ s/\D.*$//;

	$Info->{version} = \@Version;
	$Info->{name}    = $Agent[2];
	$Info->{uuid}    = "";
	return 0 if (! $This->UuidIsValid ($Agent[3]));
	$Info->{uuid}  = $Agent[3];
	$Info->{valid} = 1;
	
	$Path = "/var/Nagios/Node/$This->{Instance}/Client/".$Agent[3];
	mkpath ($Path) if (! -d $Path);
	chmod (02770, $Path);
	
	#----------------------------------------------------------------------
	return 1;
}
#------------------------------------------------------------------------------
1;
 