package Nagios::Node::Client;
#------------------------------------------------------------------------------
# Nagios/Node/Client/Cleanup.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use File::Path;

use Nagios::Node::Receive::Files::Install; # To move files to the new location
#------------------------------------------------------------------------------
sub Cleanup
{
	my ($This, @Path) = @_;
	my ($Path, $Handle, @Uuid, $Uuid, $Src, $Dst);
	my ($Limit, @Files, $Entry, @Entry);
	#----------------------------------------------------------------------
	# Move client files from the old location to the new location
	#----------------------------------------------------------------------
	$Path = "/var/Nagios/Node/$This->{Instance}";
	if (opendir ($Handle, "$Path/Clients"))
	{
		@Uuid = grep { /^[^\.]/ } readdir ($Handle);
		closedir ($Handle);
		foreach $Uuid (@Uuid)
		{
			$Src = "$Path/Clients/$Uuid";
			$Dst = "$Path/Client/$Uuid";
			next if (! opendir ($Handle, "$Src/Files"));
			@Files = grep { /^[^\.]/ } readdir ($Handle);
			closedir ($Handle);
			next if (! scalar @Files);
			$This->{Log}->Log ("Moving 'Clients/$Uuid/Files'","    to 'Client/$Uuid/Files'");
			mkpath ($Dst) if (! -d $Dst);
			chmod (02770, $Dst);
			Nagios::Node::Receive::Files_Install ($This, $Src, $Dst);
		}
		rmtree ("$Path/Clients");
	}
	#----------------------------------------------------------------------
	# Cleanup all expired input and output files
	#----------------------------------------------------------------------
	$Limit = time();
	foreach $Path (@Path)
	{
		$Limit -= 20; # Input after 20, output after 40 seconds ...
		if (! opendir ($Handle, $Path))
		{
			$This->{Log}->Log ("ERROR reading '$Path': $!");
			next;
		}
		@Files = sort grep { /^\d{10}\./ } readdir ($Handle);
		closedir ($Handle);
		foreach $Entry (@Files)
		{
			@Entry = split (/\./, $Entry);
			if ($Entry[0] < $Limit) { unlink ("$Path/$Entry"); }
		}
	}
	#----------------------------------------------------------------------
	return;
}
#------------------------------------------------------------------------------
1;
 