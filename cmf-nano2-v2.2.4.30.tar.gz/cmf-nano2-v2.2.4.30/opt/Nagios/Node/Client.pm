package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Client.pm
#------------------------------------------------------------------------------
@Nagios::Node::Client::ISA = ("Nagios::Node");

use strict;
use warnings;

use File::Path;
use Time::HiRes;
 
use Nagios::Node::Client::Cleanup;
use Nagios::Node::Client::Configure;
use Nagios::Node::Client::Handler;
use Nagios::Node::Client::Heartbeat;

use Tmdx::Lock;
use Tmdx::Log;
#------------------------------------------------------------------------------
sub Client
{
	my ($This, $Command) = @_;
	my ($Config, $Instance, $Var, $Lock, $Log, $Input, $Output, $Entry);
	my (@Input, $Cleanup, $Configure, $Time, $Limit, @Entry, $Handle);
	#----------------------------------------------------------------------
    # die ("") if ($#ARGV < 1); # Interactive only !!!
	#----------------------------------------------------------------------
	$This->{"Lock"} = undef;
	$This->{"Log"}  = undef;
	bless ($This, "Nagios::Node::Client");

	$Config   = $This->{"Config"};
	$Instance = $This->{"Instance"};
	$Var      = "/var/Nagios/Node/$Instance";

	$This->{Debug} = $Config->{"debug"} || $Config->{"debug.client"};
	
	$Lock     = Tmdx::Lock->new ("$Var/Client.pid");
	die ($Lock->Error()."\n") if (defined $Lock->Error());
	if (! $Lock->Lock()) 
	{ 
		die ($Lock->Error()."\n") if (defined $Lock->Error());
		die "The Nagios Node Client process is already active ...\n";
	}
	$This->{"Lock"} = $Lock;

	$0 = $Command."->Client()";
	$Log = Tmdx::Log->new ("$Var/log", "Client.log", undef, undef, 1);
	$Log->Log ("------------------------------------------------------------------------------",
	           "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
	$This->{"Log"} = $Log;
	#----------------------------------------------------------------------
	# Initialize our working directories ...
	#----------------------------------------------------------------------
	$Input = "$Var/Client/.Input";
	eval { mkpath ($Input); } if (! -d $Input); 
	chmod (02770, $Input);
	$Output = "$Var/Client/.Output";
	eval { mkpath ($Output); } if (! -d $Output); 
	chmod (0770, $Output);
	$Entry = "$Var/Client/.Names";
	eval { mkpath ($Entry); } if (! -d $Entry); 
	chmod (0750, $Entry);
	#----------------------------------------------------------------------
	# Start processing until the end of time ...
	#----------------------------------------------------------------------
	@Input     = ();
	$Cleanup   = 0;
	$Configure = 0;
	while (! $main::Stop)
	{
		$Time  = time();
		#--------------------------------------------------------------
		# Cleanup all expired input and output files
		#--------------------------------------------------------------
		if ($Cleanup <= $Time)
		{
			$This->Cleanup ($Input, $Output);
			$Cleanup = $Time + 10;
		}
		#--------------------------------------------------------------
		# Check for updated client configurations
		#--------------------------------------------------------------
		if ($Configure <= $Time)
		{
			$This->Configure();
			$Configure = $Time + 9;
		}
		#--------------------------------------------------------------
		# Process the previously loaded list of input files
		#--------------------------------------------------------------
		$Limit = $Time - 15;
		if ($Entry = shift (@Input))
		{
			@Entry = split (/\./, $Entry);
			if ($Entry[0] >= $Limit) 
			{
				$This->Handler ($Entry);
				$This->Heartbeat();
			}
			else { unlink ("$Input/$Entry"); }
			next;
		}
		#--------------------------------------------------------------
		# Load the list of input files to be processed
		#--------------------------------------------------------------
		if (! opendir ($Handle, $Input))
		{
			$Log->Log ("ERROR reading '$Input': $!");
			last;
		}
		@Input = sort grep { /^\d{10}\..*\.info$/ } readdir ($Handle);
		closedir ($Handle);
		if ($#Input < 0) { $This->Heartbeat(); sleep (1); }
		#--------------------------------------------------------------
	}
	#----------------------------------------------------------------------
	return 0;
}
#------------------------------------------------------------------------------
1;
 