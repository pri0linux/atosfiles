package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Rsync.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Rsync
{
  my ($Node, $Command) = @_;
  my ($Instance, $Log, $Rsync, $Options, $From, $To, @Exclude, $Exclude);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->Rsync();") if (ref($Node) !~ /^Nagios::Node/);

  return 0 if ($Node->{'Config'}{'failover'} eq ""); # rsync not needed
  $Instance = $Node->{"Instance"};
  if (defined $Command)
  {
    $0 = $Command."->Rsync()";
    $Log = Tmdx::Log->new ("/var/Nagios/Node/$Instance/log", "Rsync.log", undef, undef, 1);
    $Log->Log ("------------------------------------------------------------------------------",
               "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
    $Node->{"Log"} = $Log;
  }
  else { $Log = $Node->{"Log"}; }

  #------------------------------------------------------------------------

  $Rsync = `which rsync 2>/dev/null`;
  chomp $Rsync;
  if ($Rsync =~ /^\s*$/)
  {
    $Log->Log ("ERROR: 'rsync' not available !!!") if (defined $Log);
    if (! defined $Command) { print STDERR "ERROR: 'rsync' not available !!!\n"; }
    return 1;
  }

  #------------------------------------------------------------------------

  if (defined $Command) # sync to failover node
  {
    $Options = "-avze ssh";
    $From    = "/var/Nagios/Node/$Instance";
    $To      = $Node->{'Config'}{'failover'}.":/var/Nagios/Node/$Instance.rsync";
  }
  else # Get the newest version of all files
  {
    $Options = " -avu";
    $From    = "/var/Nagios/Node/$Instance.rsync";
    $To      = "/var/Nagios/Node/$Instance";
  }

  @Exclude = ("log", "nagios.log", "Notify.log", "rw", "tmdx/log", "tmp", "*.pid");
  foreach $Exclude (@Exclude) { $Rsync .= " --exclude='$Exclude'"; }
  $Rsync .= " --delete --timeout=5 $Options $From/ $To";

  #------------------------------------------------------------------------

  $Log->Log ($Rsync) if (defined $Log);
  if (! defined $Command) { print STDERR "$Rsync\n"; }
  $Log->Log (`$Rsync 2>&1`);

  #------------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
