package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Notify.pm
#------------------------------------------------------------------------------
use strict;
use warnings;

use Compress::Zlib;
use Data::Dumper;
use File::Path;
use Storable;

use Tmdx::Client::Transmit;
use Nagios::Node::Notify::Flood;

#------------------------------------------------------------------------------
sub Notify
{
  my ($Notify, @Options) = @_;
  my ($Config, $Instance, $Tmdx, $Var, @Log, $Log, $Option, $Name, $Value);
  my ($Data, $Tags, @Event, $Tag, $e, @Path, $p);
  my ($Id, $Uuid, $Hostname, $Subject, $Message, $Severity, $State);
  my ($File, $Maintenance, $Line, @Value);
  my ($Errors, %Info, @Force, $Event, $Force, $Pdx);
  #--------------------------------------------------------------------
  # Initialize
  #--------------------------------------------------------------------
  die ("Usage: Nagios::Node->Notify();") if (ref($Notify) ne "Nagios::Node");
  die ($Notify->{"Error"}) if ($Notify->{"Error"});
  bless ($Notify, "Nagios::Node::Notify");
  
  $Config   = $Notify->{"Config"};
  $Instance = $Notify->{"Instance"};
  $Tmdx     = $Notify->{"Tmdx"};
  $Var      = "/var/Nagios/Node/$Instance";
  @Log      = (); # Lines to be logged if log is enabled.
  $Log = Tmdx::Log->new ("$Var/log", "Notify.log", undef, undef, 1);
  if ( ($ENV{NAGIOS_SERVICESTATE}//'') eq '' )
  {
  	$State = $ENV{NAGIOS_HOSTSTATE};
  }
  else 
  {
  	$State = $ENV{NAGIOS_SERVICESTATE};
  }
  $Log->Log ("Processing $State notification for host ".($ENV{NAGIOS_HOSTDISPLAYNAME}//"")." (".($ENV{NAGIOS_HOSTNAME}//"").
  			 "), service ".($ENV{NAGIOS_SERVICEDISPLAYNAME}//"")." (".($ENV{NAGIOS_SERVICEDESC}//"").")");
  $Notify->{"Log"} = $Log;

  shift @Options;
  foreach $Option (@Options) 
  {
    if ($Option !~ /=/)
    {
      if    ($Option =~ /^log$/)  { $Config->{'notify.log'}  = 1; }
    }
    else
    {
      ($Name, $Value) = split (/\s*=\s*/, $Option, 2);
      $Name = lc($Name);
      next if ($Value eq "");
      if    ($Name eq "log")  { $Config->{'notify.log'}  = int($Value); }
      if    ($Name eq "mode") { $Config->{'notify.mode'} = int($Value); }
      elsif ($Name eq "tmdx") { $Config->{'notify.tmdx'} = lc($Value);  }
    }
  }
  $Config->{'notify.maintenance'} = "" if (! exists  $Config->{'notify.maintenance'});
  $Config->{'notify.maintenance'} = "" if (! defined $Config->{'notify.maintenance'});
  push (@Log, "Maintenance config: ".$Config->{'notify.maintenance'});
  #--------------------------------------------------------------------
  # Collect the notification parameters
  #--------------------------------------------------------------------
  $Data  = {};
  $Tags  = { "host" => {}, "service" => {}, "contact" => {} };
  @Event = ();
  foreach $Name (sort keys %ENV)
  {
    $Value = $ENV{$Name};
    next if ($Name !~ /^NAGIOS_/);
    $Name =~ s/^NAGIOS_//;

    next if ($Name =~ /^ADMIN|^COMMA|^LOGFI|^MAINC|^OBJEC/);
    next if ($Name =~ /^PROCE|^RETEN|^STATU|^TEMP.|^TOTAL/);
    next if ($Name =~ /PERFDATAFILE$/);

    $Name = lc ($Name);
    ($Value) = split (/\n/, "$Value");
    $Value =~ s/\s+$//;
    next if ($Value eq "");
    if ($Name =~ /^_.+tag_.+$/)
    {
      ($Tag, $Name) = ($Name =~ /^_(.+)tag_(.+)$/);
      next if ((! defined $Tag) || (! defined $Name));
      next if (! exists $Tags->{$Tag});
      $Tags->{$Tag}{$Name} = $Value;
      next;
    }
    $Data->{"nagios.$Name"} = $Value;
    next if ($Name !~ /^contact/);
    $Name =~ s/^contact//;
    if    ($Name eq "email")       { push (@Event, "email:".$Value); }
    elsif ($Name eq "pager")       { push (@Event, "sms:".$Value); }
    elsif ($Name =~ /^address\d$/) { push (@Event, $Value); }
  }
  #--------------------------------------------------------------------
  # Merge the collected tags into the data
  #--------------------------------------------------------------------
  $Tags->{tag} = {};
  foreach $Tag (keys %{$Tags->{host}})    { $Tags->{tag}{$Tag} = $Tags->{host}{$Tag};        }
  foreach $Tag (keys %{$Tags->{service}}) { $Tags->{tag}{$Tag} = $Tags->{service}{$Tag};     }
  foreach $Tag (keys %{$Tags->{contact}}) { $Tags->{tag}{$Tag} = $Tags->{contact}{$Tag};     }
  foreach $Tag (keys %{$Tags->{tag}})     { $Data->{"nagios.tag.$Tag"} = $Tags->{tag}{$Tag}; }
  #--------------------------------------------------------------------
  # Process event macros and merge results
  #--------------------------------------------------------------------
  for ($e = 0; $e <= $#Event; $e++)
  {
    @Path = split (/[\:\!\|]/, $Event[$e]);
    for ($p = 0; $p <= $#Path; $p++)
    {
      foreach $Tag (keys %{$Tags->{tag}})
      {
        $Name  = "#$Tag#";
        $Value = $Tags->{tag}{$Tag};
        $Path[$p] =~ s/$Name/$Value/gi;
      }
    }
    $Event[$e] = join ("|", @Path);
    $Data->{"nagios.notify.event.$e"} = $Event[$e];
  }
  #--------------------------------------------------------------------
  # Determine the notification information
  #--------------------------------------------------------------------
  $Uuid     = { client => undef, host => undef, service => undef };
  $Hostname = "UNKNOWN";
  $Subject  = "UNKNOWN";
  $Message  = "unknown";
  $Severity = "5";
  $Id       = "0";

  $Uuid->{client} = $Data->{"nagios._hostclient"} if (exists $Data->{"nagios._hostclient"}); 

  $Hostname = $Data->{"nagios.hostdisplayname"} if (exists $Data->{"nagios.hostdisplayname"});

  if (exists $Data->{"nagios.hoststateid"})    
  { 
    $Subject  = "";
    $Subject  = $Data->{"nagios.hoststate"}.": $Hostname" if (exists $Data->{"nagios.hoststate"});

    $Message  = "";
    $Message  = $Data->{"nagios.hostoutput"} if (exists $Data->{"nagios.hostoutput"});

    $Severity = "4";
    $Severity = "3" if ($Data->{"nagios.hoststateid"} > 0);
    $Severity = "2" if ($Data->{"nagios.hoststateid"} > 1);

    $Id = $Data->{"nagios.hostnotificationid"} if (exists $Data->{"nagios.hostnotificationid"});

    $Uuid->{host}   = $Data->{"nagios.hostname"} if (exists $Data->{"nagios.hostname"});
    $Uuid->{client} = $Uuid->{host} if (! defined $Uuid->{client}); # for backward compatibility
  }

  if (exists $Data->{"nagios.servicestateid"}) 
  { 
    $Subject  = "";
    $Subject  = $Data->{"nagios.servicestate"}.": " if (exists $Data->{"nagios.servicestate"});
    $Subject .= "$Hostname ";
    $Subject .= $Data->{"nagios.servicedisplayname"} if (exists $Data->{"nagios.servicedisplayname"});

    $Message  = "";
    $Message  = $Data->{"nagios.serviceoutput"} if (exists $Data->{"nagios.serviceoutput"});

    $Severity = "4";
    $Severity = "3" if ($Data->{"nagios.servicestateid"} > 0);
    $Severity = "2" if ($Data->{"nagios.servicestateid"} > 1);

    $Id = $Data->{"nagios.servicenotificationid"} if (exists $Data->{"nagios.servicenotificationid"});

    $Uuid->{service} = $Data->{"nagios.servicedesc"} if (exists $Data->{"nagios.servicedesc"});
  }

  $Data->{"nagios.notify.hostname"} = $Hostname;
  $Data->{"nagios.notify.subject"}  = $Subject;
  $Data->{"nagios.notify.message"}  = $Message;
  $Data->{"nagios.notify.severity"} = $Severity;
  $Data->{"nagios.notify.id"}       = $Id;

  #--------------------------------------------------------------------
  # Flood suppression
  #--------------------------------------------------------------------
  if ( ( $State ne 'OK' ) && ( $State ne 'UP' ) ) #non-ok notification
  {
    $Notify->Flood_Table_Initialize();
    $Notify->Flood_Load_Config();
    $Notify->Flood_Add_Notification($Data);
    $Notify->Flood_Update();
    my $flood_result = $Notify->Flood_Is_Flood($Data);
    $Notify->Flood_Table_Close();
    if ( $flood_result ) {
    	$Log->Log('    Flood detected:');
    }
    $Log->Log($Notify->{'Notify.flood_message'});
    if ( $Notify->Flood_Supress($Data) ) {
    	$Log->Log(' NOTIFICATION SUPPRESSED');
    	return 2;
    }
    else
    {
    	$Log->Log(' NOTIFICATION NOT SUPPRESSED');
    }
  }
  #--------------------------------------------------------------------
  # Check if maintenance mode is active
  #--------------------------------------------------------------------
  $Maintenance = {};
  $Data->{"nagios.notify.maintenance"} = "0";
  if (defined $Uuid->{client})
  {
    $File = sprintf ("%s/Client/%s/Maintenance.dat", $Var, $Uuid->{client});
    if (open (MAINTENANCE, $File))
    {
      foreach $Line (<MAINTENANCE>)
      {
        $Line =~ s/\s+$//;
        ($Name, $Value) = split (/\s*=\s*/, $Line, 2);
        next if ((! defined $Name) || (! defined $Value));
        @Value = split (/\s*;\s*/, $Value, 4);
        next if (! defined $Value[2]);
        next if (int($Value[2]) <= time()); # expired
        $Name = "client" if ($Name =~ /client/i);
        $Maintenance->{$Name} = $Value;
      }
      close (MAINTENANCE);

      if (exists $Maintenance->{client})
      {
        $Data->{"nagios.notify.maintenance"} = $Maintenance->{client};
      }
      elsif (exists $Maintenance->{$Uuid->{host}})
      {
        $Data->{"nagios.notify.maintenance"} = $Maintenance->{$Uuid->{host}};
      }
      elsif (exists $Maintenance->{$Uuid->{service}})
      {
        $Data->{"nagios.notify.maintenance"} = $Maintenance->{$Uuid->{service}};
      }
    }
  }
  push (@Log, "Maintenance mode:   ".$Data->{"nagios.notify.maintenance"});
  #--------------------------------------------------------------------
  # Send the notification to Nagios Headquarters
  #--------------------------------------------------------------------
  $Errors = 0;
  %Info   = ();
  $Info{'to'}    = $Config->{'nahq'};
  $Info{'event'} = "nano.notify";
  $Info{'ttl'}   = 86400;
  $Message = "nano.notify\n\nnotify {\n"; 
  foreach $Name (sort keys %$Data) 
  { 
    $Message .= "\t$Name=$Data->{$Name}\n";
  }
  $Message .= "\t}\n[eof]\n"; 
  $Tmdx->Transmit (\%Info, $Message);
  if (defined $Tmdx->Error())
  {
    push (@Log, "TMDX Client error:  ".$Tmdx->Error());
    $Errors++;
  }
  #--------------------------------------------------------------------
  # Built the notification event for the TMDX Gateway
  #--------------------------------------------------------------------
  %Info             = ();
  $Info{'source'}   = "notify:".$Data->{"nagios.notify.id"};
  $Info{'to'}       = $Config->{'notify.tmdx'};
  $Info{'ttl'}      = 3600;
  $Info{'subject'}  = $Data->{"nagios.notify.subject"};
  #--------------------------------------------------------------------
  if ($Config->{'notify.mode'} < 2) # Adjust notification for mode 1
  #--------------------------------------------------------------------
  {
    $Info{'mode'}     = 1;
    $Info{'hostname'} = $Data->{"nagios.notify.hostname"};
    $Info{'severity'} = $Data->{"nagios.notify.severity"};
    $Message = $Data->{"nagios.notify.message"};
  }
  #--------------------------------------------------------------------
  else # Adjust the notification event for mode 2
  #--------------------------------------------------------------------
  {
    $Info{'mode'} = 2;
    $Message = "";
    foreach $Name (sort keys %$Data) 
    { 
      $Message .= "$Name=$Data->{$Name}\n";
    }
    $Message .= "hostname=".$Data->{"nagios.notify.hostname"}."\n";
    $Message .= "severity=".$Data->{"nagios.notify.severity"}."\n";
    foreach $Name (keys %{$Tags->{tag}})
    {
      $Message .= "$Name=$Tags->{tag}{$Name}\n";
    }
    $Message .= "\n";
    $Message .= $Data->{"nagios.notify.message"};
  }
  #--------------------------------------------------------------------
  # Send the notification events to the TMDX Gateway
  #--------------------------------------------------------------------
  @Force = split (/[\s;]+/,lc($Config->{'notify.maintenance'}));
  foreach $Event (@Event) 
  { 
    if ($Data->{"nagios.notify.maintenance"} ne "0")
    {
      ($e) = split (/\|/, lc($Event), 2);
      $Force = 0;
      foreach (@Force) { $Force++ if ($_ eq $e); }
      if (($State eq 'OK') || ($State eq 'UP')) {
        push (@Log, "Okay notification:  $Event");
      }
      elsif (! $Force)
      {
        push (@Log, "Drop notification:  $Event");
        next;
      }
      else {
        push (@Log, "Force notification: $Event");
      }
    }
    else
    {
      push (@Log, "Send notification:  $Event");
    }
    $Info{'event'} = $Event;
    $Tmdx->Transmit (\%Info, $Message);
    if (defined $Tmdx->Error())
    {
      push (@Log, "TMDX Client error:  ".$Tmdx->Error());
      $Errors++;
    }
  }
  #--------------------------------------------------------------------
  # Store the event in PDX format
  #--------------------------------------------------------------------
  if (! -d "$Var/Notify") { mkpath ("$Var/Notify"); }
  $File = sprintf ("%s/Notify/%08d.pdx", $Var, $Data->{"nagios.notify.id"});
  $Pdx  = Compress::Zlib::memGzip (Storable::nfreeze ($Data));
  eval { Storable::lock_nstore (\$Pdx, $File); };
  #--------------------------------------------------------------------
  # Log the event in DUMP format
  #--------------------------------------------------------------------
  if ($Config->{'notify.log'})
  {
    $Data::Dumper::Sortkeys = 1;
    if (! -d "$Var/Notify.log") { mkpath ("$Var/Notify.log"); }
    $File = sprintf ("%s/Notify.log/%d-%d.log", $Var, time(), $Data->{"nagios.notify.id"});
    if (open (LOG, ">$File"))
    {
      print LOG Data::Dumper->Dump ([$Data,$Tags,$Maintenance,\@Log],["Data","Tags","Maintenance","Log"]);
      close LOG;
    }
  }
  #--------------------------------------------------------------------
  return ( $Errors ? 1 : 0 );
}
#------------------------------------------------------------------------------
1;
 
