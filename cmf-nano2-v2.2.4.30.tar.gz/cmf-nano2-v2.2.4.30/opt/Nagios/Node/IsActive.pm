package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/IsActive.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub IsActive
{
  my ($Node) = @_;
  my ($Config, $Method, $Params, $Module, $Eval, $Active);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->IsActive();") if (ref($Node) !~ /^Nagios::Node/);

  $Config = $Node->{"Config"};
  return 1 if ($Config->{'failover'} eq "");
  return 0 if ($Config->{'isactive'} eq "");

  ($Method, $Params) = split (/:/, $Config->{'isactive'}, 2);
  $Method = "" if (! defined $Method);
  $Params = "" if (! defined $Params);
  $Module = "/opt/Nagios/Node/Nagios/Node/IsActive/".lc($Method).".pm";
  if (! -r $Module)
  {
    $Node->{"Error"} = "Invalid IsActive handler: '$Module'";
    return 0;
  }
  $Eval  = "require Nagios::Node::IsActive::".lc($Method).";\n";
  $Eval .= "\$Active = \$Node->IsActive_".lc($Method)."(\$Params);\n";
  eval ($Eval);
  if ($@)
  {
    $Node->{"Error"} = $@;
    return 0;
  }
  #------------------------------------------------------------------------
  return $Active?1:0;
}
#------------------------------------------------------------------------------
1;
