package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/Receive.pm
#------------------------------------------------------------------------------
@Nagios::Node::Receive::ISA = ("Nagios::Node");

use strict;
use warnings;

use Nagios::Node::CoreCommand;
use Nagios::Node::Receive::Config::Clients;
use Nagios::Node::Request;
use Nagios::Node::StartNagios;

use Tmdx::Client::Receive;
use Tmdx::Lock;
use Tmdx::Log;
#------------------------------------------------------------------------------
sub Receive
{
  my ($Receive, $Command) = @_;
  my ($Config, $Instance, $Tmdx, $Var, $Lock, $Log, $Serial, $Minute);
  my ($Info, $Data, $Msg, $Event, @Event, $File, $Eval, @Stat);
  #------------------------------------------------------------------------
  # die ("") if ($#ARGV < 1); # Interactive only !!!
  #------------------------------------------------------------------------
  # Initialize, lock & start logging
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->Receive();") if (ref($Receive) ne "Nagios::Node");
  $Receive->{"Lock"} = undef;
  $Receive->{"Log"}  = undef;
  bless ($Receive, "Nagios::Node::Receive");

  $Config   = $Receive->{"Config"};
  $Instance = $Receive->{"Instance"};
  $Tmdx     = $Receive->{"Tmdx"};
  $Var      = "/var/Nagios/Node/$Instance";

  $Lock     = Tmdx::Lock->new ("$Var/Receive.pid");
  die ($Lock->Error()."\n") if (defined $Lock->Error());
  if (! $Lock->Lock()) 
  { 
    die ($Lock->Error()."\n") if (defined $Lock->Error());
    die "The Nagios Node Receive process is already active ...\n";
  }
  $Receive->{"Lock"} = $Lock;

  $0 = $Command."->Receive()";
  $Log = Tmdx::Log->new ("$Var/log", "Receive.log", undef, undef, 1);
  $Log->Log ("------------------------------------------------------------------------------",
             "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
  $Receive->{"Log"} = $Log;
  #------------------------------------------------------------------------
  # Start receiving information until the end of time ...
  #------------------------------------------------------------------------
  $Serial = 0;
  $Minute = 0;
  while (! $main::Stop)
  {
	if ($Minute != int(time()/60))
	{
		$Receive->StartNagios();
		$Minute = int(time()/60);
	}
    $Lock->Touch();
    last if (time() >= $Config->{'endtime'});
    ($Info, $Data) = $Tmdx->Receive();
    last if ($Tmdx->Error());
    if ($Info) 
    {
      $Msg   = "'".$Info->{'event'}."' event from '".$Info->{'from'}."'";
      $Event = lc($Info->{'event'});
      $Event = "nano.notify" if ($Event =~ /^notify[\|\:\!]/);
      @Event = split (/\./, $Event);
      if (($#Event == 1) && ($Event[0] eq "nano"))
      {
        $File = "/opt/Nagios/Node/Nagios/Node/Receive/".ucfirst($Event[1]).".pm";
        if (! -r $File)
        {
          $Log->Log ("  Skipping unknown $Msg.");
          next;
        }
        $Eval  = "require \"$File\";\n";
        $Eval .= "\$Receive->".ucfirst($Event[1])." (\$Info, \$Data);\n";
        eval ($Eval);
        $Log->Log ($@) if ($@);
        next;
      }
      $Log->Log ("  Unknown $Msg.");
    }
    @Stat = stat ("$Var/objects.cache");
    if ($#Stat < 9)              { sleep (1); next; }
    if ($Stat[9] == $Serial)     { sleep (1); next; }
    if ($Stat[9] >= (time()-10)) { sleep (1); next; }
    $Receive->Config_Clients();
    $Serial = $Stat[9];
    sleep (1);
  } 
  $Log->Log ($Tmdx->Error()?$Tmdx->Error():"Done ...");
  $Log->Close();
  $Lock->Unlock();
  #------------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
 