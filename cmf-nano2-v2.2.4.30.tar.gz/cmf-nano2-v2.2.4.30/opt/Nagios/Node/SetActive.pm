package Nagios::Node;
#------------------------------------------------------------------------------
# Nagios/Node/SetActive.pm
#------------------------------------------------------------------------------
use strict;
use warnings;
use POSIX;
#------------------------------------------------------------------------------
sub SetActive
{
  my ($Node, $Other) = @_;
  my ($Instance, $State, $Log, $Delay, $Message, $Time);
  #------------------------------------------------------------------------
  die ("Usage: Nagios::Node->SetActive();") if (ref($Node) !~ /^Nagios::Node/);

  $Instance = $Node->{"Instance"};
  $State    = $Node->{"State"};
  $Log      = $Node->{"Log"};
  return if ($State->{"IsActive"}); # state not changed
  #------------------------------------------------------------------------
  # Check if it is save to become active
  #------------------------------------------------------------------------
  $Delay = time() - $State->{"LastActive"};
  if ($Delay < 300) # Must stay passive for at least 5 minutes ...
  {
    $Message = strftime ("Stuck at PASSIVE until %H:%M:%S UTC !!!\n", gmtime($State->{"LastActive"}+300));
    $Log->Log ($Message);
    print STDERR $Message;
    return;
  }
  $Time = time();
  $Log->Log ("------------------------------------------------------------------------------",
             "$0 v$main::VERSION - Copyright $main::COPYRIGHT");
  $Message = strftime ("Switching to ACTIVE at %H:%M:%S UTC\n", gmtime($Time));
  $Log->Log ($Message);
  print STDERR $Message;

  require Nagios::Node::Rsync;
  $Node->Rsync (undef); # Get the newest version of all files

  $State->{"IsActive"} = 1;
  #------------------------------------------------------------------------
  return;
}
#------------------------------------------------------------------------------
1;
