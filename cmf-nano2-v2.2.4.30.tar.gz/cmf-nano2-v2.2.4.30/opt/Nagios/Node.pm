package Nagios;
#------------------------------------------------------------------------------
# Nagios/Node.pm - Nagios Node
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Basename;

use Nagios::Node::Initialize;
use Nagios::Node::Version;

use Tmdx::Client;
use Tmdx::Fork;
use Tmdx::SetPath;

#------------------------------------------------------------------------------
sub Node
{
  my (@Arg) = @_;
  my ($Node, $Basename, $Instance, $Config, $Tmdx, $State);
  my ($Value, $Link, $Command, $Var, @Value);
  #------------------------------------------------------------------------
  # Initialize the Nagios Node object
  #------------------------------------------------------------------------
  die ("Stop signal \$main::Stop is undefined") if (! defined $main::Stop);
  if ($#Arg < 0)
  {
    require Nagios::Node::Usage;
    return Nagios::Node::Usage(1); 
  }

  $Node = { "Basename" => basename($0),
            "Command"  => $0,
            "Config"   => undef,
            "Error"    => undef,
            "Instance" => undef,
            "Log"      => undef,
            "State"    => undef,
            "Tmdx"     => undef};

  bless ($Node, "Nagios::Node");

  $Node->Initialize(@Arg);

  $Basename = $Node->{"Basename"};
  $Instance = $Node->{"Instance"};
  $Config   = $Node->{"Config"};
  $Tmdx     = $Node->{"Tmdx"};
  $State    = $Node->{"State"};

  #--------------------------------------------------------------------
  # If started as 'Notify.pl' handle the notification
  #--------------------------------------------------------------------
  if ($Basename =~ /Notify/i)
  {
    require Nagios::Node::Notify;
    return $Node->Notify (@Arg);
  }
  #--------------------------------------------------------------------
  # If started as 'CheckNagiosNode.pl' perform the check
  #--------------------------------------------------------------------
  if ($0 =~ /CheckNagiosNode\.pl/)
  {
    require Nagios::Node::Check;
    return $Node->Check (@Arg);
  }
  #--------------------------------------------------------------------
  # If started in the 'normal' way we continue here
  #--------------------------------------------------------------------
  die ($Node->{"Error"}."\n") if ($Node->{"Error"});
  ($Value) = (`uptime` =~ /\s+load\s+.+:\s+(.+)$/i);
  $Config->{'load_average'} = $Value;
  $Command = "Nagios::Node('$Instance')";
  #--------------------------------------------------------------------
  # If this is NOT the active node we only need an rsync
  #--------------------------------------------------------------------
  if (! $State->{"IsActive"})
  {
    print ("This Nagios Node is not active\n");
    if ($#Arg == 0)
    {
      if (Tmdx::Fork()) 
      { 
        require Nagios::Node::Rsync;
        $Node->Rsync($Command);
      }
    }
    return 0;
  }
  #--------------------------------------------------------------------
  # Check directories & modes
  #--------------------------------------------------------------------
  $Var = "/var/Nagios/Node/$Instance";
  Tmdx::SetPath ({
    "$Var"              => "0750",
    "$Var/checkresults" => "0750",
    "$Var/Client"       => "02770", # 02770
    "$Var/Core"         => "0750",
    "$Var/Files"        => "0750",
    "$Var/log"          => "0750",
    "$Var/Nmon"         => "0750",
    "$Var/Notify.log"   => "0750",
    "$Var/Packages"     => "0750",
    "$Var/rw"           => "0770", # 0770
    "$Var/tmdx"         => "0750",
    "$Var/tmp"          => "0750",
    "$Var/Upload"       => "0750",
  });
  #--------------------------------------------------------------------
  # Check the nagios binary and get the version
  #--------------------------------------------------------------------
  die ("  Nagios binary not symlinked\n") if (! -x "/opt/Nagios/Node/nagios");
  @Value = `/opt/Nagios/Node/nagios`;
  while (($#Value >= 0) && (! $Config->{'nagios'}))
  { 
    $Config->{'nagios'} = shift @Value; 
    chomp $Config->{'nagios'}; 
  }
  #--------------------------------------------------------------------
  # If started with an additional argument ...
  #--------------------------------------------------------------------
  if ($#Arg > 0)
  {
    #----------------------------------------------------------
    # BATCH
    #----------------------------------------------------------
    if ($Arg[1] =~ /^b/i)
    { 
      require Nagios::Node::Batch;  
      return $Node->Batch ($Command, @Arg); 
    }
    #----------------------------------------------------------
    # CHECKS
    #----------------------------------------------------------
    if ($Arg[1] =~ /^ch/i)
    { 
      require Nagios::Node::Checks;  
      return $Node->Checks ($Command, @Arg); 
    }
    #----------------------------------------------------------
    # CLIENT
    #----------------------------------------------------------
    if ($Arg[1] =~ /^cl/i)
    { 
      require Nagios::Node::Client;  
      return $Node->Client ($Command, @Arg); 
    }
    #----------------------------------------------------------
    # CORE
    #----------------------------------------------------------
    if ($Arg[1] =~ /^co/i)
    { 
      require Nagios::Node::Core;  
      return $Node->Core ($Command, @Arg); 
    }
    #----------------------------------------------------------
    # DEBUG
    #----------------------------------------------------------
    if ($Arg[1] =~ /^d/i)
    { 
      require Nagios::Node::Debug;  
      return $Node->Debug ($Command, @Arg); 
    }
    #----------------------------------------------------------
    # GET
    #----------------------------------------------------------
    if ($Arg[1] =~ /^g/i)
    { 
      require Tmdx::Client::Get; 
      $Tmdx->Get($Command); 
      return 0;
    }
    #----------------------------------------------------------
    # NMON
    #----------------------------------------------------------
    if ($Arg[1] =~ /^n/i)
    {
      require Nagios::Node::Nmon;  
      return $Node->Nmon ($Command, @Arg); 
    }
    #----------------------------------------------------------
    # POST
    #----------------------------------------------------------
    if ($Arg[1] =~ /^p/i)
    {
      require Tmdx::Client::Post; 
      $Tmdx->Post($Command); 
      return 0;  
    }
    #----------------------------------------------------------
    # RECEIVE (needs both Get & Post to be active)
    #----------------------------------------------------------
    if (($Arg[1] =~ /^rx?$/i) || ($Arg[1] =~ /^re/i))
    { 
      if (Tmdx::Fork()) 
      { 
        require Tmdx::Client::Get; 
        $Tmdx->Get($Command); 
        return 0;
      }
      if (Tmdx::Fork()) 
      { 
        require Tmdx::Client::Post; 
        $Tmdx->Post($Command); 
        return 0;  
      }
      require Nagios::Node::Receive;  
      return $Node->Receive($Command); 
    }
    #----------------------------------------------------------
    # RSYNC
    #----------------------------------------------------------
    if ($Arg[1] =~ /^rs/i)
    { 
      require Nagios::Node::Rsync;  
      return $Node->Rsync($Command);; 
    }
    #----------------------------------------------------------
    # STATUS
    #----------------------------------------------------------
    if ($Arg[1] =~ /^sta/i)
    { 
      require Nagios::Node::Status;  
      return $Node->Status (@Arg); 
    }
    #----------------------------------------------------------
    # STOP
    #----------------------------------------------------------
    if ($Arg[1] =~ /^sto/i)
    { 
      require Nagios::Node::Stop;  
      return $Node->Stop (); 
    }
    #----------------------------------------------------------
    # TRANSMIT (needs both Post to be active)
    #----------------------------------------------------------
    if ($Arg[1] =~ /^t/i)
    {
      if (Tmdx::Fork()) 
      { 
        require Tmdx::Client::Post; 
        $Tmdx->Post($Command); 
        return 0;  
      }
      require Nagios::Node::Transmit; 
      return $Node->Transmit($Command); 
    }
    #----------------------------------------------------------
    # STOP
    #----------------------------------------------------------
    if ($Arg[1] =~ /^u/i)
    { 
      require Nagios::Node::Upload;  
      return $Node->Upload ($Command, @Arg); 
    }
    #----------------------------------------------------------
    require Nagios::Node::Usage;
    return Nagios::Node::Usage(1); 
  }
  #--------------------------------------------------------------------
  # Start the Nagios Node background processes ...
  #--------------------------------------------------------------------
  if (Tmdx::Fork()) { require Tmdx::Client::Get;      $Tmdx->Get($Command);      return 0; }
  if (Tmdx::Fork()) { require Tmdx::Client::Post;     $Tmdx->Post($Command);     return 0; }
  if (Tmdx::Fork()) { require Nagios::Node::Batch;    $Node->Batch($Command);    return 0; }
  if (Tmdx::Fork()) { require Nagios::Node::Checks;   $Node->Checks($Command);   return 0; }
  if (Tmdx::Fork()) { require Nagios::Node::Client;   $Node->Client($Command);   return 0; }
  if (Tmdx::Fork()) { require Nagios::Node::Core;     $Node->Core($Command);     return 0; }
  if (Tmdx::Fork()) { require Nagios::Node::Nmon;     $Node->Nmon($Command);     return 0; }
  if (Tmdx::Fork()) { require Nagios::Node::Receive;  $Node->Receive($Command);  return 0; }
  if (Tmdx::Fork()) { require Nagios::Node::Rsync;    $Node->Rsync($Command);    return 0; }
  if (Tmdx::Fork()) { require Nagios::Node::Transmit; $Node->Transmit($Command); return 0; }
  if (Tmdx::Fork()) { require Nagios::Node::Upload;   $Node->Upload($Command);   return 0; }
  #--------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;
 