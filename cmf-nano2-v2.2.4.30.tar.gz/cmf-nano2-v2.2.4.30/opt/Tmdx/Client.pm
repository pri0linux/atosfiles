package Tmdx::Client;
#------------------------------------------------------------------------------
# Tmdx/Client.pm - TMDX Client class definition
#------------------------------------------------------------------------------
use strict;
use warnings;
use Compress::Zlib;
use File::Copy;
use File::Path;
#------------------------------------------------------------------------------
sub new
{
  my ($Class, $Config, $Tx, $Rx, $Client, $Home);
  #------------------------------------------------------------------------
  die ("Stop signal \$main::Stop is undefined") if (! defined $main::Stop);
  $Class  = shift;
  $Config = shift;
  $Tx     = { "Spool"=>undef, "Key"=>undef, "Proxy"=>undef, "Servers"=>undef, "Count"=>0 };
  $Rx     = { "Spool"=>undef, "Key"=>undef, "Proxy"=>undef, "Servers"=>undef };
  $Client = { "Config"=>undef, "Tx"=>$Tx, "Rx"=>$Rx, "Error"=>undef };
  bless $Client, $Class;
  #------------------------------------------------------------------------
  # Check the configuration
  #------------------------------------------------------------------------
  if (ref($Config) eq "Tmdx::Config")
  {
    $Client->{"Config"} = $Config;
    $Client->{"Error"}  = "";
    $Home               = $ENV{HOME};
    #----------------------------------------------------------
    # Get the tmdx.spool settings
    #----------------------------------------------------------
    $Tx->{"Spool"} = $Client->Config('tmdx.spool', 'tmdxtx.spool', 'tmdx.txspool');
    $Rx->{"Spool"} = $Client->Config('tmdx.spool', 'tmdxrx.spool', 'tmdx.rxspool');
    if ($Tx->{"Spool"} && $Rx->{"Spool"}) 
    {
      $Tx->{"Spool"} =~ s/^\~\//$Home\//;
      $Rx->{"Spool"} =~ s/^\~\//$Home\//;
      mkpath ($Tx->{"Spool"}) if (! -d $Tx->{"Spool"});
      mkpath ($Rx->{"Spool"}) if (! -d $Rx->{"Spool"});
    }
    else { $Client->{"Error"} .= "'tmdx.spool' not configured!\n"; }
    #----------------------------------------------------------
    # Get the tmdx.tool setting (always same for Tx and Rx)
    #----------------------------------------------------------
    $Tx->{"Tool"} = $Config->{'tmdx.tool'};
    $Tx->{"Tool"} = ''     if (! $Tx->{"Tool"});
    $Tx->{"Tool"} = 'curl' if ($Tx->{"Tool"} =~ /curl/i);
    $Tx->{"Tool"} = 'wget' if ($Tx->{"Tool"} =~ /wget/i);
    if ($Tx->{"Tool"} !~ /curl|wget/i)
    {
        if    ($Config->{curl}) { $Tx->{"Tool"} = 'curl'; } # default
        elsif ($Config->{wget}) { $Tx->{"Tool"} = 'wget'; } # fallback
		else { $Client->{"Error"} .= "'curl' or 'wget' not available!\n"; }
	}
    elsif (! $Config->{$Tx->{"Tool"}})
    {
		$Client->{"Error"} .= "'$Tx->{Tool}' not available!\n";
	}
    $Rx->{"Tool"} = $Tx->{"Tool"};
    #----------------------------------------------------------
    # Get the tmdx.key settings
    #----------------------------------------------------------
    $Tx->{"Key"} = $Client->Config('tmdx.key', 'tmdxtx.key', 'tmdx.txkey');
    $Rx->{"Key"} = $Client->Config('tmdx.key', 'tmdxrx.key', 'tmdx.rxkey');
    if ($Tx->{"Key"} && $Rx->{"Key"}) 
    {
      $Tx->{"Key"} =~ s/^\~\//$Home\//;
      $Rx->{"Key"} =~ s/^\~\//$Home\//;
      if (! -r $Tx->{"Key"}) { $Client->{"Error"} .= $Tx->{"Key"}." does not exist!\n"; }
      if (! -r $Rx->{"Key"}) { $Client->{"Error"} .= $Rx->{"Key"}." does not exist!\n"; }
      if (-r $Tx->{"Key"}) { chmod (0400, $Tx->{"Key"}); }
      if (-r $Rx->{"Key"}) { chmod (0400, $Rx->{"Key"}); }
    }
    else { $Client->{"Error"} .= "'tmdx.key' not configured!\n"; }
    #----------------------------------------------------------
    # Get the tmdx.proxy settings
    #----------------------------------------------------------
    $Tx->{"Proxy"} = $Client->Config('tmdx.proxy', 'tmdxtx.proxy', 'tmdx.txproxy');
    $Rx->{"Proxy"} = $Client->Config('tmdx.proxy', 'tmdxrx.proxy', 'tmdx.rxproxy');
    if (! $Tx->{"Proxy"}) { $Tx->{"Proxy"} = ""; }
    if (! $Rx->{"Proxy"}) { $Rx->{"Proxy"} = ""; }
    #----------------------------------------------------------
    # Get the tmdx.servers settings
    #----------------------------------------------------------
    $Tx->{"Servers"} = $Client->Config('tmdx.servers', 'tmdxtx.servers', 'tmdx.txservers');
    $Rx->{"Servers"} = $Client->Config('tmdx.servers', 'tmdxrx.servers', 'tmdx.rxservers');
    if ((! $Tx->{"Servers"}) || (! $Rx->{"Servers"})) { $Client->{"Error"} .= "'tmdx.servers' not configured!\n"; }
    #----------------------------------------------------------
    if ($Client->{"Error"} eq "") { $Client->{"Error"} = undef; }
  }
  else { $Client->{"Error"} = "Invalid Config (not a 'Tmdx::Config')!"; }
  #------------------------------------------------------------------------
  return $Client;
}
#------------------------------------------------------------------------------
sub Config
{
  my ($Client, @Keys, $Config, $Value, $Key);
  ($Client, @Keys) = @_;
  die ("Usage: Tmdx::Client->Config(@Keys);") if (ref($Client) ne "Tmdx::Client");
  $Config = $Client->{"Config"};
  $Value  = undef;
  foreach $Key (@Keys)
  {
    if (exists $Config->{lc($Key)}) { $Value = $Config->{lc($Key)}; }
  }
  return $Value;
}
#------------------------------------------------------------------------------
sub Error
{
  my ($Client) = @_;
  die ("Usage: Tmdx::Client->Error();") if (ref($Client) ne "Tmdx::Client");
  return $Client->{"Error"};
}
#------------------------------------------------------------------------------
1;
