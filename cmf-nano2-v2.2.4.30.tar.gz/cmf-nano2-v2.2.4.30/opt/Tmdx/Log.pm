package Tmdx::Log;
#------------------------------------------------------------------------------
# Tmdx/Log.pm                                                      TMDX Library
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Path;
use POSIX;
#------------------------------------------------------------------------------
sub new
{
  my ($Class, $Path, $Name, $DTZ, $DTU, $Stdout) = @_;
  my ($Log, $Options, $Header);
  #------------------------------------------------------------------------
  # DTZ = Days To Zip, DTU = Days To Unlink (see Tmdx::Log->Rotate());
  #------------------------------------------------------------------------
  $Log = { "Path"   => $Path,    # Directory to store the logfiles
           "Name"   => $Name,    # Suffix for the name of the logfile
           "DTZ"    => 3,        # Days To Zip     - see Tmdx::Log->Rotate();
           "DTU"    => 33,       # Days To Unlink  - see Tmdx::Log->Rotate();
           "Stdout" => undef,    # Duplicate logged messages to STDOUT
           "File"   => "", 
           "Handle" => undef, 
           "Error"  => undef };

  if ((! defined $Path) || (! defined $Name))
  { 
    $Log->{"Error"} = "Log path and/or name not specified"; 
  }
  if (ref($DTZ) ne "HASH")
  {
    $Options = {};
    if ($DTZ) { $Log->{"DTZ"} = $DTZ; }
    if ($DTU) { $Log->{"DTU"} = $DTU; }
    $Log->{"Stdout"} = $Stdout;
  }
  else
  {
    $Options = $DTZ;
    $Log->{"DTZ"}    = $Options->{"DTZ"}    if exists $Options->{"DTZ"};
    $Log->{"DTU"}    = $Options->{"DTU"}    if exists $Options->{"DTU"};
    $Log->{"Stdout"} = $Options->{"Stdout"} if exists $Options->{"Stdout"};
  }
  bless ($Log, $Class);

  if (exists $Options->{"Header"})
  {
    $Header = $Options->{"Header"};
    $Header = [$Header] if (ref($Header) ne "ARRAY");
    $Log->Log (@$Header);
  }
  #------------------------------------------------------------------------
  return $Log;
}
#------------------------------------------------------------------------------
sub Close
{
  my ($Log, $Handle);
  #------------------------------------------------------------------------
  $Log   = shift;
  die ("Usage: Tmdx::Log->Close();") if (ref($Log) ne "Tmdx::Log");
  $Handle = $Log->{"Handle"};
  if (defined $Handle) { close ($Handle); }
  $Log->{"Handle"} = undef;
  #------------------------------------------------------------------------
  return 1;
}
#------------------------------------------------------------------------------
sub Error
{
  my ($Log) = @_;
  die ("Usage: Tmdx::Log->Error();") if (ref($Log) ne "Tmdx::Log");
  return $Log->{"Error"};
}
#------------------------------------------------------------------------------
sub Log
{
  my ($Log, @Message);
  #------------------------------------------------------------------------
  ($Log, @Message) = @_;
  die ("Usage: Tmdx::Log->Log();") if (ref($Log) ne "Tmdx::Log");
  $Log->Rotate();
  $Log->Write (@Message);
  #------------------------------------------------------------------------
  return $Log->{"Error"};
}
#------------------------------------------------------------------------------
sub Rotate
{
  my ($Log, $File, $Oldfile);
  my ($Gzip, $Age1, $Age2, $Grep, @Logs, @Zips, $Date);
  my ($Handle, $Select);
  #------------------------------------------------------------------------
  ($Log) = @_;
  die ("Usage: Tmdx::Log->Rotate();") if (ref($Log) ne "Tmdx::Log");
  $File = $Log->{"Path"}.strftime("/%Y%m%d-", gmtime()).$Log->{"Name"};
  if (($File eq $Log->{"File"}) && (defined $Log->{"Handle"})) { return undef; }
  $Log->Write ("Switching log to $File");
  $Oldfile = $Log->{"File"};
  $Log->{"File"} = $File;
  $Log->Close();
  #------------------------------------------------------------------------
  chdir ($Log->{"Path"});
  $Gzip = `which gzip 2>/dev/null`; 
  chomp $Gzip;
  $Age1 = strftime("%Y%m%d", gmtime(time()- $Log->{"DTZ"} * 24*60*60));
  $Age2 = strftime("%Y%m%d", gmtime(time()- $Log->{"DTU"} * 24*60*60));
  if (opendir (LOGS, $Log->{"Path"}))
  { 
    $Grep = $Log->{"Name"};
    $Grep =~ s/\./\\\./g;
    @Logs = sort (grep { /^\d+-$Grep$/     } readdir(LOGS));
    rewinddir(LOGS);
    @Zips = sort (grep { /^\d+-$Grep\.gz$/ } readdir(LOGS));
    closedir LOGS;
    for $File (@Logs) 
    {
      ($Date) = ($File =~ /^(\d+)/);
      $File = "$Log->{'Path'}/$File";
      next if ($Date >= $Age1);
      if ($Date < $Age2) { unlink ($File); }
      elsif ($Gzip) { `$Gzip $File`; }
    }
    for $File (@Zips) 
    {
      ($Date) = ($File =~ /^(\d+)/);
      $File = "$Log->{'Path'}/$File";
      if ($Date < $Age2) { unlink ($File); }
    }
  }
  #------------------------------------------------------------------------
  if (! -d $Log->{"Path"}) { mkpath ($Log->{"Path"}); }
  if (! open ($Handle, ">>$Log->{'File'}"))
  {
    $Log->{"Handle"} = undef;
    $Log->{"Error"} = "Error writing '$Log->{'File'}': $!";
    return $Log->{"Error"};
  }
  $Log->{"Handle"} = $Handle;
  $Select = select($Handle); 
  $| = 1; 
  select($Select); 
  if ($Oldfile) { $Log->Write ("Switched log from $Oldfile"); }
  #------------------------------------------------------------------------
  return undef;
}
#------------------------------------------------------------------------------
sub Write
{
  my ($Log, @Message, $Handle, $Time, $Usec, $Timestamp, @Lines);
  #------------------------------------------------------------------------
  ($Log, @Message) = @_;
  die ("Usage: Tmdx::Log->Write(@Message);") if (ref($Log) ne "Tmdx::Log");
  $Handle = $Log->{"Handle"};
  if (! defined $Handle) { return 0; }
  if (! eval "require Time::HiRes") { $Time = time(); $Usec = 0; }
  else { ($Time, $Usec) = Time::HiRes::gettimeofday(); }
  $Timestamp  = strftime("%H:%M:%S.", gmtime($Time));
  $Timestamp .= sprintf ("%03d", $Usec/1000);
  foreach (@Message) 
  { 
    @Lines = split (/\n/, $_);
    foreach (@Lines)
    {
      print $Handle "$Timestamp $_\n"; 
      if ($Log->{"Stdout"}) { print "$_\n"; }
    }
  }
  #------------------------------------------------------------------------
  return 1;
}
#------------------------------------------------------------------------------
1;
