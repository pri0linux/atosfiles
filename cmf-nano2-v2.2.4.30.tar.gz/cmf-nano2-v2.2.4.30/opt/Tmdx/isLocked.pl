#!/usr/bin/env perl
#------------------------------------------------------------------------------
# isLocked.pl                                                      TMDX Library
#------------------------------------------------------------------------------

  use strict;
  use warnings;
  use Fcntl qw(:DEFAULT :flock);
  use File::Basename;

  my ($Script, $File);

  $Script = basename($0);
  if ($#ARGV != 0)
  {
    print ("Usage: $Script <lockfile>\n");
    exit (3);
  }
  $File = $ARGV[0];
  if (sysopen (LOCK, $File, O_WRONLY | O_NONBLOCK))
  { 
    if (flock (LOCK, LOCK_EX | LOCK_NB))
    {
      close (LOCK);
      exit (1);
    }
    close (LOCK);
    exit (0);
  }
  print ("$!\n");
  exit (2);

#------------------------------------------------------------------------------
#[eof]
