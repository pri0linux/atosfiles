package Tmdx::Client;
#------------------------------------------------------------------------------
# Tmdx/Client/Curl.pm - TMDX Client 'curl' command handler
#------------------------------------------------------------------------------
use strict;
use warnings;

use POSIX;
#------------------------------------------------------------------------------
sub Curl
{
	my ($Client, $Method, $Url, $Data) = @_;
	my ($Mode, $Config, $Settings, $File, @Curl, $Handle, $Pid, $Limit);
	my ($Response, $Output, $Stderr, $Line, $Status, @Line);
	#----------------------------------------------------------------------
	# Compose the 'curl' command
	#----------------------------------------------------------------------
	$Mode     = ($Method =~ /P/i) ? "Tx" : "Rx";
	$Config   = $Client->{Config};
	$Settings = $Client->{$Mode};
	$File     = $Settings->{File};
	@Curl     = ($Config->{curl});		
	push (@Curl, "-A", "NagiosNode/$main::VERSION ($Config->{hostname})");
	unlink ("$File.data");
	if (defined $Data)
	{
		if (! open ($Handle, ">$File.data"))
		{
			return { status => "000 Unable to write '$File.data': $!" };
		}
		print $Handle $Data;
		close ($Handle);
		push (@Curl, "-H", "Expect:");
		push (@Curl, "-H", "Content-Type: application/octet-stream");		
		push (@Curl, "--data-binary", "\@$File.data");
	}
	if ($Settings->{Proxy} eq "")
	{
		delete ($ENV{'https_proxy'});
		delete ($ENV{'HTTPS_PROXY'});
	}
	else
	{
		$ENV{https_proxy} = $Settings->{Proxy};
		$ENV{HTTPS_PROXY} = $Settings->{Proxy};
	}
	push (@Curl, "-D", "$File.head");
	push (@Curl, "-o", "$File.data.gz");
	push (@Curl, "-k"); # don't check the server certificate
	push (@Curl, "-s", "-S"); # silent except for error messages
	push (@Curl, $Url);
	push (@Curl, "-E", $Settings->{Key}); # Last to keep ps output readable
	unlink ("$File.head");
	unlink ("$File.data.gz");
	#----------------------------------------------------------------------
	# Execute the 'curl' command
	#----------------------------------------------------------------------
	$Pid  = fork();
	if (! defined $Pid)
	{
		$main::Stop++;
		return { status => "000 Fork failed: $!" } 
	}
	if (! $Pid) #client
	{
		open STDIN , '<', '/dev/null';
		open STDOUT, '>', "$File.stdout";
		open STDERR, '>', "$File.stderr";
		exec (@Curl) || print $!;
		exit (0);
	}
	$Limit   = time() + (($Method =~ /P/i) ? 15 : 75);	
	while (! waitpid ($Pid, WNOHANG))
	{
		if ($main::Stop || (time() >= $Limit))
		{
			kill (-9, $Pid);
			kill (9, $Pid);
			return { status => "000 Aborted" } if ($main::Stop);
			return { status => "000 Timeout" };
		}
		sleep (1);
	}
	#----------------------------------------------------------------------
	# Process the 'curl' output
	#----------------------------------------------------------------------
	if (! open ($Output, "$File.head"))
	{
		$Response = { status => "000 Unable to read '$File.head': $!" };
		if (open ($Stderr, "$File.stderr"))
		{
			while ($Line = <$Stderr>) { $Client->{Log}->Log ("ERROR: $Line"); }
			close ($Stderr);
		}
		return $Response;
	}
	$Line = <$Output>;
	if (! defined $Line)
	{
		if (open ($Stderr, "$File.stderr"))
		{
			while ($Line = <$Stderr>)
			{
				next if ($Line !~ /ERROR \d{3}\D/);
				$Line =~ s/\s+//;
				($Status) = ($Line =~ /\D(\d{3}\D.*)$/);
				$Status = [split (/[\:\s]+/, $Status, 2)];
				$Response->{status} = join (" ", @$Status);
			}
			close ($Stderr);
		}
		close ($Output);
		return $Response;
	}
	$Line =~ s/\s+$//;
	$Status = [split (/\s+/, $Line, 2)];
	$Response->{status} = $Status->[1];
	$Response->{head} = {};
	$Response->{info} = {};
	while ($Line = <$Output>) 
	{
		$Line =~ s/\s+$//;
		if ($Line =~ /^HTTP\//)
		{
			$Status = [split (/\s+/, $Line, 2)];
			$Response->{status} = $Status->[1];
			next;
		}
		@Line = split (/\s*:\s*/, $Line, 2);
		next if ($#Line != 1);
		$Line = lc ($Line[0]);
		if ($Line eq "set-cookie")
		{
			@Line = split (/\s*=\s*/, $Line[1], 2);
			next if ($#Line < 1);
			$Line[1] =~ s/;.*$//;
            $Line[1] =~ tr/+/ /;
            $Line[1] =~ s/%([\da-fA-F]{2})/chr (hex ($1))/eg;
			$Response->{info}{lc $Line[0]} = $Line[1];
			next;
		}
		$Response->{head}{$Line[0]} = $Line[1];
	}	
	close ($Output);
	$Response->{data} = "";
	return $Response if (! open ($Output, "$File.data.gz"));
	$Response->{data} = do { local $/; <$Output> };
	close ($Output);
	#----------------------------------------------------------------------
	return $Response;
}
#------------------------------------------------------------------------------
1;


