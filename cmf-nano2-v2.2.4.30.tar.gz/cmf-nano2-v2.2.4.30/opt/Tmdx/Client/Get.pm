package Tmdx::Client;
#------------------------------------------------------------------------------
# Tmdx/Client/Get.pm - TMDX Client class Get method definition
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Path;
use Tmdx::Client::Curl;
use Tmdx::Client::Wget;
#------------------------------------------------------------------------------
sub Get
{
  my ($Client, $Command, @Servers, $Server, $Lock, $Log, $Index);
  my ($File, $StartTime, $Delay, $Tool, $Response, $Info, $Name);
  #--------------------------------------------------------------------
  # Create the spool/rx folder and fork a process for each server
  #--------------------------------------------------------------------
  ($Client, $Command) = @_;
  die ("Usage: Tmdx::Client->Get();") if (ref($Client) ne "Tmdx::Client");
  if (! -d $Client->{"Rx"}{"Spool"}."/rx") { mkpath ($Client->{"Rx"}{"Spool"}."/rx"); }
  if ($#ARGV < 2)
  {
    require "Tmdx/Fork.pm";
    @Servers = split (/[\s\,\;]+/, $Client->{"Rx"}{"Servers"});
    foreach (@Servers)
    {
      $Server = undef;
      if (Tmdx::Fork()) { $Server = $_; last; }
    }
    return 0 if (! $Server);
  }
  else { $Server = $ARGV[2]; }
  $Client->{"Rx"}{"Server"} = $Server;
  $Client->{"Rx"}{"File"} = $Client->{"Rx"}{"Spool"}."/get-$Server";
  #--------------------------------------------------------------------
  # The parent process returns, the forked processes continue ...
  #--------------------------------------------------------------------
  require "Tmdx/Lock.pm";
  $Lock = Tmdx::Lock->new ($Client->{"Rx"}{"File"}.".pid");
  if (defined $Lock->Error())
  {
    die ($Lock->Error()."\n");
  }
  if (! $Lock->Lock()) 
  { 
    die ($Lock->Error()."\n") if (defined $Lock->Error());
    $Client->Get_SelfCheck($Server);
    exit 0;
  }
  #--------------------------------------------------------------------
  # Open the log, cleanup, get the index and get 5 minutes to start
  #--------------------------------------------------------------------
  $Command = $0 if (! defined $Command);
  $0 = $Command."->Tmdx::Client->Get('$Server')";
  require "Tmdx/Log.pm";
  $Log = Tmdx::Log->new ($Client->{"Rx"}{"Spool"}."/log", "get-$Server.log", undef, undef, 1);
  $Log->Log ("------------------------------------------------------------------",
             "Tmdx::Client->Get('$Server') v$main::VERSION - Copyright (c) $main::COPYRIGHT");
  $Client->{Log} = $Log;
  $Client->Get_Cleanup ($Log, $Server);
  $Index = 0;
  if (open (INDEX, $Client->{"Rx"}{"File"}.".idx"))
  {
    $Index = int(<INDEX>);
    close INDEX;
  }
  $Log->Log ("Saved index is $Index");
  $File = $Client->{"Rx"}{"File"}.".kill";
  `touch $File`;
  $StartTime = time();
  $Delay     = 0;
  $Tool      = ucfirst lc $Client->{"Rx"}{"Tool"};
  #--------------------------------------------------------------------
  # Process the incoming data .....
  #--------------------------------------------------------------------
  while (! $main::Stop)
  {
    if ((time() - $StartTime) > 3600) # 1 hour runtime limit
    {
      $Log->Log ("Runtime limit exceeded: restarting ..."); 
      return $Lock->Unlink();
    }
    $Log->Log (uc($Tool)." GET https://$Server/Tmdx/Server/?ticket=$Index ...");
    $Response = $Client->$Tool("GET", "https://$Server/Tmdx/Server/?ticket=$Index");
    $Log->Log ("    ".$Response->{status});
    last if ($main::Stop);
    if (($Response->{status} =~ /^200/) && (exists $Response->{info}))
    {
		$Info = $Response->{info};
        if (exists $Info->{ticket})
        {
          #--------------------------------------------
          # Write the data and info files
          #--------------------------------------------
          $File = $Client->{Rx}{Spool}."/rx/$Info->{ticket}.$Server";
          if (open (DATA, ">$File.data"))
          {
            print DATA $Response->{data};
            close DATA;
            if (open (INFO, ">$File.info"))
            {
			  foreach $Name (sort keys %$Info)
			  {
				next if ($Name =~ /^[\.\_]/);
				print INFO "$Name: $Info->{$Name}\n";
              }
              close INFO;
              $Log->Log ("    Received '$File.*'");
              $Delay = 0;
            } 
            else
            {
              $Log->Log ("ERROR: Unable to write '$File.info': $!");
              unlink "$File.data";
              $Delay++;
            }
          }
          else
          {
            $Log->Log ("ERROR: Unable to write '$File.data': $!");
            $Delay++;
          }
          #--------------------------------------------
          # Write the index file and touch the ack file
          #--------------------------------------------
          $File  = $Client->{"Rx"}{"File"}.".idx";
          $Index = $Info->{'ticket'};
          if (open (INDEX, ">$File"))
          {
            print INDEX $Index;
            close INDEX;
            $Log->Log ("Saved index is $Index");
          }
          else
          {
            $Log->Log ("ERROR: Unable to write '$File': $!");
            $Delay++;
          }
          $File  = $Client->{"Rx"}{"File"}.".ack";
          `touch $File`;
          #--------------------------------------------
        }
        else 
        {
          $Log->Log ("WARNING: Skipping data without 'ticket' cookie");
          $Delay++;
        }
        #------------------------------------------------------
    }
    elsif ($Response->{status} =~ /^204/) 
    { 
        $File  = $Client->{"Rx"}{"File"}.".ack";
        `touch $File`;
        $Delay = 1; 
    }
    else  { $Delay++; }

	if (exists $Response->{info}{_heartbeat})
	{
		if (defined $Response->{info}{_heartbeat})
		{
			$File = $Client->{"Rx"}{"File"}.".hbt";
			if (open (HBT, ">$File"))
			{
			  print HBT $Response->{info}{_heartbeat}."\n";
			  close HBT;
			}
			else { $Log->Log ("Error writing '$File': $!"); }
		}
	}
    last if ($Delay > 7);
    sleep ($Delay);
    $Lock->Touch();
  }
  #--------------------------------------------------------------------
  # ..... until we're done .....
  #--------------------------------------------------------------------
  $Lock->Unlink();
  exit 0;
}
#------------------------------------------------------------------------------
sub Get_Cleanup
{
  my ($Client, $Log, $Server, $Grep, @Files, $File, @Info, $Gmt, $Ttl, $Info);
  my ($Name, $Value);
  #--------------------------------------------------------------------
  ($Client, $Log, $Server) = @_;
  die ("Usage: Tmdx::Client->Get_Cleanup($Log, $Server);") if (ref($Client) ne "Tmdx::Client");
  die ("Usage: Tmdx::Client->Get_Cleanup($Log, $Server);") if (ref($Log) ne "Tmdx::Log");
  #--------------------------------------------------------------------
  if (opendir (SPOOL, $Client->{"Rx"}{"Spool"}."/rx/"))
  { 
    $Log->Log ("Checking for expired files");
    $Grep  = ".$Server.info";
    $Grep  =~ s/\./\\\./g;
    @Files = sort (grep { /^\d+$Grep$/ } readdir(SPOOL));
    closedir SPOOL;
    for $File (@Files) 
    {
      $File =~ s/\.info$//;
      $File = $Client->{"Rx"}{"Spool"}."/rx/$File";
      if (open (INFO, "$File.info"))
      {
        @Info = <INFO>;
        close INFO;
        $Gmt = 0;
        $Ttl = 0;
        foreach $Info (@Info)
        {
          $Info  =~ s/^\s*//; $Info =~ s/\s*$//;
          ($Name, $Value) = split (/\s*[:=]\s*/, $Info, 2);
          next if ((! defined $Name)||(! defined $Value));
          $Name  =~ s/\s*$//; $Value =~ s/^\s*//;
          if ($Name =~ /^gmt$/i) { $Gmt = $Value; }
          if ($Name =~ /^ttl$/i) { $Ttl = $Value; }
        }
        if (($Gmt + $Ttl + 60) < time())
        {
          $Log->Log ("  Removing expired '$File.*'");
          if (-r "$File.info") { unlink ("$File.info"); }
          if (-r "$File.data") { unlink ("$File.data"); }
        }
      }
    }
  }
}
#------------------------------------------------------------------------------
sub Get_SelfCheck
{
  my ($Client, $Server, $Log, $Kill, $Age, $File, $Pid, @Stat);
  #--------------------------------------------------------------------
  ($Client, $Server) = @_;
  die ("Usage: Tmdx::Client->Get_SelfCheck(Server);") if ((ref($Client) ne "Tmdx::Client") || (! defined $Server));
  $0 .= "::Tmdx::Client->Get_SelfCheck('$Server')";
  return if (! -r $Client->{"Rx"}{"Spool"}."/get-$Server.pid"); # Impossible !!!
  require "Tmdx/Log.pm";
  $Log = Tmdx::Log->new ($Client->{"Rx"}{"Spool"}."/log", "get-$Server-selfcheck.log", undef, undef, 1);
  $Log->Log ("------------------------------------------------------------------",
             "Tmdx::Client->Get_SelfCheck('$Server') v$main::VERSION - Copyright (c) $main::COPYRIGHT");
  $Kill = 0;
  $Pid  = undef;

  $Age = $Client->Get_CheckHeartbeat ("Process", $Client->{"Rx"}{"Spool"}."/get-$Server.pid", $Log);
  if (defined $Age) { if ($Age > 300) { $Kill++; } }

  $Age = $Client->Get_CheckHeartbeat ("Local '$Server'", $Client->{"Rx"}{"Spool"}."/get-$Server.ack", $Log);
  if (defined $Age) { if ($Age > 300) { $Kill++; } }

  # Crosscheck the remote 'get' heartbeat retrieved by the 'post' process ...
  $Age = $Client->Get_CheckHeartbeat ("Remote '$Server'", $Client->{"Tx"}{"Spool"}."/post-$Server.hbt", $Log);
  if (defined $Age) { if ($Age > 600) { $Kill++; } }

  return if (! $Kill);
  $File = $Client->{"Rx"}{"Spool"}."/get-$Server.pid";
  $Pid  = `cat $File 2>/dev/null`;
  chomp $Pid;
  return if (! $Pid);

  $File = $Client->{"Rx"}{"Spool"}."/get-$Server.kill";
  @Stat = stat ($File);
  if ($#Stat < 9) { $Stat[9] = 0; }
  $Age  = time() - $Stat[9];
  if ($Age <= 275)
  {
    $Log->Log ("Process $Pid was killed $Age seconds ago: waiting for restart ...");
    return;
  }
  `touch $File`;
  $Log->Log ("Killing process $Pid and waiting for it to restart ...");
  kill ( 2, $Pid);
  kill (15, $Pid);
  #--------------------------------------------------------------------
  return;
}
#------------------------------------------------------------------------------
sub Get_CheckHeartbeat
{
  my ($Client, $Heartbeat, $File, $Log, @Stat, $Age, $Pid, $Message);
  #--------------------------------------------------------------------
  ($Client, $Heartbeat, $File, $Log) = @_;
  die ("Usage: Tmdx::Client->Get_CheckHeartbeat();") if (ref($Client) ne "Tmdx::Client");
  @Stat = stat ($File);
  if ($File !~ /\.hbt/)
  {
    if ($#Stat < 9) 
    { 
      $Log->Log ("Unable to read '$File': $!");
      return undef;
    }
    $Age = time() - $Stat[9];
	if ($File =~ /\.pid/)
	{
		if (open (HBT, $File)) 
		{
			$Pid = <HBT>;
			close HBT;
			$Pid =~ s/\D//g;
			$Heartbeat .= " $Pid";
		}
	}
  }
  else 
  {
    if ($#Stat < 9) { return undef; }
    $Age = time() - $Stat[9];
    if ($Age > 300) { return undef; }
    if (! open (HBT, $File)) { return undef; }
    $Age = <HBT>;
    close HBT;
    ($Age) = ($Age=~ /^(\d+)/); # The first part is the 'get' heartbeat
    $Age  = time() - $Age;
  }
  if    ($Age <= 300) { $Message = "OK";       }
  elsif ($Age <= 600) { $Message = "WARNING";  }
  else                { $Message = "CRITICAL"; }
  $Message .= ": $Heartbeat heartbeat is $Age second";
  $Message .= "s" if $Age != 1;
  $Message .= " old.";
  $Log->Log ($Message);
  #--------------------------------------------------------------------
  return $Age;
}
#------------------------------------------------------------------------------
1;
