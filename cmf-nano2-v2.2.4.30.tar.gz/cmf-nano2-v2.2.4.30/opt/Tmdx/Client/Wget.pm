package Tmdx::Client;
#------------------------------------------------------------------------------
# Tmdx/Client/Wget.pm - TMDX Client 'wget' command handler
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Wget
{
	my ($Client, $Method, $Url, $Data) = @_;
	my ($Mode, $Config, $Settings, $File, @Wget, $Handle, $Pid, $Limit);
	my ($Response, $Output, $Stderr, $Line, $Status, @Line);
	#----------------------------------------------------------------------
	# Compose the 'wget' command
	#----------------------------------------------------------------------
	$Mode     = ($Method =~ /P/i) ? "Tx" : "Rx";
	$Config   = $Client->{Config};
	$Settings = $Client->{$Mode};
	$File     = $Settings->{File};
	@Wget     = ($Config->{wget});		
	push (@Wget, "-U", "NagiosNode/$main::VERSION ($Config->{hostname})");
	unlink ("$File.data");
	if (defined $Data)
	{
		if (! open ($Handle, ">$File.data"))
		{
			return { status => "000 Unable to write '$File.data': $!" };
		}
		print $Handle $Data;
		close ($Handle);
		push (@Wget, "--header", "Expect:");
		push (@Wget, "--header", "Content-Type: application/octet-stream");
		push (@Wget, "--post-file=$File.data");
	}
	push (@Wget, "--certificate=$Settings->{Key}");
	if ($Settings->{Proxy} eq "")
	{
		delete ($ENV{'https_proxy'});
		delete ($ENV{'HTTPS_PROXY'});
		push (@Wget, "--no-proxy");
	}
	else
	{
		$ENV{https_proxy} = $Settings->{Proxy};
		$ENV{HTTPS_PROXY} = $Settings->{Proxy};
	}
	push (@Wget, "-O", "$File.data.gz"); # response file
	push (@Wget, "--save-headers"); # include response headers in response file
	push (@Wget, "--no-check-certificate"); # don't check the server certificate
	push (@Wget, "-nv"); # only show error messages and basic information
	push (@Wget, $Url);
	unlink ("$File.data.gz");
	#----------------------------------------------------------------------
	# Execute the 'wget' command
	#----------------------------------------------------------------------
	$Pid  = fork();
	if (! defined $Pid)
	{
		$main::Stop++;
		return { status => "000 Fork failed: $!" } 
	}
	if (! $Pid) #client
	{
		open STDIN , '<', '/dev/null';
		open STDOUT, '>', "$File.stdout";
		open STDERR, '>', "$File.stderr";
		exec (@Wget) || print $!;
		exit (0);
	}
	$Limit   = time() + (($Method =~ /P/i) ? 15 : 75);	
	while (! waitpid ($Pid, WNOHANG))
	{
		if ($main::Stop || (time() >= $Limit))
		{
			kill (-9, $Pid);
			kill (9, $Pid);
			return { status => "000 Aborted" } if ($main::Stop);
			return { status => "000 Timeout" };
		}
		sleep (1);
	}
	#----------------------------------------------------------------------
	# Process the 'wget' output
	#----------------------------------------------------------------------
	if (! open ($Output, "$File.data.gz"))
	{
		$Response = { status => "000 Unable to read '$File.data.gz': $!" };
		if (open ($Stderr, "$File.stderr"))
		{
			while ($Line = <$Stderr>) { $Client->{Log}->Log ("ERROR: $Line"); }
			close ($Stderr);
		}
		return $Response;
	}
	$Line = <$Output>;
	if (! defined $Line)
	{
		if (open ($Stderr, "$File.stderr"))
		{
			while ($Line = <$Stderr>)
			{
				next if ($Line !~ /ERROR \d{3}\D/);
				$Line =~ s/\s+//;
				($Status) = ($Line =~ /\D(\d{3}\D.*)$/);
				$Status = [split (/[\:\s]+/, $Status, 2)];
				$Response->{status} = join (" ", @$Status);
			}
			close ($Stderr);
		}
		close ($Output);
		return $Response;
	}
	$Line =~ s/\s+$//;
	$Status = [split (/\s+/, $Line, 2)];
	$Response->{status} = $Status->[1];
	$Response->{head} = {};
	$Response->{info} = {};
	while ($Line = <$Output>) 
	{ 
		last if ($Line =~ /^\s*$/);
		$Line =~ s/\s+$//;
		@Line = split (/\s*:\s*/, $Line, 2);
		next if ($#Line != 1);
		$Line = lc ($Line[0]);
		if ($Line eq "set-cookie")
		{
			@Line = split (/\s*=\s*/, $Line[1], 2);
			next if ($#Line < 1);
			$Line[1] =~ s/;.*$//;
            $Line[1] =~ tr/+/ /;
            $Line[1] =~ s/%([\da-fA-F]{2})/chr (hex ($1))/eg;
			$Response->{info}{lc $Line[0]} = $Line[1];
			next;
		}
		$Response->{head}{$Line[0]} = $Line[1];
	}	
	$Response->{data} = do { local $/; <$Output> };
	close ($Output);
	#----------------------------------------------------------------------
	return $Response;
}
#------------------------------------------------------------------------------
1;


