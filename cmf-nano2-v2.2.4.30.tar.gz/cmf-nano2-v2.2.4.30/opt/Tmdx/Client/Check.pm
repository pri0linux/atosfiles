package Tmdx::Client;
#------------------------------------------------------------------------------
# Tmdx/Client/Check.pm - TMDX Client class Check method definition
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Check
{
  my ($Client, @Get, @Post, $State);

  ($Client) = @_;
  die ("Usage: Tmdx::Client->Check();") if (ref($Client) ne "Tmdx::Client");
  @Get  = $Client->Check_Get();
  @Post = $Client->Check_Post();
  $State = -1;
  $State = $Get[0]  if ($Get[0]  > $State);
  $State = $Post[0] if ($Post[0] > $State);
  print $Get[1].", ".$Post[1]."|".$Get[2]." ".$Post[2]."\n";
  return $State;
}
#------------------------------------------------------------------------------
sub Check_Get
{
  my ($Client, $State, $States, $Age, $Ages, $Max, @Servers, $Server);
  my ($Message, $Perfdata);
  
  ($Client) = @_;
  die ("Usage: Tmdx::Client->Check_Get();") if (ref($Client) ne "Tmdx::Client");
  $State  = 0;
  $States = 0;
  $Age    = 0;
  $Ages   = "";
  $Max    = 0;
  @Servers = split (/[\s\,\;]+/, $Client->{"Rx"}{"Servers"});
  foreach $Server (@Servers)
  {
    $Age = $Client->Check_Get_Server ($Server);
    if (($Max < 0) || ($Age < 0)) { $Max = -1; }
    elsif ($Age > $Max) { $Max = $Age; }
    if    ($Age <    0) { $State = 2;  $Age = "?"; }
    elsif ($Age <= 300) { $State = 0;  }
    elsif ($Age <= 600) { $State = 1;  }
    else                { $State = 2;  }
    $States = $State if ($State > $States);
    $Ages .= $Age."s/";
  }
  $Ages =~ s/\/$//;
  $Message  = "Get heartbeat age $Ages";
  $Perfdata = "get=".$Max."s;300;600;0";
  return ($States, $Message, $Perfdata);
}
#------------------------------------------------------------------------------
sub Check_Get_Server
{
  my ($Client, $Server, $Age, $File, @Stat);
  
  ($Client, $Server) = @_;
  die ("Usage: Tmdx::Client->Check_Get_Server(Server);") if (ref($Client) ne "Tmdx::Client");
  $File = $Client->{"Rx"}{"Spool"}."/get-$Server.ack";
  @Stat = stat ($File);
  if ($#Stat < 9) { $Age = -1; }
  else { $Age = time() - $Stat[9]; }
  return $Age;
}
#------------------------------------------------------------------------------
sub Check_Post
{
  my ($Client, $State, $States, $Age, $Ages, $Max, @Servers, $Server);
  my ($Message, $Perfdata);
  
  ($Client) = @_;
  die ("Usage: Tmdx::Client->Check_Post();") if (ref($Client) ne "Tmdx::Client");
  $State  = 0;
  $States = 0;
  $Age    = 0;
  $Ages   = "";
  $Max    = 0;
  @Servers = split (/[\s\,\;]+/, $Client->{"Tx"}{"Servers"});
  foreach $Server (@Servers)
  {
    $Age = $Client->Check_Post_Server ($Server);
    if (($Max < 0) || ($Age < 0)) { $Max = -1; }
    elsif ($Age > $Max) { $Max = $Age; }
    if    ($Age <    0) { $State = 2;  $Age = "?"; }
    elsif ($Age <= 300) { $State = 0;  }
    elsif ($Age <= 600) { $State = 1;  }
    else                { $State = 2;  }
    $States = $State if ($State > $States);
    $Ages .= $Age."s/";
  }
  $Ages =~ s/\/$//;
  $Message  = "Post heartbeat age $Ages";
  $Perfdata = "post=".$Max."s;300;600;0";
  return ($States, $Message, $Perfdata);
}
#------------------------------------------------------------------------------
sub Check_Post_Server
{
  my ($Client, $Server, $Age, $File, @Stat);
  
  ($Client, $Server) = @_;
  die ("Usage: Tmdx::Client->Check_Post_Server(Server);") if (ref($Client) ne "Tmdx::Client");
  $File = $Client->{"Tx"}{"Spool"}."/post-$Server.ack";
  @Stat = stat ($File);
  if ($#Stat < 9) { $Age = -1; }
  else { $Age = time() - $Stat[9]; }
  return $Age;
}
#------------------------------------------------------------------------------
1;


