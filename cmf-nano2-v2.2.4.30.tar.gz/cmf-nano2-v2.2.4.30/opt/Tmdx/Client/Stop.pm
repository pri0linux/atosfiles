package Tmdx::Client;
#------------------------------------------------------------------------------
# Tmdx/Client/Stop.pm - TMDX Client class Stop method definition
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Stop
{
  my ($Client, @Servers, $Server, $Lock, $Pid);
  #--------------------------------------------------------------------
  ($Client) = @_;
  die ("Usage: Tmdx::Client->Stop();") if (ref($Client) ne "Tmdx::Client");
  @Servers = split (/[\s\,\;]+/, $Client->{"Rx"}{"Servers"});
  foreach $Server (@Servers)
  {
    $Lock = $Client->{"Rx"}{"Spool"}."/get-$Server.pid";
    if (-r $Lock) 
    { 
      $Pid = `cat $Lock`;
      chomp $Pid;
      kill ( 2, $Pid); 
      kill (15, $Pid); 
    }
  }
  $Lock = $Client->{"Tx"}{"Spool"}."/post.pid";
  if (-r $Lock) 
  { 
    $Pid = `cat $Lock`;
    chomp $Pid;
    kill ( 2, $Pid); 
    kill (15, $Pid); 
  }
  #--------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
1;


