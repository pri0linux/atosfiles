package Tmdx::Client;
#------------------------------------------------------------------------------
# Tmdx/Client/Post.pm - TMDX Client class Post method definition
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Path;
use Tmdx::Client::Curl;
use Tmdx::Client::Wget;
#------------------------------------------------------------------------------
sub Post
{
  my ($Client, $Command, $Lock, $Log, $LastServer, $StartTime, $Sleep);
  my ($Spool, @Files, $Count, $File, $Time, @Stat, %Info, $Info);
  my ($Name, $Value, $Data, $UsedServer);
  #--------------------------------------------------------------------
  # Create the spool/rx folder and fork a child process
  #--------------------------------------------------------------------
  ($Client, $Command) = @_;
  die ("Usage: Tmdx::Client->Post();") if (ref($Client) ne "Tmdx::Client");
  if (! -d $Client->{"Tx"}{"Spool"}."/tx") { mkpath ($Client->{"Tx"}{"Spool"}."/tx"); }
  if ($#ARGV < 1)
  {
    require "Tmdx/Fork.pm";
    return 0 if (! Tmdx::Fork());
  }
  $Client->{"Tx"}{"File"} = $Client->{"Tx"}{"Spool"}."/post";
  #--------------------------------------------------------------------
  # The parent process returns, the forked process continues ...
  #--------------------------------------------------------------------
  require "Tmdx/Lock.pm";
  $Lock = Tmdx::Lock->new ($Client->{"Tx"}{"File"}.".pid");
  die ($Lock->Error()."\n") if (defined $Lock->Error());
  if (! $Lock->Lock()) 
  { 
    die ($Lock->Error()."\n") if (defined $Lock->Error());
    $Client->Post_SelfCheck();
    exit 0;
  }
  #--------------------------------------------------------------------
  # Open the log and get 5 minutes to start
  #--------------------------------------------------------------------
  $Command = $0 if (! defined $Command);
  $0 = $Command."->Tmdx::Client->Post()";
  require "Tmdx/Log.pm";
  $Log = Tmdx::Log->new ($Client->{"Tx"}{"Spool"}."/log", "post.log", undef, undef, 1);
  $Log->Log ("------------------------------------------------------------------",
             "Tmdx::Client->Post() v$main::VERSION - Copyright (c) $main::COPYRIGHT");
  $Client->{Log} = $Log;
  $File = $Client->{"Tx"}{"File"}.".kill";
  `touch $File`;
  $LastServer = undef;
  $StartTime  = time();
  $Sleep      = 50;
  #--------------------------------------------------------------------
  # Process the queued data .....
  #--------------------------------------------------------------------
  while (! $main::Stop)
  {
    if ((time() - $StartTime) > 3600) # 1 hour runtime limit
    {
      $Log->Log ("Runtime limit exceeded: restarting ..."); 
      return $Lock->Unlink();
    }
    $Spool = $Client->{"Tx"}{"Spool"}."/tx/";
    if (! opendir (SPOOL, $Spool))
    {
      $Log->Log ("Error reading '$Spool': $!"); 
      return $Lock->Unlink();
    }
    @Files = sort (grep { /^[^\.].+\.info$/ } readdir(SPOOL));
    closedir (SPOOL);
    $Count = 0;
    foreach $File (@Files)
    {
      $File =~ s/\.info$//;
      ($Time) = ($File =~ /^(\d+)/);
      next if (($Time+1) >= time());
      #--------------------------------------------------------
      # Load the info and data to be posted
      #--------------------------------------------------------
      @Stat = stat ("$Spool/$File.info");
      $Stat[9] = 0 if ($#Stat < 9);
      if (! open (INFO, "$Spool/$File.info"))
      {
        $Log->Log ("Skipped '$File': $!"); 
        unlink ("$Spool/$File.info");
        unlink ("$Spool/$File.data");
        next;
      }
      %Info = ();
      foreach $Info (<INFO>)
      {
        $Info  =~ s/^\s*//; $Info =~ s/\s*$//;
        ($Name, $Value) = split (/:/, $Info, 2);
        $Name  =~ s/\s*$//; $Value =~ s/^\s*//;
        $Info{lc($Name)} = $Value;
      }
      close INFO;
      $Info{"ttl"} = 0 if (! exists $Info{"ttl"});
      if (($Stat[9]+$Info{"ttl"}) < time())
      {
        $Log->Log ("Skipped '$File': already expired."); 
        unlink ("$Spool/$File.info");
        unlink ("$Spool/$File.data");
        next;
      }
      $Info{"to"} = "" if (! exists $Info{"to"});
      if ($Info{'to'} eq "")
      {
        $Log->Log ("Skipped '$File': missing 'to' info."); 
        unlink ("$Spool/$File.info");
        unlink ("$Spool/$File.data");
        next;
      }
      $Data = "";
      if (open (DATA, "$Spool/$File.data"))
      {
        $Data = do { local( $/ ) ; <DATA> } ;
        close DATA;
      }
      #--------------------------------------------------------
      $Lock->Touch();
      $UsedServer = $Client->Post_Item ($Log, $File, \%Info, $Data, $LastServer);
      if ($UsedServer < 0) { return $Lock->Unlink(); }
      $LastServer = $UsedServer;
      unlink ("$Spool/$File.info");
      unlink ("$Spool/$File.data");
      $Count++;
      $Sleep = 0;
      if ($main::Stop) { return $Lock->Unlink(); }
    }
    next if ($Count > 0);
    $Sleep++;
    if ($Sleep >= 60)
    {
      $Lock->Touch();
      %Info = ('event' => 'tmdx.heartbeat');
      $UsedServer = $Client->Post_Item ($Log, "", \%Info, "", $LastServer);
      if ($UsedServer < 0) { return $Lock->Unlink(); }
      $LastServer = $UsedServer;
      $Sleep = 0;
    }
    sleep (1);
  }
  #--------------------------------------------------------------------
  # ..... until we're done .....
  #--------------------------------------------------------------------
  $Lock->Unlink;
  exit 0;
}
#------------------------------------------------------------------------------
sub Post_Item
{
	my ($Client, $Log, $File, $Info, $Data, $LastServer) = @_;
	my (@Servers, $Tool, $Url, $Name, $Value, $UsedServer, $Server);
	my ($Response, $Post, $Line);
	#--------------------------------------------------------------------
	die ("Usage: Tmdx::Client->Post_Item(...);") if (ref($Client) ne "Tmdx::Client");
	@Servers = split (/[\s\,\;]+/, $Client->{"Tx"}{"Servers"});
	$Tool    = ucfirst lc $Client->{"Tx"}{"Tool"};
	$Url     = "";
	foreach $Name (keys %$Info)
	{
		$Value = $Info->{$Name};
		$Value =~ s/([^-.\w ])/sprintf('%%%02X', ord $1)/ge;
		$Value =~ tr/ /+/;
		if (!$Url) { $Url = "?"; } else { $Url .= "&"; }
		$Url .= "$Name=$Value";
	}
	$LastServer = $#Servers if (! defined $LastServer);
	for ($UsedServer = $LastServer+1; 1;$UsedServer++)
	{
		$UsedServer = 0 if ($UsedServer > $#Servers);
		$Server     = $Servers[$UsedServer];
		$Log->Log (uc($Tool)." POST https://$Server/Tmdx/Server/$Url");
		$Response   = $Client->$Tool("POST", "https://$Server/Tmdx/Server/$Url", $Data);
		$Log->Log ("    ".$Response->{status});
		if ($Response->{status} =~ /^200/)
		{
			$Post = {};
			foreach $Line (split (/\n/, $Response->{data}))
			{
				$Line  =~ s/^\s*//; $Line =~ s/\s*$//;
				($Name, $Value) = split (/:/, $Line, 2);
				next if (! defined $Value);
				$Name  =~ s/\s*$//; $Value =~ s/^\s*//;
				$Post->{lc($Name)} = $Value;
			}
			$Info->{'event'} = "" if (! exists $Info->{'event'});
			if ($Info->{'event'} eq 'tmdx.heartbeat') { $Log->Log ("    Posted 'tmdx.heartbeat' to '$Server' ..."); }
			else { $Log->Log ("    Posted '$File' to '".$Info->{'to'}."' via '$Server' as '".$Post->{'ticket'}."' ..."); }
			`touch $Client->{Tx}{File}.ack`;
			`touch $Client->{Tx}{File}-$Server.ack`;
			if (exists $Response->{info}{_heartbeat})
			{
				if (defined $Response->{info}{_heartbeat})
				{
					$File = $Client->{"Tx"}{"File"}."-$Server.hbt";
					if (open (HBT, ">$File"))
					{
					  print HBT $Response->{info}{_heartbeat}."\n";
					  close HBT;
					}
					else { $Log->Log ("Error writing '$File': $!"); }
				}
			}
			return $UsedServer;
		}
		last if ($UsedServer == $LastServer);
	}
	if ($Info->{'event'} eq 'tmdx.heartbeat') { $Log->Log ("Failed to post 'tmdx.heartbeat': restarting ..."); }
	else { $Log->Log ("Failed to post '$File' to '".$Info->{'to'}."': restarting ..."); }
	return -1;
}
#------------------------------------------------------------------------------
sub Post_SelfCheck
{
  my ($Client, $Log, $Kill, $Age, @Servers, $Server, $File, $Pid, @Stat);
  #--------------------------------------------------------------------
  ($Client) = @_;
  die ("Usage: Tmdx::Client->Post_SelfCheck();") if (ref($Client) ne "Tmdx::Client");
  $0 .= "::Tmdx::Client->Post_SelfCheck()";
  return if (! -r $Client->{"Tx"}{"Spool"}."/post.pid"); # Impossible !!!
  require "Tmdx/Log.pm";
  $Log = Tmdx::Log->new ($Client->{"Tx"}{"Spool"}."/log", "post-selfcheck.log", undef, undef, 1);
  $Log->Log ("------------------------------------------------------------------",
             "Tmdx::Client->Post_SelfCheck() v$main::VERSION - Copyright (c) $main::COPYRIGHT");
  $Kill = 0;
  $Pid  = undef;

  $Age = $Client->Post_CheckHeartbeat ("Process", $Client->{"Tx"}{"File"}.".pid", $Log);
  if (defined $Age) { if ($Age > 300) { $Kill++; } }

  $Age = $Client->Post_CheckHeartbeat ("Communication", $Client->{"Tx"}{"File"}.".ack", $Log);
  if (defined $Age) { if ($Age > 300) { $Kill++; } }

  @Servers = split (/[\s\,\;]+/, $Client->{"Tx"}{"Servers"});
  foreach $Server (@Servers)
  {
    $Age = $Client->Post_CheckHeartbeat ("Local '$Server'", $Client->{"Tx"}{"File"}."-$Server.ack", $Log);
    if (defined $Age) { if ($Age > 300) { $Kill++; } }

    # Crosscheck the remote 'post' heartbeat retrieved by the 'get' process ...
    $Age = $Client->Post_CheckHeartbeat ("Remote '$Server'", $Client->{"Tx"}{"File"}."-$Server.hbt", $Log);
    if (defined $Age) { if ($Age > 600) { $Kill++; } }
  }

  return if (! $Kill);
  $File = $Client->{"Tx"}{"File"}.".pid";
  $Pid  = `cat $File 2>/dev/null`;
  chomp $Pid;
  return if (! $Pid);

  $File = $Client->{"Tx"}{"File"}.".kill";
  @Stat = stat ($File);
  if ($#Stat < 9) { $Stat[9] = 0; }
  $Age  = time() - $Stat[9];
  if ($Age <= 275)
  {
    $Log->Log ("Process $Pid was killed $Age seconds ago: waiting for restart ...");
    return;
  }
  `touch $File`;
  $Log->Log ("Killing process $Pid and waiting for it to restart ...");
  kill ( 2, $Pid);
  kill (15, $Pid);
  #--------------------------------------------------------------------
  return;
}
#------------------------------------------------------------------------------
sub Post_CheckHeartbeat
{
  my ($Client, $Heartbeat, $File, $Log, @Stat, $Age, $Pid, $Message);
  #--------------------------------------------------------------------
  ($Client, $Heartbeat, $File, $Log) = @_;
  die ("Usage: Tmdx::Client->Post_CheckHeartbeat();") if (ref($Client) ne "Tmdx::Client");
  @Stat = stat ($File);
  if ($File !~ /\.hbt/)
  {
    if ($#Stat < 9) 
    { 
      $Log->Log ("Unable to read '$File': $!");
      return undef;
    }
    $Age = time() - $Stat[9];
	if ($File =~ /\.pid/)
	{
		if (open (HBT, $File)) 
		{
			$Pid = <HBT>;
			close HBT;
			$Pid =~ s/\D//g;
			$Heartbeat .= " $Pid";
		}
	}
  }
  else 
  {
    if ($#Stat < 9) { return undef; }
    $Age = time() - $Stat[9];
    if ($Age > 300) { return undef; }
    if (! open (HBT, $File)) { return undef; }
    $Age = <HBT>;
    close HBT;
    ($Age) = ($Age =~ /(\d+)$/); # The last part is the 'post' heartbeat
    $Age  = time() - $Age;
  }
  if    ($Age <= 300) { $Message = "OK";       }
  elsif ($Age <= 600) { $Message = "WARNING";  }
  else                { $Message = "CRITICAL"; }
  $Message .= ": $Heartbeat heartbeat is $Age second";
  $Message .= "s" if $Age != 1;
  $Message .= " old.";
  $Log->Log ($Message);
  #--------------------------------------------------------------------
  return $Age;
}
#------------------------------------------------------------------------------
1;

