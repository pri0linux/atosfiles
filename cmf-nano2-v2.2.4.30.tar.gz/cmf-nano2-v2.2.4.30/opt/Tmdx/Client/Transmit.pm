package Tmdx::Client;
#------------------------------------------------------------------------------
# Tmdx/Client/Transmit.pm - TMDX Client class Transmit method definition
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub Transmit
{
  my (@Ttl, $Client, $Info, $Data, $Folder, $Ttl, $File, $gz);
  #------------------------------------------------------------------------
  @Ttl = (60, 3600, 604800); # Minimum, default and maximum TTL
  #------------------------------------------------------------------------
  ($Client, $Info, $Data) = @_;
  die ("Usage: Tmdx::Client->Transmit($Info, $Data);") if (ref($Client) ne "Tmdx::Client");
  if ((ref($Info) ne "HASH") || (! defined $Data))
  {
    $Client->{"Error"} = "Invalid Info (not a HASHREF) and/or Data (undefined)!";
    return $Client->{"Error"};
  }
  $Info->{"to"} = "" if (! exists $Info->{"to"});
  if ($Info->{"to"} eq "")
  {
    $Client->{"Error"} = "Invalid Info ('to' not specified)!";
    return $Client->{"Error"};
  }
  if (exists $Info->{"event"})
  {
    if (defined $Info->{"event"})
    {
      if ($Info->{"event"} =~ /^tmdx.heartbeat$/i)
      {
        $Client->{"Error"} = "Reserved 'event=tmdx.heartbeat' not allowed!";
        return $Client->{"Error"};
      }
    }
  }
  $Folder = $Client->{"Tx"}{"Spool"}."/tx";
  if (! -d $Folder) { mkpath ($Folder); }
  $Client->{"Tx"}{"Count"}++;
  if ($Client->{"Tx"}{"Count"} > 999) { $Client->{"Tx"}{"Count"} = 0; }
  $Ttl = $Ttl[1]; 
  if (exists $Info->{"ttl"}) { $Ttl = $Info->{"ttl"}; }
  if ($Ttl < $Ttl[0]) { $Ttl = $Ttl[0]; }
  if ($Ttl > $Ttl[2]) { $Ttl = $Ttl[2]; }
  $Info->{"ttl"} = $Ttl;
  $File = sprintf ("$Folder/%s.%03d%05d", time(), $Client->{"Tx"}{"Count"}, $$);
  #------------------------------------------------------------------------
  # Write the data file
  #------------------------------------------------------------------------
  $gz = gzopen ("$File.data", "wb");
  if (! $gz) 
  { 
    $Client->{"Error"} = "Can't write '$File.data': $!"; 
    return $Client->{"Error"};
  }
  if (length($Data) > 0)
  {
    if (! $gz->gzwrite($Data)) 
    {
      $Client->{"Error"} = "Can't write '$File.data': $!"; 
      $gz->gzclose();
      unlink "$File.data";
      return $Client->{"Error"};
    }
  }
  $gz->gzclose();
  #------------------------------------------------------------------------
  # Write the info file
  #------------------------------------------------------------------------
  if (! open (INFO, ">$File.temp"))
  { 
    $Client->{"Error"} = "Can't write '$File.temp': $!"; 
    unlink "$File.temp";
    unlink "$File.data";
    return $Client->{"Error"};
  }
  foreach (keys %$Info)
  {
    next if (/^[\.\_]/);
    print INFO lc($_).": ".$Info->{$_}."\n"; 
  }
  close INFO;
  if (! move ("$File.temp", "$File.info"))
  {
    $Client->{"Error"} = "Can't move '$File.temp' to '$File.info': $!";
    unlink "$File.info";
    unlink "$File.temp";
    unlink "$File.data";
    return $Client->{"Error"};
  }
  $Client->{"Error"} = undef;
  #------------------------------------------------------------------------
  return $Client->{"Error"};
}
#------------------------------------------------------------------------------
1;


