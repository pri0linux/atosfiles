package Tmdx::Client;
#------------------------------------------------------------------------------
# Tmdx/Client/Receive.pm - TMDX Client class Receive method definition
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Path;
#------------------------------------------------------------------------------
sub Receive
{
  my ($Client, $Folder, $File, $Info, $Name, $Value, $Expires, $Data, $gz, $Line);

  ($Client) = @_;
  die ("Usage: Tmdx::Client->Receive();") if (ref($Client) ne "Tmdx::Client");

  $Folder = $Client->{"Rx"}{"Spool"}."/rx";
  if (! -d $Folder) { mkpath ($Folder); }
  if ($#Tmdx::Client::Receive::Queue < 0)
  {
    if (! opendir (FOLDER, $Folder))
    { 
      $Client->{"Error"} = "Unable to read '$Folder': $!";
      return (undef, undef);
    }
    @Tmdx::Client::Receive::Queue = sort (grep { /^[^\.].+\.info$/ } readdir(FOLDER));
    closedir FOLDER;
  }
  while ($File = shift(@Tmdx::Client::Receive::Queue))
  {
    $File  =~ s/\.info$//;
    next if (! -r "$Folder/$File.info");
    if (!open (INFO, "$Folder/$File.info")) 
    { 
      $Client->{"Error"} = "Unable to read '$Folder/$File.info': $!";
      unlink ("$Folder/$File.info");
      unlink ("$Folder/$File.data");
      return (undef, undef);
    }
    $Info = {};
    while (<INFO>) 
    {
      my ($Name, $Value) = split(':', $_, 2);
      if ((defined $Name) && (defined $Value)) 
      { 
        $Name=~ s/^\s+//; $Name=~ s/\s+$//; $Name= lc ($Name);
        chomp($Value); $Value=~ s/^\s+//; $Value=~ s/\s+$//;
        next if ($Name =~ /^[\.\_]/);
        $Info->{$Name} = $Value; 
      }
    }
    close INFO;
    $Expires = $Info->{'gmt'} + $Info->{'ttl'};
    if ($Expires < time())
    {
      unlink ("$Folder/$File.info");
      unlink ("$Folder/$File.data");
      next;
    }
    $Data = "";
    $gz = gzopen ("$Folder/$File.data", "rb");
    if ($gz) 
    {
      while ($gz->gzread($Line, 8192) > 0) { $Data .= $Line; }
      $gz->gzclose();
    }
    unlink ("$Folder/$File.info");
    unlink ("$Folder/$File.data");
    $Client->{"Error"} = undef;
    return ($Info, $Data);
  } 
  $Client->{"Error"} = undef;
  #------------------------------------------------------------------------
  return (undef, undef);
}
#------------------------------------------------------------------------------
1;


