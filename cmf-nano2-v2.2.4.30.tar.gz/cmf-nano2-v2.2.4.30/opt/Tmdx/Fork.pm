package Tmdx;
#------------------------------------------------------------------------------
# Tmdx/Fork.pm                                                     TMDX Library
#------------------------------------------------------------------------------
sub Fork
{
  my ($Pid);
  #------------------------------------------------------------
  # Parent creates child and returns 0
  #------------------------------------------------------------
  $Pid = fork();
  if (! defined $Pid)
  {
    print STDERR "Fork failed: $!\n";
    return undef;
  }
  if ($Pid != 0) { waitpid ($Pid, 0); return 0; }
  #------------------------------------------------------------
  # Child creates grandchild and exits
  #------------------------------------------------------------
  $Pid = fork();
  if (! defined $Pid)
  {
    print STDERR "Fork failed: $!\n";
    return undef;
  }
  if ($Pid != 0) { exit 0; }
  #------------------------------------------------------------
  # Grandchild redirects STD* and returns it's pid
  #------------------------------------------------------------
  close (STDOUT); open (STDOUT, '>/dev/null'); 
  close (STDERR); open (STDERR, '>/dev/null'); 
  #------------------------------------------------------------
  return $$;
}
#------------------------------------------------------------------------------
1;
