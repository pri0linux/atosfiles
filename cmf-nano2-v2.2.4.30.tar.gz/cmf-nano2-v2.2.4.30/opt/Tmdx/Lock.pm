package Tmdx::Lock;
#------------------------------------------------------------------------------
# Tmdx/Lock.pm                                                     TMDX Library
#------------------------------------------------------------------------------
use strict;
use warnings;
use Fcntl qw(:DEFAULT :flock);
use File::Basename;
use File::Path;
#------------------------------------------------------------------------------
sub new
{
  my ($Class, $File, $Lock);
  #------------------------------------------------------------------------
  $Class  = shift;
  $File   = shift;
  $Lock = { "File" => $File, "Handle" => undef, "Error" => undef};
  if (! defined $File) { $Lock->{"Error"} = "Lock file not specified"; }
  bless $Lock, $Class;
  #------------------------------------------------------------------------
  return $Lock;
}
#------------------------------------------------------------------------------
sub Error
{
  my ($Lock) = @_;
  die ("Usage: Tmdx::Lock->Error();") if (ref($Lock) ne "Tmdx::Lock");
  return $Lock->{"Error"};
}
#------------------------------------------------------------------------------
sub Lock
{
  my ($Lock, $File, $Handle, $isLocked, $Path, $Select, $Test);
  #------------------------------------------------------------------------
  $Lock   = shift;
  die ("Usage: Tmdx::Lock->Lock();") if (ref($Lock) ne "Tmdx::Lock");
  $File   = $Lock->{"File"};
  $Handle = $Lock->{"Handle"};
  if (defined $Handle)
  {
    $Lock->{"Error"} = "Lock is already locked.";
    return 0;
  }
  $isLocked = dirname($0)."/Tmdx/isLocked.pl";
  if (! -r $isLocked)
  {
    $Lock->{"Error"} = "$isLocked is missing.";
    return 0;
  }
  chmod (0750, $isLocked);
  $Path = dirname ($File);
  if (! -d $Path) { mkpath ($Path); }
  if (sysopen ($Handle, $File, O_WRONLY | O_NONBLOCK | O_CREAT))
  {
    if (flock ($Handle, LOCK_EX | LOCK_NB))
    {
      if (truncate ($Handle, 0))
      {
        $Select = select($Handle); 
        $| = 1; 
        select($Select); 
        print $Handle "$$\n";
        $Test = system ($isLocked, $File) >> 8;
        if ($Test == 0) 
        {
          $Lock->{"Handle"} = $Handle;
          return 1; 
        }
        close ($Handle);
        $Lock->{"Error"} = "Lock is broken.";
        return 0;;
      }
    }
    close ($Handle)  
  }
  #------------------------------------------------------------------------
  return 0;
}
#------------------------------------------------------------------------------
sub Touch
{
  my ($Lock, $File, $Handle, $Time);
  #------------------------------------------------------------------------
  $Lock   = shift;
  die ("Usage: Tmdx::Lock->Touch();") if (ref($Lock) ne "Tmdx::Lock");
  $File   = $Lock->{"File"};
  $Handle = $Lock->{"Handle"};
  if (! defined $Handle)
  {
    $Lock->{"Error"} = "Lock is not locked.";
    return 0;
  }
  $Time = time();
  utime ($Time, $Time, $File);
  #------------------------------------------------------------------------
  return 1;
}
#------------------------------------------------------------------------------
sub Unlink
{
  my ($Lock, $Handle, $File);
  #------------------------------------------------------------------------
  $Lock   = shift;
  die ("Usage: Tmdx::Lock->Unlink();") if (ref($Lock) ne "Tmdx::Lock");
  $Handle = $Lock->{"Handle"};
  if (defined $Handle)
  {
    close ($Handle);
    $Lock->{"Handle"} = undef;
  }
  $File   = $Lock->{"File"};
  if (! -r $File)
  {
    $Lock->{"Error"} = "File not found.";
    return 0;
  }
  unlink ($File);
  #------------------------------------------------------------------------
  return 1;
}
#------------------------------------------------------------------------------
sub Unlock
{
  my ($Lock, $Handle);
  #------------------------------------------------------------------------
  $Lock   = shift;
  die ("Usage: Tmdx::Lock->Unlock();") if (ref($Lock) ne "Tmdx::Lock");
  $Handle = $Lock->{"Handle"};
  if (! defined $Handle)
  {
    $Lock->{"Error"} = "Lock is not locked.";
    return 0;
  }
  close ($Handle);
  $Lock->{"Handle"} = undef;
  #------------------------------------------------------------------------
  return 1;
}
#------------------------------------------------------------------------------
1;
