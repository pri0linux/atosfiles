package Tmdx::Monitor;
#------------------------------------------------------------------------------
# Tmdx/Monitor.pm                                                  TMDX Library
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Basename;
use File::Path;
#------------------------------------------------------------------------------
sub new
{
  my ($Class, $Monitor, $Path, $Rrd, $Rows, $Response);
  #------------------------------------------------------------------------
  ($Class, $Monitor) = @_;
  $Monitor->{"Error"} = "";
  if (! exists $Monitor->{"File"}) { $Monitor->{"Error"} .= "Monitor file not specified.\n"; }
  if (! exists $Monitor->{"Name"}) { $Monitor->{"Error"} .= "Monitor name not specified.\n"; }
  if (! exists $Monitor->{"Type"}) { $Monitor->{"Error"} .= "Monitor type not specified.\n"; }
  bless $Monitor, $Class;
  return $Monitor if ($Monitor->{"Error"} ne "");
  $Monitor->{"Error"} = undef;
  #------------------------------------------------------------------------
  $Monitor->{"Step"}      = 60                            if (! exists $Monitor->{"Step"});
  $Monitor->{"Heartbeat"} = $Monitor->{"Step"} * 5        if (! exists $Monitor->{"Heartbeat"});
  $Monitor->{"Rows"}      = 34560000 / $Monitor->{"Step"} if (! exists $Monitor->{"Rows"});
  #------------------------------------------------------------------------
  if (! -r $Monitor->{"File"})
  {
    $Path = dirname($Monitor->{"File"});
    eval ("mkpath (\$Path);") if (! -d $Path);
    $Rrd  = "rrdtool create ".$Monitor->{"File"};
    $Rrd .= " --step ".$Monitor->{"Step"};
    $Rrd .= " DS:".$Monitor->{"Name"}.":".$Monitor->{"Type"}.":".$Monitor->{"Heartbeat"}.":0:U";
    $Rrd .= " RRA:AVERAGE:0.5:1:".$Monitor->{"Rows"};
    $Response = `$Rrd 2>&1`;
    chomp $Response;
    $Monitor->{"Error"} = $Response if ($Response !~ /^\s*$/);
  }
  #------------------------------------------------------------------------
  return $Monitor;
}
#------------------------------------------------------------------------------
sub Error
{
  my ($Monitor) = @_;
  die ("Usage: Tmdx::Monitor->Error();") if (ref($Monitor) ne "Tmdx::Monitor");
  return $Monitor->{"Error"};
}
#------------------------------------------------------------------------------
sub Update
{
  my ($Monitor, $Value, $Rrd, $Response);

  ($Monitor, $Value) = @_;
  die ("Usage: Tmdx::Monitor->Update();") if (ref($Monitor) ne "Tmdx::Monitor");
  $Monitor->{"Error"} = undef;
  $Rrd  = "rrdtool update ".$Monitor->{"File"}." N:$Value";
  $Response = `$Rrd 2>&1`;
  chomp $Response;
  $Monitor->{"Error"} = $Response if ($Response !~ /^\s*$/);
  return $Monitor->{"Error"};
}
#------------------------------------------------------------------------------
1;
