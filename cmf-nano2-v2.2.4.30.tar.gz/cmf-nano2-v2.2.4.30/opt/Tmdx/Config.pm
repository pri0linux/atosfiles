package Tmdx::Config;
#------------------------------------------------------------------------------
# Tmdx/Config.pm                                                   TMDX Library
#------------------------------------------------------------------------------
use strict;
use warnings;
#------------------------------------------------------------------------------
sub new
{
  our ($CFG_FILE, $VAR_PATH);
  my ($Class, $File, $Module, %Array, $Config, $Name, $Value, $Array, @Name);
  #------------------------------------------------------------------------
  $Class  = shift;
  $File   = shift;
  $Module = shift;
  %Array  = ();
  $Config = { "File" => undef, "Error" => undef, "Array" => \%Array};
  if (defined $File)
  {
    if (open (CONFIG, $File))
    {
      $Config->{"File"}   = $File;
      while (<CONFIG>) 
      {
        chomp ($_);
        $_=~ s/^\s+//; $_ =~ s/\s+$//; 
        ($Name, $Value) = split('=', $_, 2);
        if (($Name) && ($Value)) 
        { 
          $Name=~ s/\s+$//; $Value=~ s/^\s+//;
          if ($Name =~ /^\s*\w/) 
          {
            $Config->{lc($Name)} = $Value; 
            if (exists $Array{lc($Name)}) 
            {
              $Array = $Array{lc($Name)};
              push (@$Array, $Value);
            }
            else { $Array{lc($Name)} = [$Value]; }
          }
        }
      } 
      close CONFIG;
      if (defined $Module)
      {
        $Module = lc($Module);
        for $Name (keys %$Config)
        {
          next if ($Name ne lc($Name));
          @Name = split (/\./, $Name, 2);
          next if ($#Name < 1);
          if ($Name[0] eq $Module) 
          {
            $Config->{$Name[1]} = $Config->{$Name}; 
            $Array{$Name[1]}    = $Array{$Name};
          }          
        }
      }
    }
    else { $Config->{"Error"} = "Unable to read '$File': $!"; }
  }
  else { $Config->{"Error"} = "Config file not specified"; }
  bless $Config, $Class;
  #------------------------------------------------------------------------
  return $Config;
}
#------------------------------------------------------------------------------
sub Error  
{ 
  my ($Config) = @_; 
  die ("Usage: Tmdx::Config->Error();") if (ref($Config) ne "Tmdx::Config");
  return $Config->{"Error"}; 
}
#------------------------------------------------------------------------------
sub File   
{ 
  my ($Config) = @_; 
  die ("Usage: Tmdx::Config->File();") if (ref($Config) ne "Tmdx::Config");
  return $Config->{"File"}; 
}
#------------------------------------------------------------------------------
sub Get
{ 
  my ($Config, $Name) = @_; 
  die ("Usage: Tmdx::Config->Get(<name>);") if (ref($Config) ne "Tmdx::Config");
  return undef if (! exists $Config->{lc($Name)});
  return $Config->{lc($Name)};
}
#------------------------------------------------------------------------------
sub GetArray
{ 
  my ($Config, $Name) = @_; 
  die ("Usage: Tmdx::Config->GetArray(<name>);") if (ref($Config) ne "Tmdx::Config");
  return undef if (! exists $Config->{"Array"}->{lc($Name)});
  return $Config->{"Array"}->{lc($Name)};
}
#------------------------------------------------------------------------------
1;
