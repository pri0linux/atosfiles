package Tmdx;
#------------------------------------------------------------------------------
# Tmdx::SetPath
#------------------------------------------------------------------------------
use strict;
use warnings;
use File::Path;

sub SetPath 
{
  my ($Specs) = @_;
  my ($Spec, $Mode, %Paths, $Path, $Eval);
  #--------------------------------------------------------------------
  # Build a list of all paths and the mode that should be set
  #--------------------------------------------------------------------
  if (ref($Specs) ne "HASH")
  {
    die ("Usage: Tmdx::SetPath(\\\%Specs);");
    return;
  }
  foreach $Spec (keys %$Specs)
  {
    $Mode = $Specs->{$Spec};
    if ($Spec !~ /[\*\?]/) { $Paths{$Spec} = $Mode; }
      else { foreach $Path (glob $Spec) { $Paths{$Path} = $Mode }; } 
  }
  #--------------------------------------------------------------------
  # Create any missing paths and set the mode on all specified files
  #--------------------------------------------------------------------
  foreach $Path (keys %Paths)
  {
    $Mode = $Paths{$Path};
    next if ((-r $Path) && (! -d $Path));
    next if (! defined $Mode);
    if ($Mode !~ /^02?[01357][01357][01357]$/)
    {
      die ("Tmdx::SetPath '$Path' failed: '$Mode' is not a supported mode");
    }
    $Eval  = "mkpath (\$Path) if (! -d \$Path);\n";
    $Eval .= "chmod ($Mode, \$Path);\n";
    eval ($Eval);
  } 
  #--------------------------------------------------------------------
  return;
}
#------------------------------------------------------------------------------
1;
