package Tmdx;
use POSIX;
#------------------------------------------------------------------------------
# Tmdx/Period.pm                                                   TMDX Library
#------------------------------------------------------------------------------
# Tmdx::Period ($File, $Offset, $Format)
#
#   Check if it's time to perform periodical tasks
#
# Parameters:
#
#   $File      the PID-file to be used as timestamp
#   $Offset    the offset in hours after midnight to delay
#   $Format    the strftime format to create the period ID
#
# Return value:
#
#   0    if it's not yet time
#   1    if it is time
#
# To do:
#
#   Move this information block to the Wiki
#
#------------------------------------------------------------------------------
sub Period
{
  my ($File, $Offset, $Format, $Now, @Stat, @T0, $T0, @T1, $T1);
  #--------------------------------------------------------------------
  ($File, $Offset, $Format, $Now) = @_;
  if (! $Now) 
  { 
    $Now = time(); 
  }
  @Stat = stat ($File);
  if ($#Stat > 9)
  { 
    @T0 = gmtime($Stat[9] - $Offset * 3600 - 300);
    $T0 = strftime($Format, @T0);
  }
  else { $T0 = 0; }
  @T1 = gmtime($Now - $Offset * 3600 - 300);
  $T1 = strftime($Format, @T1);
  return 0 if ($T0 >= $T1);
  if (open (PID, ">$File")) 
  {
    print PID "$$\n";
    close PID;
    utime ($Now, $Now, $File);
  }
  #------------------------------------------------------------
  return 1;
}
#------------------------------------------------------------------------------
1;
