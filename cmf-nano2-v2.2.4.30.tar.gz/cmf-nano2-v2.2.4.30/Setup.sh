#!/bin/bash
perl `dirname $0`/Setup.pl
if [ $? -ne 1 ] ; then exit 2; fi
su -c "perl `dirname $0`/Setup.pl" nagios
exit $?

