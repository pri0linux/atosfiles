#!/usr/bin/env bash
su -c '/opt/Nagios/Node/NagiosNode.pl NagiosNode' nagios;
/usr/sbin/httpd;
crond &
if [ ! -f /home/nagios/NaCl/NaCl.cfg ] && [ -n "$UUID" ]; then
	echo "uuid=$UUID" > /home/nagios/NaCl/NaCl.cfg;
	echo "server=127.0.0.1" >> /home/nagios/NaCl/NaCl.cfg;
	echo "nacc=nacc" >> /home/nagios/NaCl/NaCl.cfg;
	chown nagios:nagios /home/nagios/NaCl/NaCl.cfg;
	su -c '/opt/Nagios/Node/RequestKey.pl NagiosNode cleanup' nagios;
	su -c '/home/nagios/NaCl/NaCl -v' nagios;
else
	sleep 30;
	su -c '/home/nagios/NaCl/NaCl -s 127.0.0.1' nagios;
fi

exec "$@";
